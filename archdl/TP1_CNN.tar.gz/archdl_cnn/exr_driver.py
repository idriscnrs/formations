import imageio
# for exr format, to do on a node with internet access
imageio.plugins.freeimage.download()  