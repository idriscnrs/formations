import os
from os.path import join
from torch.hub import set_dir, get_dir 
import segmentation_models_pytorch as smp

def get_model(encoder, in_channels):
    encoder_weight = 'imagenet' # 'imagenet' or None (pretrained or not)
    activation = None 
    classes = 5
    print(f"Downloading model with encoder {encoder} with {in_channels} input channels")
    _ = smp.Unet(encoder_name=encoder, encoder_weights=encoder_weight, 
                 in_channels=in_channels, 
                 classes=classes, activation=activation)

if __name__ == '__main__':
    print(f"segmentation_models_pytorch version: {smp.__version__}")

    working_dir = os.getcwd() 
    set_dir(join(working_dir, ".cache/"))

    MODEL_CACHE = get_dir()
    os.makedirs(MODEL_CACHE, exist_ok=True)
    print(f"Models will be downloaded here: {MODEL_CACHE}")
    
    # input channels : 3 for RGB or 4 for RGB+D
    in_channels = 3 
    # encoder suggestions resnet18, vgg11_bn, resnet34
    encoder = "resnet18" 
    get_model(encoder, in_channels)
