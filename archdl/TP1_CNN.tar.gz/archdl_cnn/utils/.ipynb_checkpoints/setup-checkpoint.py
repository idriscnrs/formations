from os import getcwd, makedirs, environ
from os.path import join
from torch.hub import set_dir, get_dir
import sys

def get_path(datapath=None):
    if not datapath:
        try:
            datapath = join(environ["DSDIR"], "IPDL/datasets/TP3")
        except KeyError as e:
            sys.stderr.write("Please define a datasets root directory")
    training_path, testing_path = join(datapath,"training"), join(datapath,"testing")

    folders= {"semantic": "semantic_map", 
            "rgb": "rgb_map", 
            "depth": "depth_map"}

    return datapath, training_path, testing_path, folders["rgb"], folders["depth"], folders["semantic"]  

def get_samples_filename():
        train_csv, valid_csv, test_csv = "train_list.csv", "valid_list.csv", "test_list.csv" 
        return train_csv, valid_csv, test_csv

def set_model_cache():
        working_dir = getcwd() 
        set_dir(join(working_dir, ".cache"))
        MODEL_CACHE = get_dir()
        makedirs(MODEL_CACHE, exist_ok=True)
        print(f"Cached models are expected here: {MODEL_CACHE}") 
        return MODEL_CACHE

def set_model_save_dir(folder, model_name):    
    MODEL_SAVE_DIR = join(getcwd(), folder)
    makedirs(MODEL_SAVE_DIR, exist_ok=True)
    MODEL_NAME= model_name
    return MODEL_SAVE_DIR, MODEL_NAME

def get_train_samples(datapath, train_csv, valid_csv):
        with open(join(datapath, train_csv), 'r') as file:
                train_samples = file.read().splitlines()
    
        with open(join(datapath, valid_csv), 'r') as file:      
                valid_samples = file.read().splitlines() 
        return train_samples, valid_samples
    
def get_test_samples(datapath, test_csv):
        with open(join(datapath, test_csv), 'r') as file:      
                test_samples = file.read().splitlines() 
        return test_samples   
