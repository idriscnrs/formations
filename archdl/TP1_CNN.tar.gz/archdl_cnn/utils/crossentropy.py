import torch
from torch import nn

class CrossEntropyWithLogitsLoss(nn.Module):
    """Cross entropy loss with logits
    Labels are flattened using argmax function and CrossEntropyLoss uses a LogSoftmax function.
    """
    __name__= "CE" 
    
    def __init__(self, weight=None, reduction='mean'):

        super(CrossEntropyWithLogitsLoss, self).__init__()
        self.cross_entropy = nn.CrossEntropyLoss(weight, reduction=reduction)

    def forward(self, logits, targets):
        # flatten masks to get rid of channel dimension
        # force/cast target tensor to long
        #print(f"logits {logits.shape} targets {targets.shape}")
        targets = torch.argmax(targets.long(), dim=1)
        return self.cross_entropy(logits, targets)