import os
os.environ["OPENCV_IO_ENABLE_OPENEXR"] = "1"   # avant import cv2

from torch.utils.data import Dataset
from torch import from_numpy, unsqueeze, cat
from os.path import join
import numpy as np
import cv2


def _read_exr(path):
    """Lit un EXR avec OpenCV et renvoie un tableau HxWxC en ordre RGB(A), ou HxW si 1 canal."""
    im = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    if im is None:
        raise IOError(f"OpenCV ne peut pas lire {path}")
    if im.ndim == 3:
        if im.shape[2] == 4:
            im = cv2.cvtColor(im, cv2.COLOR_BGRA2RGBA)
        elif im.shape[2] == 3:
            im = cv2.cvtColor(im, cv2.COLOR_BGR2RGB)
    return im


class PlantDataset(Dataset):
    def __init__(self, samples_list, rgb_dir, mask_dir, depth_dir=None, rgb_transform=None, all_transform=None):
        self.samples = samples_list
        self.rgb_dir = rgb_dir
        self.depth_dir =  depth_dir
        self.mask_dir = mask_dir
        self.rgb_transform = rgb_transform
        self.all_transform = all_transform
       
    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        img_path = join(self.rgb_dir, self.samples[idx]) 
        image_rgb = self.__read_rgb__(img_path)
        if self.depth_dir is not(None):
            depth_path = join(self.depth_dir, self.samples[idx]) 
            image_depth = self.__read_depth__(depth_path) 
        else:
            image_depth = None
        mask_path = join(self.mask_dir, self.samples[idx])
        mask = self.__read_mask__(mask_path)
        
        if self.rgb_transform: 
            if isinstance(self.rgb_transform, list):
                for t in self.rgb_transform: 
                    image_rgb = t(image_rgb)
            else:
                image_rgb = self.rgb_transform(image_rgb) # on a numpy array
        
        if image_depth is None:
            image = image_rgb
        else:
            image_depth = unsqueeze(image_depth, dim=0)      
            image = cat([image_rgb, image_depth], dim=0)

        if self.all_transform:
            if isinstance(self.all_transform, list):
                for t in self.all_transform: 
                    image, mask = t(image, mask)
            else:
                image, mask = self.all_transform(image, mask) 
            
        return image, mask
    
    # read RGB images and return tensor
    def __read_rgb__(self, path):  
        im = _read_exr(path)
        im_gamma_correct = np.clip(np.power(im, 0.45), 0, 1)  # default value, can be better
        image = np.transpose(im_gamma_correct, (2, 0, 1))
        # transform into tensor
        tensor = from_numpy(image)
        return tensor

    # read depth images and return tensor
    def __read_depth__(self, path): 
        if path is None:
            return None
        im = _read_exr(path)
        if im.ndim == 3:
            im = im[:, :, 0]          # canal R, comme l'original
        tensor = from_numpy(np.ascontiguousarray(im))
        return tensor

    # concat rgb and depth and return tensor array
    def __concat__(self, image_rgb, image_depth):
        image_depth= np.expand_dims(image_depth, axis=0)
        image= np.concatenate((image_rgb, image_depth), axis=0) 
        tensor = from_numpy(image)
        return tensor

    # read mask data and transform into a pytorch tensor
    def __read_mask__(self, path):
        im= cv2.imread(path)
        im= self.__create_mask__(im[:,:,0])
        im_reshaped = np.transpose(im, (2, 0,1))
        im_reshaped= from_numpy(im_reshaped)
        return im_reshaped
    
    # expand mask in [H,W, no_classes] format 
    def __create_mask__(self, semantic, classes=5):
        size= semantic.shape + (classes,)
        mask= np.zeros(size)
    
        for i in range(classes) :
            mask[:,:,i]= (semantic==i)
        return mask
