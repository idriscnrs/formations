import numpy as np
from matplotlib import pyplot as plt
import matplotlib.colors

# return rgb and depth from a transposed tensor with depth
def split_tensor(image):
    rgb = image[0:3,:,:]
    depth = None
    if image.shape[0]==4:
        depth = np.squeeze(image[3,:,:])
    return rgb, depth


def combine_tensor(rgb, depth):
    if depth is None: return rgb
    depth= np.expand_dims(depth, axis=0)
    image= np.concatenate((rgb, depth), axis=0) 
    return image

##############################
# VISUALISATION
# ############################

# Transform mask (2D) into an RGB image where each class has a specific color
def toRGB(mask):
    # class 1
    sem0, sem1, sem2= np.zeros(mask.shape, np.int8),np.zeros(mask.shape, np.int8),np.zeros(mask.shape, np.int8)
    sem0= np.where(mask==1, 254, sem0)
    # class 2
    sem1= np.where(mask==2, 254, sem1)
    # class 3
    sem2= np.where(mask==3, 254, sem2)
    # class 4
    sem0, sem1, sem2 = np.where(mask==4, 238, sem0), np.where(mask==4, 197, sem1), np.where(mask==4, 145, sem2)

    sem= np.dstack((sem0, sem1, sem2))
    return sem 

# return a 2D mask (already transposed) from a 3D mask (where number of layers = number of classes)
def flatten(mask):
    flatten_mask= np.zeros((mask.shape[0], mask.shape[1]))
    for i in range(5):
        flatten_mask= np.add(flatten_mask,  mask[:,:,i]*i)
    return flatten_mask

# return rgb and depth from a transposed tensor with depth
def split(image):
    rgb = image[:,:,0:3]
    depth = None
    if image.shape[2]==4:
        depth = np.squeeze(image[:,:,3])
    return rgb, depth

def plot_tensor_sample(image, mask):
    image  = np.transpose(image, (1, 2, 0))
    mask = np.transpose(mask, (1,2,0))
    mask = flatten(mask) 

    if image.shape[2]==3: # no depth
        plt.figure(figsize=(15,15))
        plt.subplot(1,2,1)    
        plt.gca().set_title('RGB')
        plt.imshow(image)
        plt.subplot(1,2,2)  
        plt.gca().set_title('semantic mask')
        plt.imshow(mask)
        plt.show()
    else: # with depth
        rgb, depth= split(image)
        plt.figure(figsize=(15,15))
        plt.subplot(1,3,1)    
        plt.gca().set_title('RGB')
        plt.imshow(rgb)
        plt.subplot(1,3,2)  
        plt.gca().set_title('depth')
        plt.imshow(depth, cmap=plt.get_cmap("Spectral"))
        plt.subplot(1,3,3)  
        plt.gca().set_title('semantic mask')
        plt.imshow(mask)
        plt.show()

def plot_transform_rgb(rgb, rgb_T):
    rgb  = np.transpose(rgb, (1, 2, 0))
    rgb_T = np.transpose(rgb_T, (1,2,0))

    plt.figure(figsize=(15,15))
    plt.subplot(1,2,1)    
    plt.gca().set_title('original')
    plt.imshow(rgb)
    plt.subplot(1,2,2)  
    plt.gca().set_title('transformed')
    plt.imshow(rgb_T)
    plt.show() 

def plot_results(image, mask, pred):
    image, mask = np.transpose(image.cpu().numpy(), (1, 2, 0)), np.transpose(mask.cpu().numpy(), (1,2,0))
    if image.shape[2]==4:
        image= image[:,:,0:3]
    mask= flatten(mask)
    pred= pred.cpu().numpy()
    pred_classes = np.argmax(pred, axis=0)
    
    correct_classes = (pred_classes==mask).astype(int)

    mask = toRGB(mask)
    pred_classes = toRGB(pred_classes) 

    plt.figure(figsize=(16,5))
    plt.subplot(1,4,1)    
    plt.gca().set_title('RGB')
    plt.imshow(image)
    plt.subplot(1,4,2)  
    plt.gca().set_title('masque')
    plt.imshow(mask)
    plt.subplot(1,4,3)  
    plt.gca().set_title('prediction')
    plt.imshow(pred_classes)
    plt.subplot(1,4,4) 
    plt.gca().set_title('correct pixels')
    plt.imshow(correct_classes)
    plt.show()  

def plot_results_square(image, mask, pred):
    image, mask = np.transpose(image.cpu().numpy(), (1, 2, 0)), np.transpose(mask.cpu().numpy(), (1,2,0))
    if image.shape[2]==4:
        image= image[:,:,0:3]
    mask= flatten(mask)
    pred= pred.cpu().numpy()
    pred_classes = np.argmax(pred, axis=0)
    
    correct_classes = (pred_classes==mask).astype(int)

    mask = toRGB(mask)
    pred_classes = toRGB(pred_classes) 

    cmap = matplotlib.colors.ListedColormap(['darkred', 'aliceblue'])

    plt.figure(figsize=(12,12))
    plt.subplot(2,2,1)    
    plt.gca().set_title('RGB')
    plt.imshow(image)
    plt.subplot(2,2,2)  
    plt.gca().set_title('pixels mal classés')
    plt.imshow(correct_classes, cmap=cmap)
    plt.subplot(2,2,3)  
    plt.gca().set_title('masque')
    plt.imshow(mask)
    plt.subplot(2,2,4) 
    plt.gca().set_title('prediction')
    plt.imshow(pred_classes)
    plt.show()    