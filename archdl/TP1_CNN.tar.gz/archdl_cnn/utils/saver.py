from os.path import join
import json

def save_results(path, filename, train_losses, val_losses, train_scores, val_scores, epoch_duration):
    data = {
        "train_losses": train_losses,
        "val_losses": val_losses, 
        "train_scores": train_scores, 
        "val_scores": val_scores, 
        "epoch_duration": epoch_duration
    }
    target= join(path, filename+".json")
    with open(target, "w") as file_object:
        json.dump(data, file_object) 
        print(f"Results successfully saved at: {target}")