"""Read local Fashion-MNIST IDX files without implicit network access."""
from pathlib import Path
import gzip
import struct
import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset


def load_images(data_dir, split='train'):
    if split not in ('train', 'test'):
        raise ValueError("split must be 'train' or 'test'")
    filename = 'train-images-idx3-ubyte.gz' if split == 'train' else 't10k-images-idx3-ubyte.gz'
    path = Path(data_dir) / filename
    if not path.is_file():
        raise FileNotFoundError(f'{path} is missing. See README.md for data preparation.')
    with gzip.open(path, 'rb') as source:
        header = source.read(16)
        if len(header) != 16:
            raise ValueError(f'Incomplete IDX header: {path}')
        magic, count, rows, cols = struct.unpack('>IIII', header)
        raw = source.read()
    expected = 60000 if split == 'train' else 10000
    if magic != 2051 or (count, rows, cols) != (expected, 28, 28) or len(raw) != count*rows*cols:
        raise ValueError(f'Invalid or incomplete IDX file: {path}')
    # Writable copy and exact normalization: [0,255] -> [-1,1].
    images = torch.from_numpy(np.frombuffer(raw, dtype=np.uint8).copy().reshape(count, 1, rows, cols))
    return images.float().div_(127.5).sub_(1.0)


def make_loader(data_dir, batch_size=16, split='train', seed=42, limit=None):
    images = load_images(data_dir, split)
    if limit is not None:
        if not 1 <= limit <= len(images):
            raise ValueError('limit is outside the dataset range')
        images = images[:limit]
    dataset = TensorDataset(images)
    return DataLoader(dataset, batch_size=batch_size, shuffle=(split == 'train'),
                      generator=torch.Generator().manual_seed(seed), num_workers=0)
