"""Noise-prediction DDPM operations for a linear VP schedule.

Adapted from tp/code/forward_diffusion.py, tp/code/reverse_diffusion.py,
and Hugging Face Annotated Diffusion. License: CC BY-NC-SA 4.0.
Python indices 0..T-1 correspond to mathematical timesteps 1..T.
"""
from dataclasses import dataclass
import torch


@dataclass
class Schedule:
    betas: torch.Tensor
    alphas: torch.Tensor
    alpha_bar: torch.Tensor
    alpha_bar_prev: torch.Tensor
    posterior_variance: torch.Tensor

    @property
    def T(self):
        return self.betas.numel()


def linear_schedule(T=1000, beta_start=1e-4, beta_end=0.02, device='cpu'):
    if T < 2 or not (0 < beta_start <= beta_end < 1):
        raise ValueError('Invalid schedule: require T >= 2 and 0 < beta_start <= beta_end < 1.')
    betas = torch.linspace(beta_start, beta_end, T, device=device)
    alphas = 1 - betas
    alpha_bar = torch.cumprod(alphas, dim=0)
    alpha_bar_prev = torch.cat((torch.ones_like(alpha_bar[:1]), alpha_bar[:-1]))
    variance = betas * (1 - alpha_bar_prev) / (1 - alpha_bar)
    return Schedule(betas, alphas, alpha_bar, alpha_bar_prev, variance)


def extract(values, timesteps, shape):
    """Return per-example timestep coefficients ready for broadcasting."""
    if timesteps.ndim != 1 or len(shape) < 2 or timesteps.shape[0] != shape[0]:
        raise ValueError('timesteps must have shape [batch] and match shape[0].')
    if timesteps.dtype != torch.long:
        raise ValueError('timesteps must be a torch.long tensor.')
    if values.device != timesteps.device:
        raise ValueError('Schedule and timesteps must be on the same device.')
    return values.index_select(0, timesteps).reshape(shape[0], *((1,) * (len(shape) - 1)))


def q_sample(schedule, x0, t, noise):
    """Exact sample from q(x_t|x_0) using the supplied standard noise."""
    if noise.shape != x0.shape or t.device != x0.device or noise.device != x0.device:
        raise ValueError('x0, t and noise must be on the same device; noise must have the same shape as x0.')
    a = extract(schedule.alpha_bar, t, x0.shape)
    return a.sqrt() * x0 + (1 - a).sqrt() * noise


@torch.no_grad()
def p_sample(schedule, xt, t, predicted_noise, noise):
    """One DDPM step: predicted mean + sqrt(beta_tilde) * fresh noise."""
    if xt.shape != predicted_noise.shape or xt.shape != noise.shape:
        raise ValueError('xt, predicted_noise and noise must have the same shape.')
    if any(z.device != xt.device for z in (t, predicted_noise, noise)):
        raise ValueError('All tensors must be on the same device.')
    beta = extract(schedule.betas, t, xt.shape)
    alpha = extract(schedule.alphas, t, xt.shape)
    a_bar = extract(schedule.alpha_bar, t, xt.shape)
    variance = extract(schedule.posterior_variance, t, xt.shape)
    mean = (xt - beta * predicted_noise / (1 - a_bar).sqrt()) / alpha.sqrt()
    # Index 0 is the final mathematical step t=1: no fresh noise is added.
    active = (t > 0).reshape(xt.shape[0], *((1,) * (xt.ndim - 1)))
    return mean + active * variance.sqrt() * noise


@torch.inference_mode()
def sample(model, schedule, shape, seed=42, add_fresh_noise=True, capture=None, step_fn=p_sample,
           progress_callback=None):
    """Full DDPM loop; only requested states are kept in CPU memory.

    add_fresh_noise=False removes noise from this DDPM update: this is not DDIM.
    The same seed also fixes the initial noise.
    """
    device = next(model.parameters()).device
    if schedule.betas.device != device:
        raise ValueError('The schedule and model must be on the same device.')
    generator = torch.Generator(device=device).manual_seed(seed)
    xt = torch.randn(shape, device=device, generator=generator)
    capture = set(capture or ())
    if any(t < 0 or t >= schedule.T for t in capture):
        raise ValueError('Capture indices must be in 0..T-1.')
    snapshots = {}
    was_training = model.training
    model.eval()
    try:
        for i in range(schedule.T - 1, -1, -1):
            t = torch.full((shape[0],), i, device=device, dtype=torch.long)
            predicted_noise = model(xt, t)
            fresh = (torch.randn(xt.shape, device=device, dtype=xt.dtype, generator=generator)
                     if add_fresh_noise and i > 0 else torch.zeros_like(xt))
            xt = step_fn(schedule, xt, t, predicted_noise, fresh)
            if i in capture:
                snapshots[i] = xt.detach().cpu()
            completed = schedule.T - i
            if progress_callback is not None and (completed == 1 or completed % 100 == 0 or i == 0):
                progress_callback(completed, schedule.T)
    finally:
        model.train(was_training)
    return xt.detach().cpu(), snapshots
