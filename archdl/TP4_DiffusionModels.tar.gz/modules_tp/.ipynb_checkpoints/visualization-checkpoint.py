"""Display images on a fixed scale without modifying input tensors."""
import math
import matplotlib.pyplot as plt
import torch


def show_grid(images, titles=None, columns=4, figsize=None):
    """Images in [-1,1]; use the same scale for all thumbnails.

    Values outside [-1,1] are clipped for display only; input tensors are not
    modified. Grayscale images: [N,1,H,W].
    """
    if images.ndim != 4 or images.shape[1] != 1 or images.shape[0] == 0:
        raise ValueError('Expected a non-empty tensor of shape [N,1,H,W].')
    shown = images.detach().cpu().clone().clamp(-1, 1).add(1).div(2)
    n = len(shown)
    if titles is not None and len(titles) != n:
        raise ValueError('The number of titles must match the number of images.')
    columns = min(columns, n)
    rows = math.ceil(n / columns)
    fig, axes = plt.subplots(rows, columns, figsize=figsize or (columns * 2.0, rows * 2.2), squeeze=False)
    for i, ax in enumerate(axes.flat):
        ax.axis('off')
        if i < n:
            ax.imshow(shown[i, 0], cmap='gray', vmin=0, vmax=1)
            if titles is not None:
                ax.set_title(str(titles[i]), fontsize=10)
    fig.tight_layout()
    plt.show()
    return fig
