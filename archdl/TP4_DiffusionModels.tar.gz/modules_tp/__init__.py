"""Diffusion lab components used by the notebooks and instructor."""
