"""Explicit, validated checkpoint: weights, architecture and schedule together."""
from pathlib import Path
import torch
from .ddpm import linear_schedule
from .model import Unet

FORMAT_VERSION = 1
MODEL_CONFIG = {'dim': 28, 'dim_mults': [1, 2, 4], 'channels': 1}
DEFAULT_SCHEDULE = {'name': 'linear', 'T': 1000, 'beta_start': 1e-4, 'beta_end': 0.02}


def new_model(device, config=None):
    cfg = dict(MODEL_CONFIG if config is None else config)
    if set(cfg) != {'dim', 'dim_mults', 'channels'} or cfg['channels'] != 1:
        raise ValueError('Unknown or unsupported checkpoint architecture.')
    return Unet(dim=int(cfg['dim']), dim_mults=tuple(cfg['dim_mults']), channels=1).to(device)


def make_checkpoint(model, schedule_config, steps, seed, training_config=None):
    if schedule_config.get('name') != 'linear':
        raise ValueError('This lab only supports the linear schedule.')
    return {
        'format_version': FORMAT_VERSION,
        'model_config': dict(MODEL_CONFIG),
        'schedule_config': dict(schedule_config),
        'dataset': 'Fashion-MNIST',
        'normalization': 'uint8 / 127.5 - 1',
        'objective': 'MSE noise prediction',
        'training_steps': int(steps),
        'training_config': dict(training_config or {}),
        'seed': int(seed),
        'state_dict': {name: value.detach().cpu() for name, value in model.state_dict().items()},
    }


def load_checkpoint(path, device='cpu', expected_T=1000):
    """Load only tensors and primitive values from a trusted file."""
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f'Checkpoint missing: {path}. See GUIDE_ENSEIGNANT.md.')
    checkpoint = torch.load(path, map_location='cpu', weights_only=True)
    if not isinstance(checkpoint, dict) or checkpoint.get('format_version') != FORMAT_VERSION:
        raise ValueError('Invalid checkpoint format; use the lab preparation script.')
    sc = checkpoint.get('schedule_config', {})
    required = {'name', 'T', 'beta_start', 'beta_end'}
    if set(sc) != required or sc['name'] != 'linear':
        raise ValueError('Schedule missing or incompatible with this lab.')
    if expected_T is not None and sc['T'] != expected_T:
        raise ValueError(f"Checkpoint T={sc['T']} is incompatible with T={expected_T}.")
    if checkpoint.get('objective') != 'MSE noise prediction':
        raise ValueError('Unknown objective or incompatible with this lab.')
    if not isinstance(checkpoint.get('model_config'), dict) or 'state_dict' not in checkpoint:
        raise ValueError('Architecture or weights missing from the checkpoint.')
    model = new_model(device, checkpoint.get('model_config'))
    model.load_state_dict(checkpoint['state_dict'], strict=True)
    model.eval()
    schedule = linear_schedule(T=int(sc['T']), beta_start=float(sc['beta_start']),
                               beta_end=float(sc['beta_end']), device=device)
    return model, schedule, checkpoint
