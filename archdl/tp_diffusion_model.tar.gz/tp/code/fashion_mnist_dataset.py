# License : CC BY-NC-SA 4.0

from datasets import load_dataset
from torchvision import transforms
from torch.utils.data import DataLoader


def get_dataloader(batch_size: int = 64,
                   test: bool = False):
    """"Create Fashion MNIST dataloader."""
    
    dataset = load_dataset("fashion_mnist")
    # if True, load `test` dataset
    # type : datasets.arrow_dataset.Dataset
    if test:
        dataset = dataset['test']
    else:
        dataset = dataset['train']

    # define image transformations using torchvision
    transform = transforms.Compose([
        transforms.RandomHorizontalFlip(),    # Data augmentation
        transforms.ToTensor(),                # Transform PIL image into tensor of value between [0.0, 1.0]
        transforms.Normalize((0.5,), (0.5,))  # Normalize values between [-0.5, 0.5]
    ])

    # function that apply `transform` to all images in `examples`
    # `examples` is a batch of data from `datasets.arrow_dataset.Dataset`
    # this will be applied on-the-fly when we try access data
    # we assume that `pixel_values` is one of the features
    def transforms_im(examples):
        examples['pixel_values'] = [transform(image) for image in examples['pixel_values']]
        return examples
    
    # apply transforms_im to our `dataset`
    # instead of using the `map` method, we use `with_transform`
    # https://discuss.huggingface.co/t/dataset-map-return-only-list-instead-torch-tensors/15767/4`
    dataset = dataset.with_transform(transforms_im)          # Define transformation on-the-fly
    dataset = dataset.rename_column('image', 'pixel_values') # Rename image
    dataset = dataset.remove_columns('label')                # Remove label
    
    # shape : [C, H, W]
    # H = W in our case
    channels, image_size, _ = dataset[0]['pixel_values'].shape
    
    # create dataloader
    if test:
        dataloader = DataLoader(dataset, batch_size=batch_size)
    else:
        dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

    # number of batches in 1 epoch
    n_batch = len(dataloader)
    
    print(f"\n{'Test' if test else 'Train'} Dataloader built ==>\n",
          f"Image shape       ({channels}, {image_size}, {image_size})\n",
          f"Batch size        {batch_size}\n",
          f"Total batches     {n_batch}")
    
    return dataloader, channels, image_size, n_batch