# Lab Environment Setup
The notebooks were used and tested on the Jean Zay supercomputer, but they are designed to work fine on any classical computer and software environment.

## Jupyter Notebook Environment
For this lab, a Jupyter Notebook environment is essential. Ensure you have access to a Jupyter environment to run the notebooks.

## Python Library Requirements
The notebooks have been tested with the following library versions. While specific versions are listed, the notebooks should be compatible with other recent versions of these libraries, unless noted otherwise.

- **matplotlib:** Version 3.8.2
- **numpy:** Version 1.24.4
- **einops:** Version 0.7.0
- **tqdm:** Version 4.66.1
- **datasets:** Version 2.25.0
- **torch:** Version 2.1.1
- **torchvision:** Version 0.16.1

## Dataset Requirements
`fashion_mnist` will be downloaded from the Hugging Face Hub.