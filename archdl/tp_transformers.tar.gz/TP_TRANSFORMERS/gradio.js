// Set the favicon to PIE's logo
{
    let element = document.querySelector("#favicon_placeholder img");
    document.querySelector("link[rel=icon]").href = element.src;
}

for (let element of document.getElementsByClassName("idris_icon"))
    element.classList.remove("block");



// Cupidon textarea submit to button submit. Only activate rank and clipboard buttons
// after submission.
{
    let submit_button = document.getElementById("submit_to_pie_btn");

    // Make sure that using Shift-Enter or Ctrl-Enter does submit, exactly like
    // clicking the submit button.
    document.getElementById("text_input").addEventListener("keydown", (ev) => {
        if (ev.key === "Enter" && (ev.shiftKey || ev.ctrlKey))
            submit_button.dispatchEvent(new Event("click"));
    });
}
