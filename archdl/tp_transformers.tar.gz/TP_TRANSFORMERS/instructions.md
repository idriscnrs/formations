# Practical Introduction to Deep Learning

## Transformers Practical Labs

In this practical lab, you can play with generation parameters to better understand how large language models generate their answers.

We offer a few parameters to change in the following accordion:

* Activate or deactivate sampling mode (i.e. random draws)
* Max length: the maximum total length (includes the prompt)
* Number of beams: for beam search
* Temperature: in sampling mode, smoothens probabilities to choose between a rather greedy, or a completely random generation. Only in beam searches, ignored otherwise
* top_k: Only the first k words (in terms of likelihood) are considered in sampling mode. Only in beam searches, ignored otherwise
* top_p: Only the first set of words whose cumulative likelihood is above top_p are considered in sampling mode (higher means more words considered). Only in beam searches, ignored otherwise
* Length penalty: Encourages or penalizes longer sequences. Can be negative. Higher means longer sequences. Only in beam searches, ignored otherwise

Additionally, you have two textboxes. The first is the system template, which explains how the language model should answer ; second is your prompt.

To better understand the role of the system template, how about trying this one:

* System template: "Speak as if you were a pirate."
* User prompt: "What is the Cayley-Hamilton theorem ?"

The generated answers should be convincing :)


Do not hesitate to play with parameters to see how they work, when do you have more diverse generations, change the template, the prompt, etc. Don't hesitate to ask questions to IDRIS' teachers if you need any clarification.