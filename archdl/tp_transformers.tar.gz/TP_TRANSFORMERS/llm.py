#! /usr/bin/env python3
# -*- coding: utf-8 -*-

import gradio as gr
import random
import torch
from argparse import ArgumentParser
from pathlib import Path
from PIL import Image
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    GenerationConfig,
    GenerationMixin,
)

from theme import Theme_IDRIS


parser = ArgumentParser()
parser.add_argument("--port", type=int, default=random.randint(10000, 30000))
server_port: int = parser.parse_args().port
print(f"Port: {server_port}")
num_outputs = 4

logo_idris = Image.open(Path.cwd() / "logo_idris.png")
logo_idris = logo_idris.crop(logo_idris.getbbox())
favicon = logo_idris.resize((32, 32))

css = (Path.cwd() / "gradio.css").read_text()
js = (Path.cwd() / "gradio.js").read_text()
html = (Path.cwd() / "gradio.html").read_text()
instructions = (Path.cwd() / "instructions.md").read_text()

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

pretrained_folder = Path("/work/zephyr-7b-beta")
model: GenerationMixin = AutoModelForCausalLM.from_pretrained(
    pretrained_folder, use_safetensors=True
).to(device)
tokenizer = AutoTokenizer.from_pretrained(pretrained_folder)

system_default_template = "You are a friendly chatbot."


def predict(
    input: str,
    system_template: str,
    max_length: int,
    do_sample: bool,
    num_beams: int,
    temperature: float,
    top_k: int,
    top_p: float,
    length_penalty: float
):
    system = {
        "role": "system",
        "content": system_template if len(system_template) > 0 else system_default_template,
    }
    user_inp = {"role": "user", "content": input}

    prompt = tokenizer.apply_chat_template([system, user_inp], tokenize=False, add_generation_prompt=True)
    tokenized: torch.Tensor = tokenizer([prompt], return_tensors="pt")["input_ids"]
    tokenized = tokenized.to(device)

    config = dict(
        max_length=max_length,
        early_stopping=False,
        do_sample=do_sample,
        num_beams=num_beams,
        temperature=float(temperature),
        length_penalty=length_penalty,
        num_return_sequences=num_outputs,
        bos_token_id=1,
        eos_token_id=2,
        pad_token_id=0,
        repetition_penalty=2.0,
    )
    if not do_sample:
        if num_beams > 1:
            config["num_beam_groups"] = num_beams
            config["diversity_penalty"] = 1.0
        elif num_beams == 1:
            config["num_return_sequences"] = 1
    if top_k > -1:
        config["top_k"] = top_k
    if top_p != 1:
        config["top_p"] = top_p

    output = model.generate(tokenized, generation_config=GenerationConfig(**config))
    texts_out = tokenizer.batch_decode(output, skip_special_tokens=True)
    
    texts_out = [
        text_out.split("<|assistant|>")[1].strip()
        for text_out in texts_out
    ]
    if not do_sample and num_beams == 1:
        texts_out = [texts_out[0]] * num_outputs
    return texts_out

with gr.Blocks(title="LLM", css=css, js=f"() => {{{js}}}", theme=Theme_IDRIS()) as demo:
    gr.Image(
        favicon,
        show_label=False,
        show_download_button=False,
        show_share_button=False,
        visible=False,
        elem_id="favicon_placeholder",
    )

    gr.Image(
        logo_idris,
        show_label=False,
        show_download_button=False,
        show_share_button=False,
        elem_classes="idris_icon",
    )

    gr.Markdown(instructions)

    
    system_template = gr.Textbox(
        lines=7,
        placeholder="Template",
        label="System template",
        interactive=True,
    )
    
    text_input = gr.Textbox(
        lines=7,
        placeholder="Request",
        label="Input",
        interactive=True,
        elem_id="text_input",
    )

    with gr.Accordion(label="Generation options", open=False):
        with gr.Column():
            do_sample = gr.Checkbox(value=False, label="Sampling mode")
            with gr.Row():
                max_length = gr.Number(value=500, label="Max Length", minimum=1)
                num_beams = gr.Number(label="Number of beams (in beam search)", minimum=1, value=5)
                temperature = gr.Number(label="Temperature", value=0.2, minimum=0, step=0.1)
            with gr.Row():
                top_k = gr.Number(label="Top k", minimum=-1, step=1, value=-1)
                top_p = gr.Number(label="Top pOnly considers words whose cumulated probability higher than", minimum=0, step=0.05, maximum=1, value=1)
                length_penalty = gr.Number(label="Length penalty (can be negative, higher means longer generations)", value=0.0, step=0.1)

    with gr.Row():
        with gr.Column(scale=10):
            pass
        with gr.Column(scale=1, min_width=200):
            clear_button = gr.ClearButton([text_input], "Clear", elem_id="clear_btn")
        with gr.Column(scale=1, min_width=200):
            submit_button = gr.Button("Submit", elem_id="submit_to_pie_btn")

    with gr.Row():
        outs = [
            gr.Textbox(
                lines=15,
                label=f"Output {i + 1}",
                interactive=True,
                elem_id=f"Textbox_output{i}",
                elem_classes=["Textbox_output"],
            )
            for i in range(num_outputs)
        ]
        clear_button.add(outs)

    submit_button.click(
        fn=predict,
        inputs=[text_input, system_template, max_length, do_sample, num_beams, temperature, top_k, top_p, length_penalty],
        outputs=outs,
    )

    gr.HTML(html)

demo.launch(
    server_port=server_port,
    debug=True,
    show_error=True,
    share=False,
    app_kwargs={"openapi_url": f"/{server_port}/info"},
)
