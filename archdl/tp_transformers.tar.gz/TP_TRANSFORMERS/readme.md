## Installations nécessaires

* gradio
* torch
* transformers


## Modèle nécessaire

* Zephyr-7b-beta : https://huggingface.co/HuggingFaceH4/zephyr-7b-beta
