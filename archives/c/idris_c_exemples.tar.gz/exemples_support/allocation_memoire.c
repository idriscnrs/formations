#include <stdio.h>
#include <stdlib.h>
typedef struct { int nb; float *ptr; } TAB_REEL;
#define TAILLE 100

main()
{
   TAB_REEL *p; int i;
   p = (TAB_REEL *)calloc(TAILLE, sizeof(TAB_REEL));
   if (!p) {
     fprintf(stderr, "Erreur a l'allocation\n\n");
     exit(1);
   }
   for (i=0; i<TAILLE; i++) {
      p[i].nb  = TAILLE;
      p[i].ptr = (float *)malloc(p[i].nb*
                                 sizeof(float));
      p[i].ptr[i] = 3.14159f;
   }
   for (i=0; i<TAILLE; i++) free(p[i].ptr);
   free(p);

   return 0;
}
