#include <stdio.h>
main()
{
   int chiffre = 0;

   printf("Boucle \"while\"\n\n");
   while (chiffre)
   {
      printf(" %d", chiffre++);
      if (!(chiffre%5))
        printf("\n");
   }
   printf("Boucle \"do-while\"\n\n");
   do
   {
      printf(" %3d", ++chiffre);
      if (!(chiffre%5))
        printf("\n");
      if (chiffre == 100)
        chiffre = 0;
   }
   while (chiffre);
   return 0;
}
