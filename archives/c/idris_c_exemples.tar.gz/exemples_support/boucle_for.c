main()
{
  int   tab[] = {1, 2, 9, 10, 7, 8, 11};
  int   i, j;
  char  buffer[] = "Voici une chaine"
                   " qui se termine "
                   "par un blanc ";
  char *p;
  int   t[4][3];

  for (i=0; i<sizeof tab / sizeof tab[0]; i++)
     printf("tab[%d] = %d\n", i, tab[i]);

  for (p=buffer; *p; p++)
       ;
  *--p = '\0';
  printf("buffer : %s$\n", buffer);
  for (i=0; i<4; i++)
    for (j=0; j<3; j++)
      t[i][j] = i + j;

  return 0;
}
