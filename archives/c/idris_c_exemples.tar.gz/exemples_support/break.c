#include <stdio.h>
main()
{
   char  buffer[] = "Wolfgang Amadeus Mozart\n"
                    " est un musicien divin.\n";
   char *p;

   for (p=buffer; *p; p++)
     if (*p == '\n') 
     {
       *p = '\0';
       break;
     }
   printf("Nom : %s\n", buffer);

   return 0;
}
