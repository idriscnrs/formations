#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv)
{
   void usage (char *s);
   char *s  = "/usr/include/string.h", *p;
   int   NbSlash = 0;
   if (argc != 3) usage(argv[0]);
   if (!strcmp(argv[1], argv[2]))
     printf("Les 2 arguments sont identiques.\n");
   else if (strcmp(argv[1], argv[2]) > 0)
       printf("arg1 > arg2\n");
   else printf("arg1 < arg2\n");
   for (p = s-1; p = strchr(++p, '/'); NbSlash++)
              ;
   printf("La cha�ne s contient %d\n", NbSlash);
   printf("slashs sur %d caract�res.\n", strlen(s));
}

void usage (char *s)
{
   fprintf(stderr, "usage : %s ch1 ch2.\n", s);
   exit(1);
}
