#include <stdio.h>
#include <stdlib.h>
#include <string.h>

main(int argc, char **argv)
{
   char *parm1, *parm2, buffer[BUFSIZ];

   if (argc != 3) usage(argv[0]);
   parm1 = strdup(argv[1]);
   parm2 = strdup(argv[2]);
   strcat(strcpy(buffer, "R�sultat de la concat�nation : "), parm1);
   strcat(strcat(buffer, parm2), "\n");
   printf("%s", buffer);
   sprintf(buffer, "%s%s%s\n", "R�sultat de la concat�nation : ", parm1, parm2);
   printf("%s", buffer);
   free(parm1); free(parm2);
}

void usage (char *s)
{
   fprintf(stderr, "usage : %s ch1 ch2.\n", s);
   exit(1);
}
