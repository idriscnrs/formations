#include <stdio.h>
main()
{
  char *buffer = "\nCeci est une chaine\n"
                 "de caracteres\tsur\n\n"
                 "plusieurs     lignes.\n";
  int   NbCar  = 0, NbEsp = 0, NbLignes = 0;
  
  for (; *buffer; buffer++) {
    switch (*buffer) {
      case '\n': NbLignes++;
                 break;
      case '\t': continue;
      case ' ' : NbEsp++;
      default  : break;
    }
    NbCar++;
  }
  printf("NbCar = %d, NbEsp = %d, NbLignes = %d\n",     
          NbCar, NbEsp, NbLignes);

  return 0;
}
