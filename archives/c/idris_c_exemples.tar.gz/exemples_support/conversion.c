#include <stdio.h>
#include <stdlib.h>
main()
{
  char *s = "     37.657a54";
  char *cerr;

  printf("%f\n", strtod(s, &cerr));
  if (*cerr != '\0')
    fprintf(stderr,
	    "Caractere errone : %c\n", *cerr);
  s = "11001110101110";
  printf("%ld\n", strtol(s, NULL, 2));
  s = "0x7fff";
  printf("%ld\n", strtol(s, NULL, 0));
  s = "0777";
  printf("%ld\n", strtol(s, NULL, 0));
  s = "777";
  printf("%ld\n", strtol(s, NULL, 0));

  return 0;
}
