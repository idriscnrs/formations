#include <stdio.h>
#include <time.h>
main()
{
   time_t t;
   struct tm *tm;

   time(&t);
   puts(ctime(&t));
   tm = localtime(&t);
   puts(asctime(tm));
   tm->tm_year = 94;
   tm->tm_mday = 16;
   tm->tm_mon  = 10;

/*
   Surtout pas d'appel a "asctime" ici car tous
   les champs de la structure "tm" seraient utilises!
   Or ils ne sont pas coherents.
*/

   t = mktime(tm); /* Attention ici on obtient eventuellement un
                      decalage d'1 Heure  du au changement d'heure
                      (heure d'hiver, heure d'ete). */
   puts(ctime(&t));
   t -= 20*86400;
   puts(ctime(&t));

   return 0;
}
