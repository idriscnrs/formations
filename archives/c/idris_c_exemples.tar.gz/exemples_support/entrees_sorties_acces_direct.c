#include <stdio.h>
#include <stdlib.h>

main(int argc, char **argv)
{
   FILE *f;
   void  usage(char *s);

   if (argc != 2)
     usage(argv[0]);
   if ((f = fopen(argv[1], "r")) == NULL)
   {
     perror("fopen");
     exit(2);
   }
   fseek(f, 0L, SEEK_END);
   printf("Taille(octets) : %d\n", ftell(f));
   fclose(f);
}

void  usage(char *s)
{
   fprintf(stderr, "usage : %s fichier\n", s);
   exit(1);
}
