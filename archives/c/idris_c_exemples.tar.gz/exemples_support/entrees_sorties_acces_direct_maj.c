#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>
#define NbElements(t) sizeof t / sizeof t[0]

int main( int argc, char **argv )
{
  void  conversion(char *nom, char *mode);
  FILE *f;
  char  nom[100];
  char *mus[] = { "Frédéric Chopin\n", "Maurice Ravel\n", };

  if( argc != 2 ) exit( 1 );
  if( (f=fopen(argv[1], "r+")) == NULL )
  {
    if( errno != ENOENT ||
        (f=fopen(argv[1], "w+")) == NULL )
    {
      perror( "fopen" );
      exit( 2 );
    }
  }
  fgets( nom, 100, f );
  while( ! feof( f ) )
  {
    fseek( f, -1L*strlen(nom), SEEK_CUR );
    conversion( nom, "majuscule" );
    fputs( nom, f );
    fseek( f, 0L, SEEK_CUR );
    fgets( nom, 100, f );
  }
  for( int n=0; n<NbElements(mus); n++ )
    fputs( mus[n], f );
  fclose( f );
}

void conversion( char *nom, char *mode )
{
  int (*conv)(int);

  if( ! strcmp( mode, "majuscule" ) )      conv = toupper;
  else if( ! strcmp( mode, "minuscule" ) ) conv = tolower;
  for( char *ptr=nom; *ptr++=conv(*ptr); )
     ;
  return;
}
