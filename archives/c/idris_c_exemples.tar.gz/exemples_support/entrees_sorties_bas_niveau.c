#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

int main()
{
  int  fde, fds;
  char buffer[BUFSIZ];
  int  nlus;

  if ((fde = open("entrees_sorties_bas_niveau.in", O_RDONLY)) == -1)
  {
    perror("open");
    exit(1);
  }
  if ((fds = creat("entrees_sorties_bas_niveau.out", 0644)) == -1)
  {
    perror("creat");
    exit(2);
  }

  while(nlus = read(fde, buffer, sizeof(buffer)))
     write(fds, buffer, nlus);

  close(fde), close(fds);

  return 0;
}
