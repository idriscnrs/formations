#include <stdio.h>
#include <stdlib.h>
#define NbElt(t) ( sizeof t / sizeof t[0] )

int main()
{
  typedef struct { int   n; float t[10]; char  c;
                 } DONNEE;
  DONNEE s1   = { 1, { 1.,  2., 3.}, 'a'};
  DONNEE s2[] = { {4, {10., 32., 3.}, 'z'}, {5, { 2., 11., 2., 4.}, 'h'} };

  FILE *f, *f_sauve; DONNEE s;
  if ((f = fopen("donnee_204", "w")) == NULL)
    perror("fopen"), exit(1);
  fwrite(&s1, sizeof(DONNEE), 1, f);
  fwrite(s2, sizeof(DONNEE), NbElt(s2), f);
  fclose(f);

  if ((f = fopen("donnee_204", "r")) == NULL ||
      (f_sauve = fopen("sauvegarde_204", "w")) ==  NULL)
    perror("fopen"), exit(1);

  fread(&s, sizeof(DONNEE), 1, f);
  while (!feof(f))
  {
    fwrite(&s, sizeof(DONNEE), 1, f_sauve);
    fread(&s, sizeof(DONNEE), 1, f);
  }
  fclose(f); fclose(f_sauve);

  return 0;
}
