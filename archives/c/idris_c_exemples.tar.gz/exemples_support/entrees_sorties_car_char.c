#include <stdio.h>
main()
{
  char c;  <=== Attention Erreur !
                ----------------

  while ((c = getchar()) != EOF)
     putchar(c);
}
