#include <stdio.h>
main()
{
  int c;

  while ((c = getchar()) != EOF)
    putchar(c);

  clearerr( stdin );

  c = getchar();
  while (!ferror(stdin) &&
         !feof(stdin)) {
    putchar(c);
    c = getchar();
  }

  return 0;
}
