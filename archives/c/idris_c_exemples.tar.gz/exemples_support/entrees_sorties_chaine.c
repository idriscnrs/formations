#include <stdio.h>
#include <stdlib.h>

int main()
{
  char *mus1 = "Wolfgang Amadeus Mozart\n";
  char *mus2 = "Ludwig van Beethoven\n";
  char  buffer[BUFSIZ+1];
  FILE *f;

  if ((f = fopen("musiciens_202", "w")) == NULL)
  {
    perror("fopen");
    exit(1);
  }
  fputs(mus1, f);
  fputs(mus2, f);
  fclose(f);
  if ((f = fopen("musiciens_202", "r")) == NULL)
  {
    perror("fopen");
    exit(2);
  }

  while (fgets(buffer, sizeof(buffer), f))
     fputs(buffer, stdout);
  fclose(f);
  puts("\nExecution terminee.");

  return 0;
}
