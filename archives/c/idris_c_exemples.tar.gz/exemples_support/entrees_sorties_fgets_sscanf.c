#include <stdio.h>
#include <stdlib.h>

int main()
{
  char   mois[10];
  char   buffer[BUFSIZ];
  int    quantite;
  double prix;
  FILE  *f;

  if ((f=fopen("entrees_sorties_fgets_sscanf.in", "r")) == NULL)
    perror("fopen"), exit(1);

  fgets(buffer, sizeof(buffer), f);
  while (!feof(f))
  {
    sscanf(buffer, "%s%d%lf", mois, &quantite, &prix);
    printf("mois : %s, qte : %d, prix : %f\n",
            mois, quantite, prix);
    fgets(buffer, sizeof(buffer), f);
  }

  fseek(f, 0l, SEEK_SET);
  fscanf(f, "%s%d%lf", mois, &quantite, &prix);
  while (!feof(f))
  {
    printf("mois : %s, qte : %d, prix : %f\n",
            mois, quantite, prix);
    fscanf(f, "%s%d%lf", mois, &quantite, &prix);
  }
  fclose(f);

  return 0;
}
