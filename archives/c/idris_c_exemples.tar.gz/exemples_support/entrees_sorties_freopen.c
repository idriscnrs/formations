#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
  void usage(char *s);

  if (argc != 2)
    usage(argv[0]);
  if (freopen(argv[1], "w", stdout) == NULL) {
    perror("freopen");
    exit(2);
  }
  printf("Ce message est redirig� ");
  printf("dans le fichier ");
  printf("dont le nom est ");
  printf("pass� en argument.\n");
}

void usage(char *s)
{
  fprintf(stderr, "usage : %s fichier\n", s);
  exit(1);
}
