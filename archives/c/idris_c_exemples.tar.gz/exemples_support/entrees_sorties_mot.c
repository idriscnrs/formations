#include <stdio.h>
#include <stdlib.h>
#define DIM 100

int main()
{
   FILE *flot;
   int   tab[DIM];
   int   i;

   if ((flot = fopen("resultat_199", "w")) == NULL)
   {
     perror("fopen");
     exit(1);
   }
   for (i=0; i<DIM; i++)
   {
      tab[i] = i*i;
      putw(tab[i], flot);
   }
   fclose(flot);

   return 0;
}
