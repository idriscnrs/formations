#include <stdio.h>
main()
{
  char *chaine = "Wolfgang Amadeus Mozart";

  printf("$%s$\n", chaine);
  printf("$%.16s$\n", chaine);
  printf("$%-22.16s$\n", chaine);
  printf("$%22.16s$\n", chaine);

  return 0;
}
