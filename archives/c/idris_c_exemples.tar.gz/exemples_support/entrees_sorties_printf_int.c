#include <stdio.h>
main()
{
  printf("|%d|\n",     1234);
  printf("|%-d|\n",    1234);
  printf("|%+d|\n",    1234);
  printf("|% d|\n",    1234);
  printf("|%10d|\n",   1234);
  printf("|%10.6d|\n", 1234);
  printf("|%10.2d|\n", 1234);
  printf("|%.6d|\n",   1234);
  printf("|%06d|\n",   1234);
  printf("|%.2d|\n",   1234);
  printf("|%*.6d|\n",  10, 1234);
  printf("|%*.*d|\n",  10, 6, 1234);
  printf("|%x|\n",     0x56ab);
  printf("|%#x|\n",    0x56ab);
  printf("|%X|\n",     0x56ab);
  printf("|%#X|\n",    0x56ab);

  return 0;
}
