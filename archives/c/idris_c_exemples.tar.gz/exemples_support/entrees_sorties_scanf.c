#include <stdio.h>
main()
{
  int   i;
  float x, y;
  char  buffer[BUFSIZ];
  char *p = "12/11/94";
  int   jour, mois, annee;

  scanf("%d%f%f%*c", &i, &x, &y);
  printf("i = %d, x = %f, y = %f\n", i, x, y);
  scanf("%[^\n]%*c", buffer);
  while (!feof(stdin)) {
    fprintf(stderr, "%s\n", buffer);
    scanf("%[^\n]%*c", buffer);
  }
  sscanf(p, "%d/%d/%d", &jour, &mois, &annee);
  printf("jour  : %d\n", jour);
  printf("mois  : %d\n", mois);
  printf("annee : %d\n", annee);
}
