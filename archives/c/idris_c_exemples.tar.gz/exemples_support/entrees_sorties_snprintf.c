#include <stdio.h>
int main( int argc, char *argv[] )
{
  char buffer[1024];
  int  n, taille_dispo;

  taille_dispo = sizeof buffer;
  n = snprintf( buffer, taille_dispo, "Commande lancée ==> " );
  for( int i=0; i<argc; i++ )
  {
    taille_dispo = sizeof buffer - n;
    n += snprintf( buffer+n, taille_dispo, " %s", argv[i] );
  }
  printf( "%s\n", buffer );

  return 0;
}
