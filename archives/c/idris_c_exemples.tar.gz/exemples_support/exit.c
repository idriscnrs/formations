#include <stdio.h>
#include <stdlib.h>

int main()
{
   int tab[][4] = {1, 2, 8, 9, 10, 12, 1, 9, 5};
   int i, j;
   double x;

   for (i=0; i<sizeof tab / sizeof tab[0]; i++)
     for (j=0; j<4; j++)
       if (tab[i][j] == 10) {
         printf("L'element tab[%d][%d]"
                " est egal a 10.\n", i, j);
         return 0;
       }
   fprintf(stderr, "Element non trouve.\n");
   exit(1);
}
