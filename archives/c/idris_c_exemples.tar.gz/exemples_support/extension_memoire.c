#include <stdio.h>
#include <stdlib.h>
main()
{
  char **ptr = (char **)NULL;
  char   buffer[BUFSIZ];
  int    nb = 0, i;

  for (;;) {
    printf("Entrer une chaine : ");
    scanf("%s", buffer);
    if (!strcmp(buffer, "fin"))
      break;
    ptr = (char **)realloc(ptr, ++nb*sizeof(char *));
    ptr[nb-1] = (char *)malloc((strlen(buffer)+1)*sizeof(char));
    strcpy(ptr[nb-1], buffer);
  }
  for (i=0; i<nb; i++) {
    printf("%s\n", ptr[i]);
    free(ptr[i]);
  }
  free(ptr);

  return 0;
}
