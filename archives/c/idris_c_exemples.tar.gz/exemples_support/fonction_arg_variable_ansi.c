#include <stdio.h>
#include <stdarg.h>
main()
{
   int moyenne(int nombre, ...);
   printf("moyenne = %d\n", moyenne(4, 1, 2, 3, 4));
   printf("moyenne = %d\n",
           moyenne(5, 1, 2, 3, 4, 5));

   return 0;
}

int moyenne(int nombre, ...)
{
   int     somme = 0, i;
   va_list arg;
   va_start(arg, nombre);
   for(i=0; i<nombre; i++)
     somme += va_arg(arg, int);
   va_end(arg);
   return somme/nombre;
}
