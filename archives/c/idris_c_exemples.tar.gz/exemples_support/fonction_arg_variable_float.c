#include <stdio.h>
#include <varargs.h>
main()
{
   float moyenne();

   printf("moyenne = %f\n",
           moyenne(4, 1.f, 2.f, 3.f, 4.f));
   printf("moyenne = %f\n",
           moyenne(5, 1.f, 2.f, 3.f, 4.f, 5.f));

   return 0;
}

float moyenne(nombre, va_alist)
int nombre;
va_dcl
{
   float   somme = 0.f;
   int     i;
   va_list arg;

   va_start(arg);
   for(i=0; i<nombre; i++)
     somme += va_arg(arg, double);
   va_end(arg);

   return somme/nombre;
}
