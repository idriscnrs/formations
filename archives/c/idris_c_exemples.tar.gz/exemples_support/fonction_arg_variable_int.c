#include <stdio.h>
#include <varargs.h>
main()
{
   float moyenne();

   printf("moyenne = %f\n",
           moyenne(4, 1, 2, 3, 4));
   printf("moyenne = %f\n",
           moyenne(5, 1, 2, 3, 4, 5));

   return 0;
}

float moyenne(nombre, va_alist)
int nombre;
va_dcl
{
   int     somme = 0, i;
   va_list arg;

   va_start(arg);
   for(i=0; i<nombre; i++)
     somme += va_arg(arg, int);
   va_end(arg);

   return (float)somme/nombre;
}
