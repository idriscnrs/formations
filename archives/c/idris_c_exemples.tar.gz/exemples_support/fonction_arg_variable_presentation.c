void fonction(int a, ...);
main()
{
   int i = 10, j = 11, k = 12;
   printf("Avant appel fonction i = %d\n", i);
   printf("Avant appel fonction j = %d\n", j);
   printf("Avant appel fonction k = %d\n", k);
   fonction(i, j, k);

   return 0;
}
void fonction(int a, ...)
{
   printf("Valeur de a = %d\n", a);
   printf("R�cup�ration de j = %d\n", *(&a + 1));
   printf("R�cup�ration de k = %d\n", *(&a + 2));
}
