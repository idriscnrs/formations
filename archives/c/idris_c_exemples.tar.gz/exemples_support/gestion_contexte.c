#include <stdio.h>
#include <setjmp.h>
jmp_buf cntx;
main()
{
  int appel_boucle();

  printf("Terminaison avec \"%c\"\n", appel_boucle());
}

int appel_boucle(void)
{
  void boucle(void);
  int  retour = setjmp(cntx);

  printf("setjmp retourne %d\n", retour);
  if (retour == 0) boucle();
  return retour;
}

void boucle(void)
{
  for (;;) {
    char getcmd(char *);
    char c = getcmd("-> ");

    switch(c) {
      case 'q': longjmp(cntx, c);
      default: printf("Traitement de %c\n", c);
      break;
    }
  }
}
char getcmd(char *s)
{
  char c = (printf("%s", s), getchar());

  while (getchar() != '\n')
      ;
  return c;
}
