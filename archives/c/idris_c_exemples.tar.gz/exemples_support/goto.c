#include <stdio.h>
main()
{
   int tab[][4] = {1, 2, 8, 9, 10, 12, 1, 9, 5};
   int i, j;
   double x;

   for (i=0; i<sizeof tab / sizeof tab[0]; i++)
     for (j=0; j<4; j++)
       if (tab[i][j] == 10)
         goto trouve;

   fprintf(stderr, "Element non trouve.\n");
   return 1;

trouve:
   printf("L'element tab[%d][%d]"
          " est egal a 10.\n", i, j);

   return 0;
}
