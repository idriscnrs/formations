#include <string.h>
#include <assert.h>
#define DIM 50
main()
{
   char tab[DIM];
   void f(char *p, int n);

   memset(tab, ' ', DIM);
   f(tab, DIM+1);

   return 0;
}

void f(char *p, int n)
{
   char *ptr = p;
   int   i;

   for (i=0; i<n; i++) {
     assert(ptr - p < DIM);
     *ptr++ = '$';
   }
}
