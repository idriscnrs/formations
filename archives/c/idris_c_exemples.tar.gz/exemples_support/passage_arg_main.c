#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv, char **envp)
{
   void usage(char *s);

   if (argc != 3)
     usage(argv[0]);
   for(; *argv; argv++)
     printf("%s\n", *argv);
   for(; *envp; envp++)
     printf("%s\n", *envp);
}

void usage(char *s)
{
   fprintf(stderr, "usage : %s arg1 arg2\n", s);
   exit(1);
}
