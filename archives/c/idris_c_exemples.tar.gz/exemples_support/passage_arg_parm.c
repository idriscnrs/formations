#include <stdio.h>
main()
{
   int a, b, c;
   void somme(int a, int b, int *c);

   a = 3;
   b = 8;
   somme(a, b, &c);
   printf("Somme de a et b : %d\n", c);
   
   return 0;
}

void somme(int a, int b, int *c)
{
   *c = a + b;

   return;
}
