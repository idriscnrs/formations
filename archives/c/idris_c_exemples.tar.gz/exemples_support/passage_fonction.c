double integrale(double b_inf, double b_sup,
                 int pas, double (*f)(double));
double carre(double x);
main()
{
   double b_inf, b_sup, aire;
   int    pas;

   b_inf = 1., b_sup = 6., pas = 200000;
   aire = integrale(b_inf, b_sup, pas, carre);
   printf("Aire : %lf\n", aire);

   return 0;
}

double integrale(double b_inf, double b_sup,
                 int pas, double (*f)(double))
{
   double surface, h;
   int    i;
  
   h = (b_sup - b_inf)/pas;
   surface = 0;
   for(i=0; i<pas; i++)
     surface += h*(*f)(b_inf+i*h);
   return surface;
}

double carre(double x) {return x*x;}
