#include <stdio.h>
#define NbElts(v) ( sizeof v / sizeof v[0] )

typedef struct
{
   float v[6];
} Vecteur;

main()
{
  Vecteur v = { {1.34f, 8.78f, 10.f,
                 0.f, 22.12f, 3.145f} };
  Vecteur inv;
  Vecteur inverse(Vecteur v, int n);
  int i, n = NbElts(v.v);

  inv = inverse(v, n);
  for (i=0; i<n; i++)
    printf("inv.v[%d] : %f\n", i, inv.v[i]);
}

Vecteur inverse(Vecteur v, int n)
{
  Vecteur w;
  int     i;

  for(i=0; i<n; i++)
    w.v[i] = v.v[i] ? 1./v.v[i] : 0.f;

  return w;
}
