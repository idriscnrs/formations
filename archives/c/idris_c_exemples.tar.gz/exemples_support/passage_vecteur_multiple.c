#define NbElements(t) sizeof t / sizeof t[0]
#include <stdio.h>
main()
{
   int tab[][5] = {
                     { 4, 7, 1, 9, 6},
                     { 5, 9, 3, 4, 2},
                     { 2, 9, 5, 9, 13}
                  };
   int somme(int (*t)[5], int n);

   printf("Somme des elements de tab : %d\n",
           somme(tab, NbElements(tab)));

   return 0;
}
int somme(int (*t)[5], int n)
{
   int i;
   int som = 0;
   int (*p)[5] = t;
   for(; t-p<n; t++)  
     for (i=0; i<5; i++)
        som += (*t)[i];
   return som;
}
