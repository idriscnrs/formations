#define NbElements(t) sizeof t / sizeof t[0]
#define M 5
#include <stdio.h>
int main()
{
  int tab[][M] = { { 4, 7, 1, 9, 6},
                   { 5, 9, 3, 4, 2},
                   { 2, 9, 5, 9, 13} };
  int somme( int n, int m, int t[n][m] );

  printf( "Somme des éléments de tab : %d\n",
             somme(NbElements(tab), M, tab) );

  return 0;
}
int somme( int n, int m, int t[n][m] )
{
  int som;

  som = 0;
  for (int i=0; i<n; i++)
    for (int j=0; j<m; j++)
      som += t[i][j];

  return som;
}
