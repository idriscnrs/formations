#define NbElements(t) sizeof t / sizeof t[0]
#include <stdio.h>
main()
{
   int  tab[] = { 1, 9, 10, 14, 18};
   int  somme(int t[], int n);
   void impression(int *t, int n);

   printf("%d\n", somme(tab, NbElements(tab)));
   impression(tab, NbElements(tab));
   return 0;
}
int  somme(int t[], int n)
{
   int i, som = 0;

   for (i=0; i<n; i++) som += t[i];
   return som;
}
void impression(int *t, int n)
{
   int i=0, *p;

   for (p=t; t-p<n; t++)
      printf("t[%d] = %d\n", i++, *t);
}
