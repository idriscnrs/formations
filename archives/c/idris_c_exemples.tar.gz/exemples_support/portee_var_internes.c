#include <stdio.h>
main()
{
  int a = 1, b = 2;
  printf("a = %d, b = %d\n", ++a, ++b);
  {
     char b = 'A'; int x = 10;
     printf("a = %d, b = %c, x = %d\n",
             ++a, ++b, ++x);
     {
        int a = 100, y = 200;
        printf("a = %d, b = %c, x = %d, y = %d\n",
                ++a, ++b, ++x, ++y);
        {
           char a = 'L'; int z = -5;
           printf("a = %c, b = %c, x = %d, y = %d, z = %d\n",
                   ++a, ++b, ++x, ++y, ++z);
        }
        printf("a = %d, b = %c, x = %d, y = %d\n",
                ++a, ++b, ++x, ++y);
     }
     printf("a = %d, b = %c, x = %d\n",
             ++a, ++b, ++x);
  }

  return 0;
}
