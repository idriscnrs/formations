#define  TAILLE 256
#define  TAILLE_EN_OCTETS \
         TAILLE*sizeof(int)
main()
{
   int  tab[TAILLE];
   int  i;

   for(i=0; i<TAILLE; i++)
     tab[i] = i;
   printf("Le tableau tab contient %d octets\n",
          TAILLE_EN_OCTETS);

   return 0;
}
