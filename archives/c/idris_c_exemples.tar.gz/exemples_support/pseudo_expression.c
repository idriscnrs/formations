#define TBLOC 256
#if !defined TAILLE
#  define TAILLE TBLOC
#endif

#if TAILLE%TBLOC == 0
#  define TAILLEMAX TAILLE
#else
#  define TAILLEMAX ((TAILLE/TBLOC+1)*TBLOC)
#endif

static char buffer[TAILLEMAX];

main()
{
  printf("Taille du vecteur : %d caracteres\n",
          sizeof buffer);

  return 0;
}
