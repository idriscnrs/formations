#define ABS(x) x>0 ? x : -x
#define NB_ELEMENTS(t) sizeof t / sizeof t[0]
#include <stdio.h>
#include <math.h>
main()
{
  int    tab[][2] = { 1,  2,  3,  9,
                     10, 11, 13, 16};
  double r = -acos(-1.);
  int    i, j;

  for(i=0; i < NB_ELEMENTS(tab); i++)
    for(j=0; j < 2; j++)
      tab[i][j] = i + j;

  printf("%f\n", ABS(r));
}
