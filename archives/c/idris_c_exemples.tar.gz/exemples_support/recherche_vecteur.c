#include <stdio.h>
#include <string.h>
#include <stdlib.h>
main(int argc, char **argv)
{
   int cmp(const void *key, const void *elt);
   int tab[] = {10, 8, 7, 4, 2, 1, 0};
   int *ptr;
   int NbElt = sizeof tab / sizeof tab[0];
   int key = (int)strtol(argv[1], NULL, 0);
   ptr = bsearch(&key, tab, NbElt,
                           sizeof(int), cmp);
   if (ptr)
     printf("Rg de l'�lt rech. : %d\n", ptr-tab+1);
}
int cmp(const void *key, const void *elt)
{
   if (*(int *)key < *(int *)elt)
     return 1;
   else if (*(int *)key > *(int *)elt)
     return -1;
   else return 0;
}
