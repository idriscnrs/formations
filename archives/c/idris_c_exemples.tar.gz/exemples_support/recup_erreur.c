#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>

int main()
{
  FILE *f;

  if ((f=fopen("ExistePas", "r")) == NULL)
  {
    perror("fopen");
    puts(strerror(errno));
    exit(1);
  }

  return 0;
}
