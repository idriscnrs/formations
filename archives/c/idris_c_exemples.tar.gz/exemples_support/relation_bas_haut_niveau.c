#include <stdio.h>
#include <stdlib.h>

int main()
{ int   fd;
  FILE *fe, *fs;
  char  buffer[BUFSIZ];

  if ((fd = creat("relation_bas_haut_niveau.out", 0644)) == -1)
  {
    perror("open"); exit(1);
  }
  write(fd, "abcdefg", 7);
  if ((fe = fopen("relation_bas_haut_niveau.in", "r")) == NULL)
  {
    perror("fopen"); exit(2);
  }
  printf("Descripteur du fichier \"relation_bas_haut_niveau.in\" : "
         "%d\n", fileno(fe));

  if ((fs = fdopen(fd, "w")) == NULL)
  {
    perror("fdopen"); exit(3);
  }
  fgets(buffer, sizeof buffer, fe);
  while (!feof(fe))$
  {
    fputs(buffer, fs);
    fgets(buffer, sizeof buffer, fe);
  }
  fclose(fe); fclose(fs);

  return 0;
}
