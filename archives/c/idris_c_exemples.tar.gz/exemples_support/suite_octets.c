#include <stdio.h>
#include <string.h>
main()
{
   char  buffer[100];
   char  tab[] = "Voici\0une chaine qui"
                 "\0\0contient\0des"
                 "\0caracteres \"null\".";
   char *p, *ptr;
   int   taille = sizeof tab / sizeof tab[0];
   int   n;

   memset(buffer, ' ', 100);
   memcpy(buffer, tab, taille);
   n = --taille;
   for (p=ptr=tab; p=memchr(ptr, '\0', n);)
   {
      *p = ' ';
      n -= p - ptr + 1;
      ptr = ++p;
   }
   printf("%s\n", buffer);
   printf("%.*s\n", taille, tab);

   return 0;
}
