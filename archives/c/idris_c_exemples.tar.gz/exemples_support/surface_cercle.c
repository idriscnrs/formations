#include <stdio.h>
#define PI 3.14159
/* calcul de la surface d'un cercle. */
main()
{
  float rayon, surface;
  float calcul(float rayon);

  printf("Rayon = ? ");
  scanf("%f", &rayon);
  surface = calcul(rayon);
  printf("Surface = %f\n", surface);

  return 0;
}

/* definition de fonction. */
float calcul(float r)
{
  float a;

  a = PI * r * r;
  return(a);
}
