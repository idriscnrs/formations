#include <stdio.h>
#include <ctype.h>
main()
{
   int c;
   int NbMaj = 0;
   int NbMin = 0;
   int NbNum = 0;
   int NbAutres = 0;

   while((c=getchar()) != EOF)
      if (isupper(c))
        NbMaj++;
      else if (islower(c))
        NbMin++;
      else if (isdigit(c))
        NbNum++;
      else
        NbAutres++;
   printf("NbMaj    : %d\n", NbMaj);
   printf("NbMin    : %d\n", NbMin);
   printf("NbNum    : %d\n", NbNum);
   printf("NbAutres : %d\n", NbAutres);

   return 0;
}
