#include <stdio.h>
#include <math.h>
main()
{
  double x, y;

  scanf("%lf", &x);
  y = log(x);
  printf("%f\n", y);
}
int matherr(struct exception *p)
{
  puts("erreur d�tect�e");
  printf(" type : %d\n", p->type);
  printf(" name : %s\n", p->name);
  printf(" arg1 : %f\n", p->arg1);
  printf(" arg2 : %f\n", p->arg2);
  printf(" valeur retourn�e : %f\n", p->retval);
  p->retval = -1.;
  return 0;
}
