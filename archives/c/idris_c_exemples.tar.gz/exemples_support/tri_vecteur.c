#include <stdio.h>
#include <stdlib.h>
main()
{
   int cmp(const void *elt1, const void *elt2);
   double tab[] = {3., 10., 6., 101.,
                   7., 11., 6., 14.};
   int    NbElt = sizeof tab / sizeof tab[0];
   int    i;

   qsort(tab, NbElt, sizeof(double), cmp);
   printf("Vecteur tab trie : \n");
   for (i=0; i<NbElt; i++)
     printf("%f\n", tab[i]); 

   return 0;
}

int cmp(const void *elt1, const void *elt2)
{
   if (*(double *)elt1 < *(double *)elt2)
     return 1;
   else if (*(double *)elt1 > *(double *)elt2)
     return -1;
   else return 0;
}
