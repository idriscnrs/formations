#include <stdio.h>
#include <stdlib.h>
#define RACINE        "RACINE"
#define DEFAUT_RACINE "."
main()
{
  char  *racine;

  if ((racine = getenv(RACINE)) == NULL)
    racine = DEFAUT_RACINE;
  printf("Repertoire de travail : \"%s\"\n", racine);

  return 0;
}
