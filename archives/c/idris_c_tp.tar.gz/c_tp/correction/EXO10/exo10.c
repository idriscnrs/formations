#include <stdio.h>
#include <stdarg.h>

typedef struct somme
{
  int    entiers;
  double reels;
} Somme;

int main()
{
  Somme sigma( int nb_couples, ... );
  Somme s;

  s = sigma( 4, 2, 3., 3, 10., 3, 5., 11, 132. );
  printf( " Somme des entiers : %d\n", s.entiers ); 
  printf( " Somme des r�els   : %f\n", s.reels ); 
  printf( "\t\t------------------\n" );
  s = sigma( 5, 2, 3., 3, 10., 3, 5., 11, 132., 121, 165. );
  printf( " Somme des entiers : %d\n", s.entiers );
  printf( " Somme des r�els   : %f\n", s.reels );

  printf( "\n\nFin EXO10.\n" );

  return 0;
}

Somme sigma( int nb_couples, ... )
{
  Somme   s;
  va_list arg;

  // Initialisation de "arg" avec l'adresse
  // de l'argument qui suit "nb_couples".
  // ("arg" pointe sur l'entier du 1er couple).

  va_start( arg, nb_couples );
  s.entiers = s.reels = 0;
  // Boucle de r�cup�ration des valeurs.
  for( int i=0; i<nb_couples; i++ )
  {
    s.entiers += va_arg( arg, int );
    s.reels   += va_arg( arg, double );
  }
  va_end( arg );

  return s;
}
