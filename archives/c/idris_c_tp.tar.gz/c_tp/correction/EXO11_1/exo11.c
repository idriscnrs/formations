#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void traitement_option( const unsigned char option );
void usage( char *s );

const unsigned char  option_a = 1;
const unsigned char  option_b = 2;
const unsigned char  option_c = 4;
const unsigned char  option_d = 8;
const unsigned char  option_e = 16;
const unsigned char  option_f = 32;
unsigned char        mask_options = 0;
char                *valeur_option = NULL, *fichier = NULL;
char                *module;

void bilan_options( void );

int main( int argc, char **argv )
{
  // Sauvegarde du nom de l'ex�cutable.
  module = strdup( *argv );

  // Boucle sur les arguments.
  while( *++argv != NULL )
  {
    // Est-ce que l'argument commence par le caract�re '-' ?

    if( (*argv)[0] == '-' )
    {
      // On analyse les caract�res qui suivent.
      for( (*argv)++; **argv; (*argv)++ )
      {
        switch( **argv )
        {
          case 'a':
            traitement_option( option_a );
            break;
          case 'b':
            traitement_option( option_b );
            break;
          case 'c': 
            traitement_option( option_c );
            break;
          case 'd':
            traitement_option( option_d );
            break;
          case 'e':
            traitement_option( option_e );
            break;
          case 'f':
            traitement_option( option_f );
            break;
          default : usage( module );
        }
        if ( **argv == 'a' || **argv == 'b' || **argv == 'c' ) 
        {
          // La valeur de l'option 'a', 'b' ou 'c' peut
          // suivre imm�diatement, ou bien �tre s�par�e
          // de l'option par des blancs.
          if( *++*argv != '\0' )
            valeur_option = strdup( *argv );
          // Cas o� aucune valeur ne suit.
          else if( (*++argv)[0] == '-' )
            usage( module );
          else
            valeur_option = strdup( *argv );
          break;
        }
      }
    }
    // L'argument ne commence pas par le caract�re '-'.
    else if( fichier != NULL )
      usage( module );
    else
      fichier = strdup( *argv );
  }

  bilan_options();

  printf( "\n\nFin EXO11.\n" );

  return 0;
}

void bilan_options( void )
{
  // L'option 'a', 'b', ou 'c' suivie d'une
  // cha�ne, ainsi qu'un nom de fichier
  // doivent �tre sp�cifi�s.

  if( valeur_option == NULL || fichier == NULL )
    usage( module );

  // Si aucune des options 'd', 'e', 'f'
  // n'a �t� sp�cifi�e, on les consid�re toutes.

  if( ! (mask_options & option_d) &&
      ! (mask_options & option_e) &&
      ! (mask_options & option_f) )
    mask_options |= option_d + option_e + option_f;

  if( mask_options & option_a )
    printf( "Option \"a\" fournie avec comme valeur : "
            "%s\n", valeur_option );
  if( mask_options & option_b )
    printf( "Option \"b\" fournie avec comme valeur : "
            "%s\n", valeur_option );
  if( mask_options & option_c )
    printf( "Option \"c\" fournie avec comme valeur : "
            "%s\n", valeur_option );
  printf( "Option \"d\" %s.\n",
           mask_options & option_d ? "active" : "inactive" );
  printf( "Option \"e\" %s.\n",
           mask_options & option_e ? "active" : "inactive" );
  printf( "Option \"f\" %s.\n",
           mask_options & option_f ? "active" : "inactive" );

  printf( "Nom du fichier indiqu� : %s\n", fichier );

  return;
}

void traitement_option( const unsigned char option )
{
  // Une seule des options "-a", "-b", "-c"
  // doit avoir �t� sp�cifi�e.

  if ( option == option_a ||
       option == option_b ||
       option == option_c )
    if ( valeur_option != NULL )
      usage( module );

  // On interdit qu'une option soit indiqu�e 2 fois.

  if ( mask_options & option )
    usage( module );
  else
    mask_options |= option;

  return;
}

void usage( char *s )
{
  const char * const message =
       "usage: %s -a chaine | -b chaine | -c chaine [-d -e -f] fichier\n";

  fprintf(stderr, message, s);
  exit(1);
}
