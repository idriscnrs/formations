#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>


typedef struct options
{
  char  nom[3];
  bool  option_fournie;
  bool  option_a_valeur;
  char *valeur;
} Option;
typedef enum { option_a, option_b, option_c,
               option_d, option_e, option_f,
               nb_options, option_invalide } option_t;

Option options[] = {
                     { "-a", false, true,  NULL },
                     { "-b", false, true,  NULL },
                     { "-c", false, true,  NULL },
                     { "-d", false, false, NULL },
                     { "-e", false, false, NULL },
                     { "-f", false, false, NULL }
                   };

option_t type_option( char *option );
void     bilan_options( void );
void     usage(char *s);

char *module, *fichier = NULL;

int main( int argc, char **argv )
{
  // Sauvegarde du nom de l'ex�cutable.
  module = strdup( *argv );

  // Boucle sur les arguments.
  while( *++argv != NULL )
  {
    // Est-ce que l'argument commence par le caract�re '-' ?

    if( (*argv)[0] == '-' )
    {
      option_t opt;

      opt = type_option( *argv );
      if( opt == option_invalide ) usage( module );
      if( options[opt].option_a_valeur )
      {
        *argv += strlen( options[opt].nom );
        if( argv[0][0] != '\0' )
          options[opt].valeur = strdup( *argv );
        // Cas o� aucune valeur ne suit.
        else if( (++argv)[0][0] == '-' )
          usage( module );
        else
          options[opt].valeur = strdup( *argv );
      }
    }
    else if( fichier != NULL )
      usage( module );
    else
      fichier = strdup( *argv );
  }

  bilan_options();

  printf( "\n\nFin EXO11.\n" );

  return 0;
}

option_t type_option( char *option )
{
  option_t rang;

  for( rang=0; rang<nb_options; rang++ )
    if ( ! strncmp( options[rang].nom, option, strlen( options[rang].nom ) ) &&
         ! options[rang].option_fournie )
      break;
  if ( rang == nb_options )
    return option_invalide;
  if ( strcmp( options[rang].nom, option ) != 0 && ! options[rang].option_a_valeur )
    return option_invalide;

  options[rang].option_fournie = true;

  return rang;
}

void bilan_options( void )
{
  option_t rang;

  // Une seule des options "-a", "-b", "-c"
  // doit avoir �t� sp�cifi�e ainsi qu'un
  // nom de fichier.

  if( options[option_a].option_fournie ^
      options[option_b].option_fournie ^
      options[option_c].option_fournie &&
      fichier != NULL )
  {
    if ( options[option_a].option_fournie &&
         options[option_b].option_fournie &&
         options[option_c].option_fournie ) usage( module );
    // Si aucune des options 'd', 'e', 'f'
    // n'a �t� sp�cifi�e, on les consid�re toutes.
    if( ! options[option_d].option_fournie &&
        ! options[option_e].option_fournie &&
        ! options[option_f].option_fournie )
      options[option_d].option_fournie =
      options[option_e].option_fournie =
      options[option_f].option_fournie = true;

    for( rang=0; rang<nb_options; rang++ )
      if ( options[rang].option_fournie )
      {
        if ( options[rang].option_a_valeur )
          printf( "Option %s fournie avec comme valeur : %s\n", options[rang].nom,
                                                                options[rang].valeur );
        else
          printf( "Option %s active.\n", options[rang].nom );
      }
      else if ( ! options[rang].option_a_valeur )
        printf( "Option %s inactive.\n", options[rang].nom );

    printf( "fichier indiqu� : %s\n", fichier );
  }
  else usage( module );

  return;
}

void usage( char *s )
{
  const char * const message =
       "usage: %s -a chaine | -b chaine | -c chaine [-d -e -f] fichier\n";

  fprintf(stderr, message, s);
  exit(1);
}
