#include <stdio.h>

int main()
{
  char  buffer[BUFSIZ];
  char *p;

  // Boucle de lecture sur l'entr�e standard
  // avec la cha�ne "--> " comme prompt.
  fputs( "--> ", stdout );
  gets( buffer );
  while( ! feof(stdin) )
  {
    // On se positionne � la fin du mot lu.
    for( p=buffer; *p; p++ );
    // Conversion du mot en "louchebem".
    p[0] = *buffer;
    *buffer = 'l';
    p[1] = 'e'; p[2] = 'm'; p[3] = '\0';
    puts( buffer );
    fputs( "--> ", stdout );
    gets( buffer );
  } 

  printf( "\n\nFin EXO12.\n" );

  return 0;
}
