#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main( int argc, char **argv )
{
  void   usage ( char *s );
  double myatof( char *s );

  // Y a-t-il un argument ?
  if( argc != 2 ) usage( argv[0] );
  // On imprime les r�sultats des fonctions
  // "atof" et "myatof" pour comparaison.
  printf( "%f\n", atof  ( argv[1] ) );
  printf( "%f\n", myatof( argv[1] ) );

  printf("\n\nFin EXO13.\n");

  return 0;
}

double myatof( char *s )
{
  long   nombre, signe;
  double exposant;

  exposant = 1.;
  nombre   = 0;
  // Saut des �ventuels caract�res
  // espace, tabulation et "newline"
  // situ�s en t�te.
  for( ; isspace( *s ); s++ )
      ;
  // Gestion du signe.
  signe = *s == '-' ? -1 : 1;
  *s == '-' || *s == '+' ? s++ : s;
  // Gestion de la partie enti�re.
  for( ; isdigit( *s ); s++ )
    nombre = nombre*10 + *s - '0';
  if( *s++ != '.' )
    return signe*nombre*exposant;
  // Gestion de la partie d�cimale.
  for( ; isdigit( *s ); s++ )
  {
    nombre = nombre*10 + *s - '0';
    exposant /= 10.;
  }

  return signe*nombre*exposant;
}

void usage( char *s )
{
  fprintf( stderr, "usage: %s nombre.\n", s );
  exit( 1 );
}
