#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* D�finitions de nouveaux types. */
typedef enum sens {arriere, avant} Sens;
typedef struct cellule
{
   char   *chaine;
   struct  cellule *ptr_precedent;
   struct  cellule *ptr_suivant;
} CEL;

void  liste ( CEL *p, Sens sens );
void  libere( CEL *p );
CEL  *debut = NULL;

int main()
{
  CEL  *ptr_courant = NULL;
  char  chaine[40];

  /*
   * Boucle de lecture sur l'entr�e standard
   * avec "--> " comme prompt.
   */
  fputs( "--> ", stdout );
  gets( chaine );
  while( ! feof( stdin ) )
  {
    /*
     * Si "la" est la cha�ne entr�e,
     * on liste les cha�nes d�j� saisies.
     */
    if( ! strcmp( chaine, "la" ) )
      liste( debut, avant );
    /*
     * Si "li" est la cha�ne entr�e,
     * on liste les cha�nes d�j� saisies
     * dans l'ordre inverse.
     */
    else if( ! strcmp( chaine, "li" ) )
      liste( ptr_courant, arriere );
    else
    {
      // C'est la 1�re cha�ne.
      if( debut == NULL )
      {
        debut = malloc( sizeof(CEL) );
        debut->ptr_precedent = NULL;
        ptr_courant = debut;
      }
      else
      {
        // C'est une cha�ne diff�rente de la 1�re.
        ptr_courant->ptr_suivant = malloc( sizeof(CEL) );
        ptr_courant->ptr_suivant->ptr_precedent = ptr_courant;
        ptr_courant = ptr_courant->ptr_suivant;
      }
      // On valorise le nouvel �l�ment de la liste.
      ptr_courant->chaine = strdup( chaine );
      ptr_courant->ptr_suivant = NULL;
    }
    fputs( "--> ", stdout );
    gets( chaine );
  }
  // On lib�re la liste.
  if( debut != NULL )
    libere( debut );

  printf( "\n\nFin EXO14.\n" );

  return 0;
}

// Fonction r�cursive d'affichage de la liste.
void liste( CEL *p, Sens sens )
{
  if( debut == NULL )
  {
    printf( "D�sol�! la liste est vide.\n\n" );
    return;
  }
  if ( p != NULL )
  {
    printf( "\t%s\n", p->chaine );
    liste( sens == avant ?
              p->ptr_suivant : p->ptr_precedent, sens );
  }

  return;
}

// Fonction lib�rant la m�moire occup�e par la liste.
void libere( CEL *p )
{
  if ( p->ptr_suivant != NULL )
    libere( p->ptr_suivant );

  free( p->chaine );
  free( p );

  return;
}
