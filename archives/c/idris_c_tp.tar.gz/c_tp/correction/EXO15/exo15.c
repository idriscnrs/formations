#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
  typedef struct index
  {
     unsigned int debut;
     unsigned int longueur;
  } INDEX;
  FILE  *mus, *ind, *musind;
  char   buffer[BUFSIZ];
  INDEX  index;

  // Ouverture du fichier texte "musiciens".
  if( (mus = fopen( "musiciens", "r" )) == NULL )
  {
    perror( "fopen" );
    exit(1);
  }
  /*
   * Ouverture en �criture du fichier
   * des musiciens index�.
   */
  if( (musind = fopen( "musiciens.indexe", "w" )) == NULL )
  {
    perror( "fopen" );
    exit(2);
  }
  // Ouverture en �criture du fichier d'index.
  if( (ind = fopen( "musiciens.index", "w" )) == NULL )
  {
    perror( "fopen" );
    exit(3);
  }

  index.debut = ftell( mus );
  // Boucle de lecture du fichier des musiciens.
  fgets( buffer, sizeof buffer, mus );   
  while( ! feof(mus) )
  {
    /*static int n = 0;*/  /* nombre de caract�res "newline". */

    // On supprime le caract�re "newline".
    buffer[strlen( buffer )-1] = '\0'; /*n++; */
    fputs( buffer, musind );
    index.longueur = strlen( buffer );
    fwrite( &index, sizeof index, 1, ind ); 
    // Mise � jour de la position pour l'it�ration suivante.
    /*
    index.debut = ftell( mus ) - n;
     */
    index.debut = ftell( musind );
    fgets( buffer, sizeof buffer, mus );
  }
  // Fermeture des fichiers.
  fclose( ind ); fclose( musind ); fclose( mus );

  printf( "\n\nFin EXO15.\n" );

  return 0;
}
