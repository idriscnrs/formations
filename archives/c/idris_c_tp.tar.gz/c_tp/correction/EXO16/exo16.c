#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* D�finition de types. */
typedef struct date
{
  unsigned int date_naiss;
  unsigned int date_mort;
} DATE;
typedef struct musicien
{
  char nom[30];
  char prenom[20];
  DATE date;
} MUSICIEN;
typedef struct index
{
  unsigned int debut;
  unsigned int longueur;
} INDEX;

int main()
{
  MUSICIEN  mort_le_plus_jeune( MUSICIEN *mus, int n );
  void      imprime           ( MUSICIEN *mus, int n );
  int       cmp_alpha         ( const void *mus1, const void *mus2 );
  int       cmp_chrono        ( const void *mus1, const void *mus2 );
  FILE     *ind, *musind;
  INDEX     index;
  MUSICIEN *p_mus;
  MUSICIEN  mus_mort_le_plus_jeune;
  char     *buffer;
  int       NbMus;

  // Ouverture du fichier index.
  if( (ind = fopen( "musiciens.index", "r" )) == NULL )
  {
    perror( "fopen" );
    exit(1);
  }
  // Ouverture du fichier index� des musiciens.
  if( (musind = fopen( "musiciens.indexe", "r" )) == NULL )
  {
    perror( "fopen" );
    exit(2);
  }
  NbMus = 0;
  p_mus = NULL;
  /*
   * Boucle de lecture du fichier index� des musiciens,
   * par l'interm�diaire du fichier d'index.
   */
  fread( &index, sizeof(INDEX), 1, ind );
  while( ! feof(ind) )
  {
    buffer = malloc( index.longueur+1 );
    fgets( buffer, index.longueur+1, musind );
    p_mus = realloc( p_mus, ++NbMus*sizeof(MUSICIEN) );
    sscanf( buffer, "%s%s%d%d",  p_mus[NbMus-1].prenom,
                                 p_mus[NbMus-1].nom,
                                &p_mus[NbMus-1].date.date_naiss,
                                &p_mus[NbMus-1].date.date_mort );
    free( buffer );
    fread( &index, sizeof(INDEX), 1, ind );
  }
  // Fermeture des fichiers.
  fclose( ind ); fclose( musind );
  // Affichage de la liste des musiciens.
  printf( "\n\n\t\tListe des musiciens :\n" );
  printf( "\t\t-------------------\n\n" );
  imprime( p_mus, NbMus );

  /*
   * Tri puis affichage de la liste des musiciens
   * tri�s par ordre alphab�tique. 
   */
  qsort( p_mus, NbMus, sizeof(MUSICIEN), cmp_alpha );
  printf( "\n\n\tListe des musiciens par ordre alphab�tique :\n" );
  printf( "\t------------------------------------------\n\n" );
  imprime( p_mus, NbMus );

  /*
   * Tri puis affichage de la liste des musiciens
   * tri�s par ordre chronologique.
   */
  qsort( p_mus, NbMus, sizeof(MUSICIEN), cmp_chrono );
  printf( "\n\n\tListe des musiciens par ordre chronologique :\n" );
  printf( "\t-------------------------------------------\n\n" );
  imprime( p_mus, NbMus );

  // Recherche du musicien mort le plus jeune.
  mus_mort_le_plus_jeune =  mort_le_plus_jeune( p_mus, NbMus );
  /*
   * Affichage du musicien mort le plus jeune, ainsi
   * que sa dur�e de vie.
   */
  printf( "\n\n\tLe musicien mort le plus jeune est :"
          "\n\t----------------------------------\n\n" );
  printf( "\t%s %s qui est mort � %d ans.\n\n",
           mus_mort_le_plus_jeune.prenom,
           mus_mort_le_plus_jeune.nom,
           mus_mort_le_plus_jeune.date.date_mort -
           mus_mort_le_plus_jeune.date.date_naiss );

  printf( "\n\nFin EXO16.\n" );

  return 0;
}

/*
 * Fonction appel�e par "qsort" pour trier les
 * musiciens par ordre alphab�tique.
 */
int cmp_alpha( const void *mus1, const void *mus2 )
{
  return strcmp( ((MUSICIEN *)mus1)->nom, ((MUSICIEN *)mus2)->nom );
}

/*
 * Fonction appel�e par "qsort" pour trier les
 * musiciens par ordre chronologique.
 */
int cmp_chrono( const void *mus1, const void *mus2 )
{
  if( ((MUSICIEN *)mus1)->date.date_naiss > ((MUSICIEN *)mus2)->date.date_naiss )
    return 1;
  if( ((MUSICIEN *)mus1)->date.date_naiss < ((MUSICIEN *)mus2)->date.date_naiss )
    return -1;
  return 0;
}

// Fonction d'affichage.
void imprime( MUSICIEN *mus, int n )
{
  for( int i=0; i<n; i++ )
    printf( "%-20s%-25s %5d %5d\n", mus[i].prenom, mus[i].nom,
                                    mus[i].date.date_naiss,
                                    mus[i].date.date_mort );

  return;
}

// Fonction recherchant le musicien mort le plus jeune.
MUSICIEN mort_le_plus_jeune( MUSICIEN *mus, int n )
{
  int indice = 0;

  for( int m=1; m<n; m++ )
    if( mus[m].date.date_mort - mus[m].date.date_naiss <
        mus[indice].date.date_mort -
        mus[indice].date.date_naiss )
      indice = m;

  return mus[indice];
}
