#include <stdio.h>
#include <stdlib.h>

typedef struct index
{
   unsigned int debut;
   unsigned int longueur;
} INDEX;

int main( int argc, char **argv )
{
  void   erreur(int rc);
  void   usage (char *s);
  FILE  *ind, *musind;
  int    rang_mus;
  INDEX  index;
  char  *buffer;

  // Le rang a-t-il �t� sp�cifi� ?
  if( argc != 2 ) usage( argv[0] );
  // Conversion de l'argument en entier.
  rang_mus = (int)strtol( argv[1], NULL, 0 );
  if( rang_mus <= 0 )
    erreur( 1 );
  // Ouverture du fichier index� des musiciens.
  if( (musind = fopen( "musiciens.indexe", "r" )) == NULL )
    perror( "fopen" ), exit(2);
  // Ouverture du fichier d'index.
  if( (ind = fopen( "musiciens.index", "r" )) == NULL )
    perror( "fopen" ), exit(3);
  // Positionnement dans le fichier d'index.
  fseek( ind, (rang_mus-1)*sizeof(INDEX), SEEK_SET );
  /*
   * Lecture de l'index contenant le positionnement et
   * la longueur de l'enregistrement, dans le fichier
   * index� des musiciens, correspondant au rang sp�cifi�.
   */
  if( fread( &index, sizeof index, 1, ind ) != 1 )
    erreur( 4 );
  // Positionnement puis lecture de l'enregistrement d�sir�.
  fseek( musind, index.debut, SEEK_SET );
  buffer = malloc( index.longueur+1 );
  fgets( buffer, index.longueur+1, musind );
  // Affichage du musicien s�lectionn�.
  printf( "\n\tmusicien de rang %d ==> %s\n\n",
           rang_mus, buffer );
  free( buffer );
  // Fermeture des fichiers.
  fclose( ind ); fclose( musind );

  printf( "\n\nFin EXO17.\n ");

  return 0;
}

void erreur( int rc )
{
  fprintf( stderr, "rang invalide.\n" );
  exit( rc );
}

void usage( char *s )
{
  fprintf( stderr, "usage : %s rang\n", s );
  exit( 6 );
}
