#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>

// Les pseudos-variables suivantes doivent surtout
// correspondre à des valeurs non nulles car celles-ci
// seront utilisées lors des appels à la fonction ¶\motcle{\og \bftt{longjmp}\fg{}}¶
#define USAGE            1
#define RANG_INVALIDE    2
#define ERROR_OPEN_INDEX 3
#define ERROR_OPEN_MUS   4
#define ERROR_LEC_INDEX  5

typedef struct index
{
   unsigned int debut;
   unsigned int longueur;
} INDEX;

jmp_buf cntx;

static int  traitement_arg( int argc, char **argv );
static void recherche_mus (int rang_mus);

int main( int argc, char **argv )
{
  int retour;
  int rang_mus;

  if ( (retour = setjmp( cntx )) == 0 )
  {
    rang_mus = traitement_arg(argc, argv);
    recherche_mus(rang_mus);
  }
  else
    exit(retour);

  printf( "\n\nFin EXO17.\n");

  return 0;
}

static int traitement_arg( int argc, char **argv )
{
  int rang_mus;

  // Le rang a-t-il été spécifié ?
  if( argc != 2 )
  {
    fprintf( stderr, "usage : %s rang\n", argv[0] );
    longjmp( cntx, USAGE );
  }
  // Conversion de l'argument en entier.
  rang_mus = (int)strtol( argv[1], NULL, 0 );
  if( rang_mus <= 0 )
  {
    fprintf( stderr, "rang invalide.\n" );
    longjmp(cntx, RANG_INVALIDE);
  }

  return rang_mus;
}

static void recherche_mus(int rang_mus)
{
  FILE  *ind, *musind;
  INDEX  index;
  char  *buffer;

  // Ouverture du fichier indexé des musiciens.
  if( (musind = fopen( "musiciens.indexe", "r" )) == NULL ) {
    perror( "fopen(mus)" ); longjmp(cntx, ERROR_OPEN_INDEX);
  }
  // Ouverture du fichier d'index.
  if( (ind = fopen( "musiciens.index", "r" )) == NULL ) {
    perror( "fopen(index)" ); longjmp(cntx, ERROR_OPEN_MUS);
  }
  // Positionnement dans le fichier d'index.
  // Ne pas trop compter sur la valeur retournée par la fonction ¶\textcolor{black}{\og \bftt{fseek}\fg{}}¶.
  // Un mauvais positionnement provoquera une erreur lors de la lecture suivante.
  fseek( ind, (rang_mus-1)*sizeof(INDEX), SEEK_SET );
  // Lecture de l'index contenant le positionnement et la longueur de l'enregistrement
  // dans le fichier indexé des musiciens correspondant au rang spécifié.
  if( fread( &index, sizeof index, 1, ind ) != 1 ) {
    fprintf( stderr, "rang invalide.\n" ); longjmp(cntx, ERROR_LEC_INDEX);
  }
  // Positionnement puis lecture de l'enregistrement désiré.
  fseek( musind, index.debut, SEEK_SET );
  buffer = malloc( index.longueur+1 );
  fgets( buffer, index.longueur+1, musind );
  // Affichage du musicien sélectionné.
  printf( "\n\tmusicien de rang %d ==> %s\n\n", rang_mus, buffer );
  free( buffer );
  // Fermeture des fichiers.
  fclose( ind ); fclose( musind );

  return;
}
