#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include <fcntl.h>

int *positions;
int  nb_positions;
int  nombre_octets_lus;

static void init( void )
{
  positions = NULL;
  nb_positions = 0;
  nombre_octets_lus = 0;
  
  return;
}

int main( int argc, char **argv )
{
   // D�clarations.
   void  usage(char *s);
   void  strrech( char *buffer, int nblus,
                  char *ChaineAchercher, size_t longueur );
   int     fd;
   char    buffer[BUFSIZ];
   char   *ChaineAchercher;
   size_t  longueur;
   int     nblus;

   // Le fichier et la cha�ne � chercher ont-ils �t� pass�s en argument ?

   if ( argc != 3 )
     usage( argv[0] );
   ChaineAchercher = argv[2];
   longueur = strlen( ChaineAchercher );

   // initialisation des variables globales.
   init();

   // Ouverture du fichier pass� en argument.

   if( (fd = open( argv[1], O_RDONLY )) == -1 )
   {
      perror( "open" );
      exit( 1 );
   }

   // Boucle de lecture du fichier.
   while( nblus = read( fd, buffer, sizeof buffer ) )
   {
     // R�cup�ration des positions de la cha�ne dans le buffer courant.
     strrech( buffer, nblus, ChaineAchercher, longueur );

     /*
      * Si BUFSIZ caract�res ont �t� lus, on recule de
      * (longueur-1) caract�res dans le fichier,
      * pour �tre s�r de n'oublier aucune position de la
      * cha�ne lors de la lecture suivante.
      */

     nombre_octets_lus += nblus;
     if( nblus == BUFSIZ )
     {
       lseek( fd, -(long)(longueur - 1), SEEK_CUR );
       nombre_octets_lus -= longueur - 1;
     }
   }
   close( fd );

   // Impression des positions trouv�es.

   if ( nb_positions == 0 )
     printf( "La cha�ne \"%s\" n'a pas �t� trouv�e\n"
             "dans le fichier \"%s\".\n", ChaineAchercher, argv[1] );
   else
   {
     printf( "Dans le fichier \"%s\", la cha�ne \"%s\"\n"
             "a �t� trouv�e aux positions :\n\n", argv[1], ChaineAchercher );
     for( int pos=0; pos<nb_positions; )
     {
       printf( "%5d", positions[pos] );
       if( ! ((++pos)%12) ) printf( "\n" );
     }
     printf( "\n" );
   }
   free( positions );

   printf( "\n\nFin EXO18.\n" );
}

/*
 * Fonction de r�cup�ration des positions
 * de la cha�ne dans le buffer courant.
 */
void strrech( char *s, int nblus,
              char *ChaineAchercher, size_t longueur )
{
   char       *buffer;
   static int  n = 0;

   /*
    * On prend garde de remplacer les �ventuels caract�res
    * "nuls" par des blancs pour pouvoir utiliser
    * la fonction "strstr".
    */

   buffer = malloc( nblus+1 );
   memcpy( buffer, s, nblus );
   for( int i=0; i<nblus; i++ )
     buffer[i] = buffer[i] ? buffer[i] : ' ';
   buffer[nblus] = '\0';

   // Boucle de recherche de la cha�ne.
   for( char *ptr=buffer; ptr=strstr( ptr, ChaineAchercher );
        ptr+=longueur )
   {
     // extension du vecteur positions.
     positions = (int *)realloc( positions, ++n*sizeof(int) );
     assert( positions != NULL );

     // position de la cha�ne trouv�e par rapport au d�but du bloc lu.
     positions[n-1] = ptr - buffer + 1;

     // position de la cha�ne trouv�e par rapport au d�but du fichier.
     positions[n-1] += nombre_octets_lus;
   }
   free( buffer );
   nb_positions = n;

   return;
}

void usage(char *s)
{
   fprintf( stderr, "usage: %s fichier ChaineAchercher.\n", s );
   exit(1);
}
