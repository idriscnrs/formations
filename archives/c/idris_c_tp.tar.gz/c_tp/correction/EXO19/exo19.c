#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "exo19.h"
#include "exo19_gestion_liste.h"

struct menu
{
  char  *texte;
  void (*action)( void );
};

int main()
{
  // D�finition du menu.
  struct menu menu[] =
  {
    {"  1 - AJOUTS d'�l�ments dans une liste cha�n�e.\n", ajouts},
    {"  2 - AFFICHAGE de la liste cha�n�e.\n",            liste},
    {"  3 - TRI de la liste cha�n�e.\n",                  tri},
    {"  4 - SUPPRESSION d'�l�ments dans la liste.\n",     suppression},
    {"  5 - VIDER la liste.\n",                           vider},
    {"  6 - ARR�T du programme.\n",                       arret}
  };
  int SelectionMenu( struct menu menu[], int NbChoix );

  // Boucle infinie sur les choix effectu�s.
  for( ;; )
    menu[SelectionMenu( menu, taille(menu) )].action();
}

// Fonction renvoyant le choix effectu�.

int SelectionMenu( struct menu menu[], int NbChoix )
{
  int   choix;
  char  entree[10];
  char *endp;

  do
  {
    printf( "\n\nListe des choix :\n" );
    for( int m=0; m<NbChoix; m++ )
      printf( "%s", menu[m].texte );

    // Lecture du choix.
    // Attention : si "scanf", lire le "newline"
    // car, par la suite, les lectures s'effectueront
    // � l'aide de la fonction "gets".
    //  scanf("%d%*c", &choix);

    gets( entree );
    choix = (int)strtol( entree, &endp, 0 );
    if( *endp != '\0' || choix < 1 || choix > NbChoix )
      printf( "\nERREUR - choix invalide.\n" );
  } while( *endp != '\0' || choix < 1 || choix > NbChoix );
  printf( "\n" );

  return --choix;
}
