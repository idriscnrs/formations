#define taille(t) sizeof(t) / sizeof(t[0])
