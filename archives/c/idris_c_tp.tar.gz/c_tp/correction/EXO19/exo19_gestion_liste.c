#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "exo19.h"
#include "exo19_gestion_liste.h"

#define LISTE_VIDE "La liste est vide.\n"

static const char * const prompt_ajout       = "�l�ment � ajouter[CtrlD pour terminer] --> ";
static const char * const prompt_suppression = "�l�ment � supprimer[CtrlD pour terminer] --> ";
static const char *prompt;

typedef struct cellule
{
  char           *capitale;
  struct cellule *ptr_precedent;
  struct cellule *ptr_suivant;
} CEL;

static CEL  *debut   = NULL;
static CEL  *curseur = NULL;

static bool  liste_vide         ( void );
static void  ajout_cellule      ( char *chaine );
static void  suppression_cellule( void );
static bool  recherche_cellule  ( char *chaine );
static char *lire_chaine        ( void );
static void  affichage_liste    ( CEL *p );

static bool liste_vide( void )
{
  return debut == NULL ? true : false;
}

static void ajout_cellule( char *chaine )
{
  CEL *p;

  // Allocation, valorisation, insertion du nouvel �l�ment.
  p = malloc( sizeof(CEL) );
  p->capitale = chaine;

  if ( liste_vide() )
    p->ptr_suivant = p->ptr_precedent = NULL;
  else
  {
    if ( curseur != debut )
      curseur->ptr_precedent->ptr_suivant = p;
    p->ptr_precedent = curseur->ptr_precedent;
    curseur->ptr_precedent = p;
    p->ptr_suivant = curseur;
  }
  curseur = p;
  if( curseur->ptr_precedent == NULL )
    debut = curseur;

  return;
}

static void suppression_cellule( void )
{
  if( curseur == debut )
  {
    // L'�l�ment � supprimer est le 1er de la liste.
    debut = curseur->ptr_suivant;
    if( ! liste_vide() )
      debut->ptr_precedent = NULL;
  }
  else
  {
    // L'�l�ment � supprimer n'est pas le 1er de la liste.
    curseur->ptr_precedent->ptr_suivant = curseur->ptr_suivant;
    if( curseur->ptr_suivant != NULL )
      // L'�l�ment � supprimer n'est pas le dernier de la liste.
      curseur->ptr_suivant->ptr_precedent = curseur->ptr_precedent;
  }
  {
    CEL *p = curseur;

    free( p->capitale ); free( p );
    if ( curseur->ptr_suivant != NULL )
      curseur = curseur->ptr_suivant;
    else
      curseur = debut;
  }

  return;
}

static bool recherche_cellule( char *chaine )
{
  CEL *p;

  for( p=debut; p; p=p->ptr_suivant )
    if ( ! strcmp( p->capitale, chaine ) )
      break;

  if( p != NULL )
  {
    curseur = p;
    return true;
  }

  return false;
}

static char *lire_chaine( void )
{
  char buffer[BUFSIZ];

  // Lecture de l'�l�ment � ajouter.

  fputs( prompt, stdout );
  gets( buffer );

  /*
   * Si Control-D, annuler le bit indicateur
   * de fin de fichier, pour les prochaines saisies.
   */

  if( feof( stdin ) )
  {
    clearerr( stdin );
    return NULL;
  }

  return strdup( buffer );
}

// Fonction rattach�e au choix 1. (AJOUTS d'�l�ments dans la liste cha�n�e).
void ajouts( void )
{
  char *chaine;

  // Boucle de lecture des cha�nes.

  prompt = prompt_ajout;

  while( (chaine = lire_chaine()) != NULL )
    ajout_cellule( chaine );

  return;
}

// Fonction rattach�e au choix 2. (AFFICHAGE de la liste cha�n�e).
void liste( void )
{
  if ( liste_vide() )
  {
    fprintf( stderr, LISTE_VIDE );
    return;
  }
  affichage_liste( debut );

  return;
}

static void affichage_liste( CEL *p )
{
  if( p != NULL )
  {
    printf( "\t%s\n", p->capitale );
    affichage_liste( p->ptr_suivant );
  }

  return;
}

// Fonction rattach�e au choix 3. (TRI de la liste cha�n�e).
void tri( void )
{
  bool  tri_terminee;
  CEL  *ptr;

  // La liste doit exister.
  if ( liste_vide() )
    fprintf( stderr, LISTE_VIDE );
  else
  {
    // Boucle de tri.
    do
    {
      tri_terminee = true;
      for( ptr=debut; ptr->ptr_suivant;
           ptr = ptr->ptr_suivant )
        if( strcmp( ptr->capitale,
                    ptr->ptr_suivant->capitale ) > 0 )
        {
          // On effectue une interversion.
          curseur = ptr;
          ajout_cellule(
            strdup( curseur->ptr_suivant->capitale ) );
          curseur = ptr->ptr_suivant;
          suppression_cellule();
          tri_terminee = false;
          if ( ptr->ptr_suivant == NULL )
            break;
        }
    } while( ! tri_terminee );
  }

  return;
}

// Fonction rattach�e au choix 4. (SUPPRESSION d'�l�ments dans la liste).
void suppression( void )
{
  char *chaine;

  // Boucle de lecture des cha�nes.
  prompt = prompt_suppression;

  while( ! liste_vide() && (chaine = lire_chaine()) != NULL )
  {
    if( ! recherche_cellule( chaine ) )
    {
      fprintf( stderr, "L'�l�ment \"%s\" est inexistant!\n\n", chaine );
      continue;
    }
    suppression_cellule();
    printf( "L'�l�ment \"%s\" a �t� supprim� de la liste.\n\n", chaine );
  }
  // La liste est-elle vide ?
  if ( liste_vide() ) fprintf( stderr, LISTE_VIDE );

  return;
}

// Fonction rattach�e au choix 5. (VIDER la liste ).
void vider( void )
{
  if ( liste_vide() )
    fprintf( stderr, LISTE_VIDE );
  else
  {
    curseur = debut;
    while ( ! liste_vide() )
      suppression_cellule();
  }

  return;
}

// Fonction rattach�e au choix 6. (ARRET du programme).
void arret( void )
{
  // Si la liste n'est pas vide, on lib�re la m�moire qu'elle occupe.
  if( ! liste_vide() ) vider();

  printf( "\n\nFin EXO19.\n" );

  exit( 0 );
}
