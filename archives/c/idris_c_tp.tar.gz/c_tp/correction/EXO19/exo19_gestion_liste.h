void ajouts     ( void );
void liste      ( void );
void tri        ( void );
void suppression( void );
void vider      ( void );
void arret      ( void );
