#include <stdio.h>

int main()
{
  char *argv[] = {
                    "Wolfgang Amadeus Mozart",
                    "Ludwig van Beethoven",
                    "Hector Berlioz",
                    "Nicolo Paganini"
                 };
  char **p = argv;

  printf( "\n1�re s�rie : \n" );
  printf( "----------\n" );
  printf( "%c\n", (*p++)[1] );
  printf( "%c\n", *p++[1] );
  printf( "%c\n", (*++p)[4] );
  printf( "%c\n", *++*p );

  p = argv;
  p[0] = "Wolfgang Amadeus Mozart";
  p[1] = "Ludwig van Beethoven";
  p[2] = "Hector Berlioz";
  p[3] = "Nicolo Paganini";

  printf( "\n2�me s�rie : \n" );
  printf( "----------\n" );
  printf( "%c\n", (*p++)[1] );
  printf( "%c\n", *p[1]++ );
  printf( "%c\n", (*++p)[4] );
  printf( "%c\n", *++*p );

  printf( "\n\nFin EXO2.\n" );

  return 0;
}
