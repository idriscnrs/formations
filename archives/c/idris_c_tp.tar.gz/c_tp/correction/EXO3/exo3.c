#include <stdio.h>
int main()
{
  int a;
  int b;
  int c;

  a = 16;
  b = 2;
  c = 10;

  /*
   * 1) on commence par �valuer l'expression
   *    a > 0 && a <= 15, laquelle constitue
   *    le 1er op�rande de l'op�rateur ?:.
   *    Celle-ci est fausse car les expressions
   *    a > 0 et a <= 15 sont vraie et
   *    fausse respectivement,
   * 2) on �value donc le 3eme op�rande de l'op�rateur
   *    ?:, c'est-�-dire l'expression a/b,
   * 3) et enfin on effectue l'affectation.
   */
  c += a > 0 && a <= 15 ? ++a : a/b;
  printf( "c : %d\n", c );/*  ===>  18 */

  // Que dire de l'expression suivante? :
  // ----------------------------------
  // a > 30 ? b = 11 : c = 100;

  /*
   * Cette expression provoque une erreur
   * � la compilation car le troisi�me
   * op�rande de l'op�rateur ?: est c
   * et non pas c = 100. De ce fait,
   * l'expression a > 30 ? b = 11 : c
   * est d'abord �valu�e. Sa valeur est ensuite utilis�e
   * comme op�rande de gauche de la derni�re affectation.
   * D'o� l'erreur, car cette valeur n'est pas une g-valeur.
   *
   * On devrait �crire :
   */

  a > 30 ? b = 11 : (c = 100); 

  return 0;
}
