#include <stdio.h>

int main()
{
  int pairs, carres_impairs, cubes; 

  pairs = carres_impairs = cubes = 0;
  // Boucle de calcul.
  for( int i=1; i<=100; i++ )
  {
    cubes += i*i*i;
    // "i" est-il pair ou impair?
    i%2 ? carres_impairs += i*i : (pairs += i);
  }
  // Impression des r�sultats.
  printf( "Somme des entiers pairs entre 1 et 100              : %d\n", pairs );
  printf( "Somme des carr�s des entiers impairs entre 1 et 100 : %d\n", carres_impairs );
  printf( "Somme des cubes des 100 premiers entiers            : %d\n", cubes );

  printf( "\n\nFin EXO4.\n" );

  return 0;
}
