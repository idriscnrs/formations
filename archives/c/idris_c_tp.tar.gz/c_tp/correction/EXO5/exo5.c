#include <stdio.h>
#include <stdlib.h>

// rand retourne un entier pseudo-aléatoire dans l'intervalle [0,RAND_MAX]
int main()
{
  const int n = 10, m = 5, p = 3;
  double    a[n][m], b[m][p], c[n][p];

                 // Produit matriciel C = A*B
  for( int i=0; i<n; i++ )
    for( int j=0; j<p; j++ )
    {
      c[i][j] = 0.;
      for( int k=0; k<m; k++ )
      {
        a[i][k] = (double)rand()/RAND_MAX; b[k][j] = (double)rand()/RAND_MAX;
        c[i][j] += a[i][k] * b[k][j];
      }
    }

                 // Impression de la matrice C.
  for( int i=0; i<n; i++ )
  {
    for( int j=0; j<p; j++ )
      printf( "%9.5f", c[i][j] );
    printf( "\n" );
  }

  printf( "\n\nFin EXO5.\n" );

  return 0;
}
