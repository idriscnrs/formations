#include <stdio.h>
#include <stdbool.h>
#include <math.h>

int main()
{
  const int n = 1000;
  bool      tab_nombres[n];
  int       imax;

  // Remplissage du tableau "tab_nombres"
  for( int i=1; i<n; i++ )
    tab_nombres[i] = true;

  imax = (int)sqrt( (double)n );
  for( int i=2; i<imax; i++ )
    if( tab_nombres[i] )
      /*
       * Suppression des multiples non d�j�
       * exclus du nombre "tab_nombres[i]".
       */
      for( int j=i+1; j<n; j++ )
        if( tab_nombres[j] && j%i == 0 )
          tab_nombres[j] = false;

  /*
   * Impression des nombres non exclus
   * qui sont les nombres premiers cherch�s.
   * Impression de 10 nombres par ligne.
   */
  printf( "Les nombres premiers entre 1 et "
          "%d sont :\n\n", n );
  for( int i=1; i<n; i++ )
  {
    static int nb_prem = 0;

    if ( tab_nombres[i] )
    {
      if( nb_prem++%10 == 0 ) printf( "\n" );
      printf( "%5d", i );
    }
  }

  printf( "\n\nFin EXO6\n" );

  return 0;
}
