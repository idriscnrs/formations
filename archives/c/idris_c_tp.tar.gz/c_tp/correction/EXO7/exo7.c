#include <stdio.h>

int main()
{
  char tab[12][12];

  // Boucle sur les colonnes.
  for( int j=0; j<12; )
    /*
     * On remplit par groupe de 3 colonnes avec
     * les caract�res successifs '1', '2'  et '3'.
     */
    for( char c='1'; c<='3'; c++, j++ )
      for( int i=j; i<12; i++ )
        tab[i][j] = c;
  // Impression du tableau obtenu.
  for( int i=0; i<12; i++ )
  {
    for( int j=0; j<=i; j++ )
      printf( "  %c", tab[i][j] );
    printf( "\n" );
  }

  printf( "\n\nFin EXO7.\n" );

  return 0;
}
