#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define NLIGNES 3
#define NCOLS   4

// rand retourne un entier pseudo-al�atoire dans l'intervalle [0,RAND_MAX]
int main()
{
  void      tri_vec( double *t );
  const int n = NLIGNES, m = NCOLS;
  double    mat[n][m];

  // Tri de chaque vecteur ligne.
  for( int i=0; i<n; i++ )
  {
    for ( int j=0; j<m; j++ )
      mat[i][j] = (double)rand()/RAND_MAX;
    tri_vec( mat[i] );
  }
  // Impression de la matrice obtenue.
  for( int i=0; i<n; i++ )
  {
    for( int j=0; j<m; j++ )
      printf( "%9.3f", mat[i][j] );
    printf( "\n" );
  }
  printf( "\n\nFin EXO8.\n" );
  return 0;
}

// Fonction effectuant le tri d'un vecteur par la m�thode du tri � "bulles".
void tri_vec( double *t )
{
  for( int i=NCOLS-2; i >= 0; i-- )
  {
    for( int j=0; j<=i; j++ )
      if( t[j] > t[j+1] )
      {
        double temp;

        temp = t[j+1];
        t[j+1] = t[j];
        t[j] = temp;
      }
  }

  return;
}
