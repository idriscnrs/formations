#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// Fonctions de transformations.
double identite( double x ) { return x; }

double carre   ( double x ) { return x*x; }

double cubes   ( double x ) { return x*x*x; }

int main()
{
  void      init     ( int n, int m, double mat[n][m] );
  void      transform( int n, int m, double mat[n][m], double (*f)( double ) );
  const int n = 3, m = 4;
  double    mat[n][m];
  const int choix = 4;

  init( n, m, mat );

  switch( choix )
  {
    case 1:
      transform( n, m, mat, identite );
      break;
    case 2:
      transform( n, m, mat, carre );
      break;
    case 3:
      transform( n, m, mat, cubes );
      break;
    case 4:
      transform( n, m, mat, log );
      break;
  }

  // Impression de la matrice transform�e.
  for( int i=0; i<n; i++ )
  {
    for( int j=0; j<m; j++ )
      printf( "%9.3f", mat[i][j] );
    printf( "\n" );
  }

  printf( "\n\nFin EXO9.\n" );

  return 0;
}

// Fonction d'inialisation.
// rand retourne un entier pseudo-al�atoire dans l'intervalle [0,RAND_MAX]
void init( int n, int m, double mat[n][m] )
{
  for( int i=0; i<n; i++ )
    for( int j=0; j<m; j++ )
      mat[i][j] = (double)rand()/RAND_MAX;

  return;
}

// Fonction effectuant la transformation.
void transform( int n, int m, double mat[n][m], double (*f)( double ) )
{
  for( int i=0; i<n; i++ )
    for( int j=0; j<m; j++ )
      mat[i][j] = (*f)( mat[i][j] );

  return;
}
