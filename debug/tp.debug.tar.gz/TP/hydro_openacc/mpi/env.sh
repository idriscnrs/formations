module purge
module load nvidia-compilers/21.3
module load cuda/11.2
module load openmpi/4.1.1-cuda
