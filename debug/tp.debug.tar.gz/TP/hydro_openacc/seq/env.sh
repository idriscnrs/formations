module purge
module load nvidia-compilers/21.3
