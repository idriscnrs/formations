#include <stdio.h>

float (*addr)( float );
float (*addr_func)( float );

float f( float x )
{
  return x*x*x;
}

void appel_c( void )
{
  printf( "%f\n", addr( 3.14f ) );
  addr_func = f;

  return;
}
