#include <stdio.h>

int entier_externe;
double double_externe;

void sp( float m1[6][3], double m2[][5], int *n, char *ch )
{
  int i, j;

  printf( "\t\t%s\n\n", ch );
  printf( "entier_externe = %d\n", entier_externe );
  printf( "double_externe = %f\n", double_externe );
  printf( "\t\tMatrices C\n\n" );
  for( j=0; j<3; j++ ) {
    for( i=0; i<6; i++ )
      printf( "%f ", m1[i][j] );
    printf( "\n" );
  }
  printf( "\n" );
  for( j=0; j<5; j++ ) {
    for( i=0; i<*n; i++ )
      printf( "%f ", m2[i][j] );
    printf( "\n" );
  }
  return;
}
