float C_Func( float *buf, int count )
{
  float somme = 0. ; 

  for( int i=0; i<count; i++ ) somme += buf[i] ;

  return somme ; 
}
