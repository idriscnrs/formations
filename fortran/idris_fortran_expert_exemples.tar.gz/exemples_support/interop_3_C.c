void f1( double *b, double d[], long taille_d );
int main()
{
  double beta = 378.0 ;
  double delta[] = { 17.,   12.3,  3.14,  2.718,  0.56,
                     22.67, 25.8, 89.,   76.5,   80. } ;
  long   taille_delta = sizeof delta / sizeof delta[0] ;

  f1( &beta, delta, taille_delta ) ;
  return 0;
}
