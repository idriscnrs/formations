void fct(int n, int m, float mat[m][n])
{
  for( int i=0; i<m; i++ )
    mat[i][n-1] *= 2.;

  return;
}
