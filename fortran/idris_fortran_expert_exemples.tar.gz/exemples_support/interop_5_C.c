#include <stdlib.h>

void C_alloc( float **p, int n, int m )
{ *p = malloc( n*m*sizeof(float) ); return ; }

void C_free( float *p ) { free( p ); return ; }
