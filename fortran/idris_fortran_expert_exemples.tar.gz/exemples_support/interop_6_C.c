#include <stdio.h>

void F_alloc  ( float **, int );
void F_moyenne( float * , int );
void F_free   ( void );

int main()
{
  const int  n = 100;
  float     *vec;

  F_alloc( &vec, n );
  printf( " vec[50] = %f\n", vec[50] );
  F_moyenne( vec, n );
  F_free();

  return 0;
}
