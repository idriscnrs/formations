#include <stdio.h>

typedef struct 
{
    int    len  ;
    float *p    ;
} vecteur;

void C_moyenne(vecteur vec)
{
  float moy ;
   
  printf( "Le vecteur vec a %d �l�ments.\n", vec.len ) ;
  moy = 0. ;
  for( int i=0; i<vec.len; i++ ) moy += vec.p[i] ;
  moy /= vec.len ;
  printf( "Moyenne = %f\n", moy ) ;
  return ;
}
