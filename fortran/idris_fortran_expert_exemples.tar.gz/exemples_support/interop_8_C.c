#include <stdio.h>
#include <stdlib.h>

typedef struct 
{
    int    len  ;
    float *p    ;
} vecteur;

void F_val(vecteur v);

int main()
{
  float   moy ;
  vecteur vec ;

  moy = 0. ;
  vec.p = (float *)calloc(vec.len=1000, sizeof(float)) ;
  F_val( vec ) ;
  for( int i=0; i<vec.len; i++ ) moy += vec.p[i] ;  
  moy /= vec.len ; printf( "Moyenne = %f\n", moy ) ;
  free(vec.p) ;
  return 0 ;
}
