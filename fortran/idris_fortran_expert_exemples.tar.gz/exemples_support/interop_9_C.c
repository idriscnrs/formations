#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct
{
  int i, j;
} Pair;

typedef struct
{
  int    n;
  double r;
  int    n_ch;
  char **tab_chaines;
  int    nb_pairs;
  Pair  *p;
} Cel;
int main()
{
  void Ap_For( Cel );
  Cel c;

  c.n = 1756, c.r = acos( -1. ), c.n_ch = 10;
  c.tab_chaines = calloc( c.n_ch, sizeof(char *) );
  for ( int n=0; n<c.n_ch; n++ )
  {
    char buffer[] = "File numberxx";

    sprintf( buffer+11, "%02d", n );
    c.tab_chaines[n] = strdup( buffer );
  }
  c.p = calloc( c.nb_pairs=3, sizeof(Pair) );
  for ( int n=0; n<c.nb_pairs; n++ )
    c.p[n].i = n+1000, c.p[n].j = n+2000;

  Ap_For( c );

  for ( int n=0; n<c.n_ch; n++ ) free( c.tab_chaines[n] );
  free( c.tab_chaines );
  free( c.p );

  return 0;
}
