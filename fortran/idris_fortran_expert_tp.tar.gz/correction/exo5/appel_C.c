#include <string.h>
#include <stdlib.h>

void c_chaine( char **chaine )
{
  *chaine = strdup( "Wolfgang Amadeus Mozart" ); 

  return;
}

void c_chaine_free( char *chaine )
{
  free( chaine );

  return;
}
