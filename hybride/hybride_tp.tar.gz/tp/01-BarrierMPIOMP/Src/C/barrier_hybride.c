#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <mpi.h>
#include <omp.h>

// Desynchronisation des threads, a ne pas toucher
void desync(int myMPIRank, int myOMPRank)
{
  if (myMPIRank==1 && myOMPRank==1) sleep(10);
}


// Barriere hybride a coder
void barrierMPIOMP()
{
  // ?
  sleep(1);
}


int main(int argc, char **argv)
{
  int myMPIRank, nbOMP;
  int code, level_mpi_provided;
  
  // Initialisation MPI/OMP
  // ?
  // Recuperation myMPIRank
  // ?
  // Desynchronisation des threads
#pragma omp parallel
  {
    int myOMPRank = omp_get_thread_num();
    desync(myMPIRank,myOMPRank);
    printf("Avant barriere, processus MPI : %d thread OMP : %d\n",myMPIRank,myOMPRank);
    // Barriere hybride a coder
    barrierMPIOMP();
    printf("Apres barriere, processus MPI : %d thread OMP : %d\n",myMPIRank,myOMPRank);
  }
  // Fermeture environnement MPI
  // ?
  return EXIT_SUCCESS;
}
