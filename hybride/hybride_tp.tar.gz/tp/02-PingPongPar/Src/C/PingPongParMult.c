/*
 * Parallel Hybrid PingPong with threads support level of type Multiple
 * Computation of the sustained network bandwidth between two nodes,
 * with one MPI process per node and nbOMPComm parallel streams of communication
 * Execution on 2 nodes.
 */

#include <stdlib.h>
#include <stdio.h>

#include <mpi.h>
#include <omp.h>

#define SIZE_OMP_COMM 8
#define NB_SIZES 3

void barrierMPIOMP();
void pingPongPar(int myMPIRank, int myOMPRank, int nbOMPComm, int tailleMo);

int main(int argc, char **argv)
{
  const int OMPComm[SIZE_OMP_COMM] = { 1, 2, 3, 4, 8, 16, 20, 40 };
  int myMPIRank, nbMPIProcs;
  int nbOMPThds, nbOMPComm;
  int level_mpi_provided;
  const int tailleBufMo[NB_SIZES] = { 1, 10, 100 };

  // MPI Initialization
  ...
  // Get myMPIRank & nbMPIProcs
  ...
  ...
  if (level_mpi_provided < MPI_THREAD_MULTIPLE)
  {
    if (myMPIRank == 0)
      printf("Error: level_mpi_provided < MPI_THREAD_MULTIPLE\n");

    MPI_Abort(MPI_COMM_WORLD, 1);
  }

  // OpenMP parallel region
  ...
  {
    ...
    {
      // Number of OpenMP threads per MPI process
      nbOMPThds =
    }
  } // End of OpenMP parallel region

  // Output information of the run
  if (myMPIRank == 0)
    printf("Execution sur %d processus MPI constitues de %d threads OpenMP\n", nbMPIProcs, nbOMPThds);

  // Loop on the number of tests (1 test for each # of data streams in //)
  for (int it = 0; it < SIZE_OMP_COMM; it++)
  {
    if (OMPComm[it] > nbOMPThds)
      break;

    // OpenMP parallel region
    ...
    {
      // Rank of the OpenMP thread
      int myOMPRank =

      // Number of active threads involved in communication
      ...
      {
        nbOMPComm =
        if (myMPIRank == 0)
          printf("Nombre de threads de communication : %d\n", nbOMPComm);
      }

      // Hybrid synchronization barrier
      barrierMPIOMP();

      // Loop on the message sizes (1 MB, 10 MB and 100 MB)
      for (int i = 0; i < NB_SIZES; i++)
        pingPongPar(myMPIRank, myOMPRank, nbOMPComm, tailleBufMo[i]);

      if (myMPIRank == 0 && myOMPRank == 0)
        printf("\n");
    } // End of OpenMP parallel region
  }

  // Finalization of MPI environment
  ...

  return EXIT_SUCCESS;
}

void pingPongPar(int myMPIRank, int myOMPRank, int nbOMPComm, int tailleMo)
{
  double startTime, endTime;
  int nbElBuf, nbIter;
  double *pingSendBuf, *pingRecvBuf, *pongRecvBuf;
  int sendRank, recvRank, tagping, tagpong;
  MPI_Status statut;

  // Number of elements in the buffers
  nbElBuf = (1e6 * tailleMo) / sizeof(double);
  // Number of iterations for a total data transfert of 1 GB pingPong
  nbIter = 1000 / tailleMo;

  // For communication threads
  if (...)
  {
    // Allocations of send and receive buffers
    if (...)
    {
      pingSendBuf = (double*)malloc(nbElBuf * sizeof(double));
      pongRecvBuf = (double*)malloc(nbElBuf * sizeof(double));
    }
    else
      pingRecvBuf = (double*)malloc(nbElBuf * sizeof(double));

    // Who to send (sendRank), who to receive (recvRank) ?
    sendRank = ...
    recvRank = ...
    tagping = myOMPRank;
    tagpong = myOMPRank;

    // Initialization of the send buffer pingSendBuf
    if (...)
    {
      for (int i = 0; i < nbElBuf; i++)
        pingSendBuf[i] = myOMPRank;
    }
  }

  // Hybrid synchronization barrier
  barrierMPIOMP();

  // Timer for the parallel PingPong on node 0
  #pragma omp master
  {
    if (...)
      startTime = MPI_Wtime();
  }

  // Loop to get the equivalent of 1 GB data transfert per pingpong
  for (int iter = 0; iter < nbIter; iter++)
  {
    if (...)
    {
      // Ping : Send pingSendBuf to sendRank
      if (...)
        ...
      // Pong : Receive of sendRank in pongRecvBuf
      if (...)
        ....
    }
    else
    {
      // Ping : Receive from sendRank in pingRecvBuf
      if (...)
        ....
      // Pong : Send of pingRecvBuf to sendRank
      if (...)
        ...
    }
    // Waiting for Pong completion
    ...
  }

  // End of timing and output of sustained bandwidth
  #pragma omp master
  {
    if (...)
    {
      endTime = MPI_Wtime();
      printf("Taille msg = %5d Mo, tps elapsed = %.3e, debit = %.3e Mo/s\n",
             tailleMo, endTime - startTime, nbOMPComm * nbIter * 2.0 * tailleMo / (endTime - startTime));
    }
  }

  // Deallocations of send and receive buffers
  if (...)
  {
    if (...)
    {
      free(pingSendBuf);
      free(pongRecvBuf);
    }
    else
      free(pingRecvBuf);
  }

  barrierMPIOMP();
}

void barrierMPIOMP()
{
  #pragma omp barrier
  #pragma omp master
  MPI_Barrier(MPI_COMM_WORLD);
  #pragma omp barrier
}
