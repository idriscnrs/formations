#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

#define IDX(i,j,k) ((ny + 4) * (nz + 4) * (i + 2) + (nz + 4) * (j + 2) + (k + 2))
