/*
 * Parallel Hybrid PingPong with threads support level of type Funneled
 * Computation of the sustained network bandwidth between two nodes,
 * with nbMPIProcs/2 MPI process per node and as many parallel streams of communication
 * Execution on 2 nodes.
 */

#include <stdlib.h>
#include <stdio.h>

#include <mpi.h>
#include <omp.h>

#define NB_SIZES 3

void barrierMPIOMP();
void pingPongPar(int myMPIRank, int nbMPIProcs, int myOMPRank,
                 int tailleMo, int nbElBufLoc, int nbElBuf,
                 double *pingSendBuf, double *pingRecvBuf, double *pongRecvBuf);

int main(int argc, char **argv)
{
  int myMPIRank, nbMPIProcs;
  int myOMPRank, nbOMPThds, nbOMPComm;
  int nbElBuf, nbElBufLoc;
  int level_mpi_provided;
  const int tailleBufMo[NB_SIZES] = { 1, 10, 100 };
  double *pingSendBuf, *pingRecvBuf, *pongRecvBuf;
  
  // MPI Initialization
  MPI_Init_thread(&argc, &argv, MPI_THREAD_FUNNELED, &level_mpi_provided);
  // Set myMPIRank & nbMPIProcs
  MPI_Comm_rank(MPI_COMM_WORLD, &myMPIRank);
  MPI_Comm_size(MPI_COMM_WORLD, &nbMPIProcs);
  if (level_mpi_provided < MPI_THREAD_FUNNELED)
  {
    if (myMPIRank == 0)
      printf("Error: level_mpi_provided < MPI_THREAD_FUNNELED\n");
    MPI_Abort(MPI_COMM_WORLD, 1);
  }

  // OpenMP parallel region
  #pragma omp parallel private(myOMPRank)
  {
    // Rank of the OpenMP thread
    myOMPRank = omp_get_thread_num();
    
    #pragma omp master
    {
      // Number of OpenMP threads per MPI process
      nbOMPThds = omp_get_num_threads();
      
      // Output information of the run (only one time)
      if (myMPIRank == 0)
        printf("Execution sur %d processus MPI constitues de %d threads OpenMP\n", nbMPIProcs, nbOMPThds);
    }
    
    // Hybrid synchronization barrier
    barrierMPIOMP();
    
    // Loop on the message sizes (1 MB, 10 MB and 100 MB)
    for (int i = 0; i < NB_SIZES; i++)
    {
      // Allocation of memory only by one thread
      #pragma omp single
      {
        // Number of elements in the buffers
        nbElBufLoc = 1e6 * tailleBufMo[i] / (8 * nbOMPThds);
        nbElBuf = nbElBufLoc * nbOMPThds;
        
        // Allocations of send and receive buffers
        if (myMPIRank < nbMPIProcs / 2)
        {
          // 1st half are sending and receiving
          pingSendBuf = (double*)malloc(nbElBuf * sizeof(double));
          pongRecvBuf = (double*)malloc(nbElBuf * sizeof(double));
        }
        else
        {
          // 2nd half are receiving and sending using the same buffer
          pingRecvBuf = (double*)malloc(nbElBuf * sizeof(double));
        }
      }
      
      pingPongPar(myMPIRank, nbMPIProcs, myOMPRank,
                  tailleBufMo[i], nbElBufLoc, nbElBuf,
                  pingSendBuf, pingRecvBuf, pongRecvBuf);
      
      // Deallocation of memory
      #pragma omp single
      {
        // Deallocations of send and receive buffers
        if (myMPIRank < nbMPIProcs / 2)
        {
          free(pingSendBuf);
          free(pongRecvBuf);
        }
        else
          free(pingRecvBuf);
      }
    }
  } // End of OpenMP parallel region
  
  // Finalization of MPI environment
  MPI_Finalize();
  
  return EXIT_SUCCESS;
}

void pingPongPar(int myMPIRank, int nbMPIProcs, int myOMPRank,
                 int tailleMo, int nbElBufLoc, int nbElBuf,
                 double *pingSendBuf, double *pingRecvBuf, double *pongRecvBuf)
{
  // Parallel initialization of pingSendBuf, each thread
  // initializes a slice of buffer pingSendBuf
  if (myMPIRank < nbMPIProcs / 2)
  {
    for (int i = myOMPRank * nbElBufLoc, iEnd = (myOMPRank + 1) * nbElBufLoc; i < iEnd; i++)
      pingSendBuf[i] = myOMPRank;
  }
  
  #pragma omp barrier
  
  #pragma omp master
  {
    double startTime, endTime;
    MPI_Status statut;
    
    // Number of iterations for a total data transfert of 1 GB pingPong
    int nbIter = 1000 / tailleMo;
    
    // Who to send (sendRank), who to receive (recvRank) ?
    int sendRank = (myMPIRank + nbMPIProcs / 2) % nbMPIProcs;
    int recvRank = sendRank;
    int tagping = 1;
    int tagpong = 2;
    
    // Communications between MPI processes
    MPI_Barrier(MPI_COMM_WORLD);
    
    // Timer for the parallel PingPong on node 0
    if (myMPIRank == 0)
      startTime = MPI_Wtime();
    
    // Loop to get the equivalent of 1 GB data transfert per pingpong
    for (int iter = 0; iter < nbIter; iter++)
    {
      if (myMPIRank < nbMPIProcs / 2)
      {
        // Ping : Send pingSendBuf to sendRank
        MPI_Send(pingSendBuf, nbElBuf, MPI_DOUBLE_PRECISION, sendRank, tagping, MPI_COMM_WORLD);
        // Pong : Receive of sendRank in pongRecvBuf
        MPI_Recv(pongRecvBuf, nbElBuf, MPI_DOUBLE_PRECISION, recvRank, tagpong, MPI_COMM_WORLD, &statut);
      }
      else
      {
        // Ping : Receive from sendRank in pingRecvBuf
        MPI_Recv(pingRecvBuf, nbElBuf, MPI_DOUBLE_PRECISION, recvRank, tagping, MPI_COMM_WORLD, &statut);
        // Pong : Send pingRecvBuf to sendRank
        MPI_Send(pingRecvBuf, nbElBuf, MPI_DOUBLE_PRECISION, sendRank, tagpong, MPI_COMM_WORLD);
      }
      // Waiting for Pong completion
      MPI_Barrier(MPI_COMM_WORLD);
    }
    
    // End of timing and output of sustained bandwidth
    if (myMPIRank == 0)
    {
      endTime = MPI_Wtime();
      printf("Taille msg = %5d Mo, tps elapsed = %.3e, debit = %.3e Mo/s\n",
             tailleMo, endTime - startTime, nbMPIProcs / 2 * nbIter * 2.0 * tailleMo / (endTime - startTime));
    }
  }
  
  // Hybrid synchronization barrier
  barrierMPIOMP();
}

void barrierMPIOMP()
{
  #pragma omp barrier
  #pragma omp master
  MPI_Barrier(MPI_COMM_WORLD);
  #pragma omp barrier
}
