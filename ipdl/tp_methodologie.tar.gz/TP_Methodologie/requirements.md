# Lab Environment Setup

The notebooks are optimized for use on the Jean Zay supercomputer and are provided as is. They have been developed and tested with specific library versions, but they are designed to be flexible with regards to the software environment.

## Jupyter Notebook Environment
For this lab, a Jupyter Notebook environment is essential. Ensure you have access to a Jupyter environment to run the notebooks.

## Python Library Requirements
The notebooks have been thoroughly tested on the Jean Zay supercomputing environment with the specified versions of libraries. While exact versions are listed for optimal compatibility, slight variations in versions may be acceptable, especially for libraries other than `torch` and `torchaudio`. Below are the library versions used:

- IPython: 8.18.1
- matplotlib: 3.8.2
- numpy: 1.24.4
- pandas: 2.1.3
- seaborn: 0.13.0
- sklearn: 1.3.2
- torch: 2.1.1
- torchaudio: 2.1.1
- torchvision: 0.16.1
- tqdm: 4.66.1

It is crucial that your installation of `torch` and `torchaudio` is functional, as compatibility issues may arise with different versions of `torchaudio`, particularly changes related to the GTZAN class.

## Dataset Requirements:
For this lab, two versions of the GTZAN dataset are utilized:

1. **Full GTZAN Dataset:** Available directly through the `torchaudio` library. For details and download instructions, visit the [torchaudio.datasets.GTZAN](https://pytorch.org/audio/main/generated/torchaudio.datasets.GTZAN.html) documentation page.

2. **Preprocessed GTZAN Dataset (Feature CSVs):** A version of the GTZAN dataset processed into features, available in CSV format. This dataset can be downloaded from Kaggle at [GTZAN Dataset - Music Genre Classification](https://www.kaggle.com/datasets/andradaolteanu/gtzan-dataset-music-genre-classification).

You will have to change the paths to the datasets in the notebooks.