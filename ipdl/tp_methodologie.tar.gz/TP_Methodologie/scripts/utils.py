from __future__ import print_function
import os 
from torch.utils.data import random_split, ConcatDataset
from torch import Generator
import numpy as np
from .dataset import *
from .models import *

import torch.nn.functional as F
from torch.autograd import Variable

import matplotlib.pyplot as plt
import seaborn as sns
from sklearn import preprocessing
from sklearn.decomposition import PCA

import pandas as pd

import time

def plot_loss(train_loss, val_loss):
    train_loss = [l.cpu() for l in train_loss]
    plt.plot(range(1, len(train_loss) + 1), train_loss, 'b', label='Training loss')
    plt.plot(range(1, len(val_loss) + 1), val_loss, 'r', label='Validation loss')
    plt.title('Training and validation loss')
    plt.xlabel('epoch')
    plt.ylabel('loss')
    plt.legend()
    plt.show()
    
def plot_accuracy(train_acc, val_acc):
    plt.plot(range(1, len(train_acc) + 1), train_acc, 'b', label='Training acc')
    plt.plot(range(1, len(val_acc) + 1), val_acc, 'r', label='Validation acc')
    plt.title('Training and validation accuracy')
    plt.xlabel('epoch')
    plt.ylabel('accuracy')
    plt.legend()
    plt.figure()

def crop_audio(waveform, duration=10, samplerate=22050, augment=False):
    nbr_samples = duration*samplerate
    if augment:
        start = np.random.randint(0, (np.shape(waveform)[1]-duration*samplerate))
        end = start + nbr_samples
    else:
        start = 0
        end = nbr_samples
    waveform = waveform[:, start:end]
    return waveform

def compute_correlation_matrix(data, stat = 'mean', show = True):
    spike_cols = [col for col in data.columns if stat in col]
    corr = data[spike_cols].corr()


    if show:
        # Generate a mask for the upper triangle
        mask = np.triu(np.ones_like(corr, dtype=np.bool))

        # Set up the matplotlib figure
        f, ax = plt.subplots(figsize=(16, 11));

        # Generate a custom diverging colormap
        cmap = sns.diverging_palette(240, 10, as_cmap=True, s = 90, l = 45, n = 5)

        # Draw the heatmap with the mask and correct aspect ratio
        if stat == 'var':
            stat =='variance'
        plt.title('Correlation Heatmap (for the '+stat +')', fontsize = 25)
        plt.xticks(fontsize = 10)
        plt.yticks(fontsize = 10)
        sns.heatmap(corr, mask=mask, cmap=cmap, vmax=.3, center=0,
                    square=True, linewidths=.5, cbar_kws={"shrink": .5})

    
    return corr

def boxplot(data, feature='tempo'):

    x = data[["label", feature]]

    f, ax = plt.subplots(figsize=(16, 9));
    sns.boxplot(x = "label", y = feature, data = x, palette = 'husl');

    plt.title('BPM Boxplot for ' + feature, fontsize = 25)
    plt.xticks(fontsize = 14)
    plt.yticks(fontsize = 10);
    plt.xlabel("Genre", fontsize = 15)
    plt.ylabel(feature, fontsize = 15)
    

def pca(data):
    data = data.iloc[0:, 1:]
    y = data['label']
    X = data.loc[:, data.columns != 'label']

    #### NORMALIZE X ####
    cols = X.columns
    min_max_scaler = preprocessing.MinMaxScaler()
    np_scaled = min_max_scaler.fit_transform(X)
    X = pd.DataFrame(np_scaled, columns = cols)

    #### PCA 2 COMPONENTS ####
    pca = PCA(n_components=2)
    principalComponents = pca.fit_transform(X)
    principalDf = pd.DataFrame(data = principalComponents, columns = ['principal component 1', 'principal component 2'])

    # concatenate with target label
    finalDf = pd.concat([principalDf, y], axis = 1)

    pca.explained_variance_ratio_
    
    plt.figure(figsize = (16, 9))
    sns.scatterplot(x = "principal component 1", y = "principal component 2", data = finalDf, hue = "label", alpha = 0.7,s = 100)
    plt.title('PCA on Genres', fontsize = 25)
    plt.xticks(fontsize = 14)
    plt.yticks(fontsize = 10)
    plt.xlabel("Principal Component 1", fontsize = 15)
    plt.ylabel("Principal Component 2", fontsize = 15)
 
    return principalComponents





def check_sizes(set):
    sizes = []
    for i in range(len(set)):
        sizes.append(np.shape(set[i][0]))
    sizes = np.unique(sizes, axis=0)
    
    if len(sizes)==1:
        size_uniformity = True
        print('Items all have the same dimensions : ', sizes)
    else: 
        size_uniformity = False
        print('Items DO NOT all have the same dimensions :', sizes)
    return size_uniformity, sizes

def list_classes(rootdir):
    classes = []
    for file in os.listdir(rootdir):
        d = os.path.join(rootdir, file)
        if os.path.isdir(d):
            classes.append(file)
    return classes

def load_gtzan_sets(root = '.', filtered = True, generator = 'default', train_ratio=0.8, valid_ratio=0.1, test_ratio=0.2, transform = None, target_transform = None):
    assert train_ratio + valid_ratio + test_ratio == 1, 'Ratio sum not equal to 1'
    if generator=='default':
        train_set = GTZAN(root, download=True, subset = 'training', transform= transform, target_transform = target_transform)
        valid_set = GTZAN(root, download=True, subset = 'validation', transform= transform, target_transform = target_transform)
        test_set = GTZAN(root, download=True, subset = 'testing', transform= transform, target_transform = target_transform)
    else:
        if filtered:
            train_set = GTZAN(root, download=True, subset = 'training', transform= transform, target_transform = target_transform)
            valid_set = GTZAN(root, download=True, subset = 'validation', transform= transform, target_transform = target_transform)
            test_set = GTZAN(root, download=True, subset = 'testing', transform= transform, target_transform = target_transform)
            dataset = ConcatDataset([train_set, valid_set, test_set])
        else:
            dataset = GTZAN(root, download=True, transform= transform, target_transform = target_transform)

        dataset_size = len(dataset)    
        train_size = int(train_ratio*dataset_size)
        valid_size = int(valid_ratio*dataset_size)
        test_size = dataset_size - train_size - valid_size
        seed = Generator().manual_seed(generator)
        train_set, valid_set, test_set = random_split(dataset, (train_size, valid_size, test_size), seed)            
    return train_set, valid_set, test_set

def to_device(data, device):
    """Move tensor(s) to chosen device"""
    if isinstance(data, (list,tuple)):
        return [to_device(x, device) for x in data]
    return data.to(device, non_blocking=True)




def train_basic(loader, model, criterion, optimizer, epoch, device, log_interval, verbose=True):
    model.train()
    train_loss = 0
    for batch_idx, (data, samplerate, label, target) in enumerate(loader):
        data = data.to(device)
        target = target.to(device)
        optimizer.zero_grad()
        output = model(data)
        loss = criterion(output,target)
        loss.backward()
        optimizer.step()
        train_loss += loss.data
        if verbose:
            if batch_idx % log_interval == 0:
                print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
                    epoch, batch_idx * len(data), len(loader.dataset), 100.
                    * batch_idx / len(loader), loss.data))
    return train_loss / len(loader.dataset)



#F.nll_loss(output, target)
#data, target = Variable(data), Variable(target)

import torch
#import ipywidgets as widgets
#from IPython.display import display


def train(train_loader, val_loader, model, optimizer, criterion, start_epoch, nbr_epochs=100, device='cpu', epoch_interval = 1, batch_interval = 100, verbose=True, models_dir = None, experiment_name = None, history=None):
    
   try:

        print('train() called: model=%s, opt=%s(lr=%f), epochs=%d, device=%s\n' % \
              (type(model).__name__, type(optimizer).__name__,
               optimizer.param_groups[0]['lr'], nbr_epochs, device))

        if history == None:
            history = {} # Collects per-epoch loss and acc like Keras' fit().
            history['loss'] = []
            history['val_loss'] = []
            history['acc'] = []
            history['val_acc'] = []





        start_time_sec = time.time()
        for epoch in range(start_epoch, nbr_epochs+1):

            # --- TRAIN AND EVALUATE ON TRAINING SET -----------------------------
            model.train()
            train_loss         = 0.0
            num_train_correct  = 0
            num_train_examples = 0



            for batch_idx, (data, samplerate, label, target) in enumerate(train_loader):
                optimizer.zero_grad()

                data = data.to(device)
                target = target.to(device)

                output = model(data)
                loss = criterion(output,target)
                loss.backward()
                optimizer.step()
                train_loss += loss.data

                if verbose:
                    if batch_idx % batch_interval == 0:
                        print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
                            epoch, batch_idx * len(data), len(train_loader.dataset), 100.
                            * batch_idx / len(train_loader), loss.data))


                train_loss         += loss.data.item() * data.size(0)
                num_train_correct  += (torch.max(output, 1)[1] == target).sum().item()
                num_train_examples += data.shape[0]



            train_acc   = num_train_correct / num_train_examples
            train_loss  = train_loss / len(train_loader.dataset)


            # --- EVALUATE ON VALIDATION SET -------------------------------------
            model.eval()
            val_loss       = 0.0
            num_val_correct  = 0
            num_val_examples = 0

            for batch_idx, (data, samplerate, label, target) in enumerate(val_loader):

                data = data.to(device)
                target = target.to(device)
                output = model(data)
                loss = criterion(output,target)

                val_loss         += loss.data.item() * data.size(0)
                num_val_correct  += (torch.max(output, 1)[1] == target).sum().item()
                num_val_examples += target.shape[0]

            val_acc  = num_val_correct / num_val_examples
            val_loss = val_loss / len(val_loader.dataset)

            if verbose:
                if epoch == 1 or epoch % epoch_interval == 0:
                  print('Epoch %3d/%3d, train loss: %5.2f, train acc: %5.2f, val loss: %5.2f, val acc: %5.2f' % \
                        (epoch, nbr_epochs, train_loss, train_acc, val_loss, val_acc))


            history['loss'].append(train_loss)
            history['val_loss'].append(val_loss)
            history['acc'].append(train_acc)
            history['val_acc'].append(val_acc)

            if val_loss <= np.min(history['val_loss']):
                if not os.path.isdir(models_dir):
                    os.mkdir(models_dir)
                file_name = experiment_name + '_' + 'val' + '_' +f"{val_loss:.5f}" + '.t7'
                file_path = os.path.join(models_dir, file_name)
                torch.save(model, file_path)
                print('Validation loss < Best validation loss => Model sauvegardé : ', file_path)



            
        # END OF TRAINING LOOP


        end_time_sec       = time.time()
        total_time_sec     = end_time_sec - start_time_sec
        time_per_epoch_sec = total_time_sec / (nbr_epochs - start_epoch)
        print()
        print('Time total:     %5.2f sec' % (total_time_sec))
        print('Time per epoch: %5.2f sec' % (time_per_epoch_sec))

        return model, history, epoch
      
   except KeyboardInterrupt:
      # do nothing here
      return model, history, epoch


def test(loader, model, criterion, device, verbose=True):
    model.eval()
    test_loss = 0
    correct = 0
    predictions, targets = [], []

    for batch_idx, (data, samplerate, label, target) in enumerate(loader):
        data, target = data.to(device), target.to(device)
        data, target = Variable(data, volatile=True), Variable(target)
        output = model(data)
        test_loss += criterion(output, target).data # sum up batch loss
        pred = output.data.max(1, keepdim=True)[1]  # get the index of the max log-probability
        correct += pred.eq(target.data.view_as(pred)).cpu().sum()

        # convert to numpy arrays
        #pred = pred.cpu().numpy()
        #label = label.numpy()

        for i in range(len(pred)):
            predictions.append(pred[i].item())
            targets.append(target[i].item())

        
    test_loss /= len(loader.dataset)
    if verbose:
        print('\nTest set: Average loss: {:.4f}, Accuracy: {}/{} ({:.0f}%)\n'.format(
            test_loss, correct, len(loader.dataset), 100. * correct / len(loader.dataset)))
        
        
        
    return test_loss, predictions, targets

