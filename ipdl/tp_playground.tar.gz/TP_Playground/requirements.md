## Lab Environment Setup


## Environment Setup for Practical Lab
For this practical lab, the only requirement is a web browser with internet access. This setup ensures that you can readily access all necessary online tools and resources without the need for complex installations.

## Alternative Local Setup
For those interested in a local setup, it is possible to install TensorFlow Playground directly on your machine. TensorFlow Playground provides an interactive visualization of neural networks, which can be beneficial for hands-on learning. For installation, visit the TensorFlow Playground GitHub repository:

[https://github.com/tensorflow/playground](https://github.com/tensorflow/playground)

## Dataset Requirements:
There are no specific dataset requirements for this practical lab.
