# Lab Environment Setup

The notebooks are optimized for use on the Jean Zay supercomputer and are provided as is. They have been developed and tested with specific library versions, but they are designed to be flexible with regards to the software environment.

## Jupyter Notebook Environment
For this lab, a Jupyter Notebook environment is essential. Ensure you have access to a Jupyter environment to run the notebooks.

## Python Library Requirements
The notebooks have been tested with the following library versions. While specific versions are listed, the notebooks are generally compatible with other recent versions of these libraries, unless noted otherwise.

- **matplotlib:** Version 3.8.2 or newer. The notebooks should be compatible with any relatively recent version of matplotlib.
- **torch:** Version 2.1.1 is recommended. To utilize the full functionality of the notebooks, including the "torch.compile" bonus section, a version of torch 2.0 or higher is required. However, most of the notebooks should function with torch versions 1.11 and above without significant issues.

## Additional Tools for Torch Profiler Visualization
To visualize the torch profiler data, you will need to install the following tools:

- `torch-tb-profiler`: This tool is necessary for detailed performance analysis and visualization.
- `tensorboard`: Required for general visualization purposes and to work in tandem with `torch-tb-profiler`.

## Dataset Requirements
There are no specific dataset requirements for this practical lab.

