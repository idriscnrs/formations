program pair_impair
  USE MPI_F08
  implicit none

  integer :: rang,nb_processus

  call MPI_INIT()

  call MPI_COMM_RANK(MPI_COMM_WORLD,rang)
  call MPI_COMM_SIZE(MPI_COMM_WORLD,nb_processus)

  if (mod(rang,2) == 0) then
    print *,'Coucou, je suis le processus pair   ',rang
  else
    print *,'Coucou, je suis le processus impair ',rang
  end if

  call MPI_FINALIZE()

end program pair_impair
