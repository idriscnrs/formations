program pair_impair
  USE MPI
  implicit none

  integer :: rang,nb_processus,code

  call MPI_INIT(code)

  call MPI_COMM_RANK(MPI_COMM_WORLD,rang,code)
  call MPI_COMM_SIZE(MPI_COMM_WORLD,nb_processus,code)

  if (mod(rang,2) == 0) then
    print *,'Coucou, je suis le processus pair   ',rang
  else
    print *,'Coucou, je suis le processus impair ',rang
  end if

  call MPI_FINALIZE(code)

end program pair_impair
