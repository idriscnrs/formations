program ping_pong_1
  use, intrinsic :: iso_fortran_env, only : dp => real64
  USE MPI_F08
  implicit none

  TYPE(MPI_Status)                     :: statut
  integer, parameter                   :: nb_valeurs=1000,etiquette=99
  integer                              :: rang
  real(kind=dp), dimension(nb_valeurs) :: valeurs
  TYPE(MPI_Datatype)                   :: typedp

! TODO: Initialisation MPI & recuperation du rang

    ! Remplir avec des nombres aleatoires
    call random_number(valeurs)
    ! TODO : Processus 0 envoie valeurs au processus 1


    ! TODO: Processus 1 recoit valeurs du processus 0

    print ('("Moi, processus 1, j''ai recu ",i4," valeurs (derniere = ", &
           & f4.2,") du processus 0.")'), nb_valeurs,valeurs(nb_valeurs)

! TODO: Finaliser MPI

end program ping_pong_1
