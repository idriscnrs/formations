program ping_pong_2
  use, intrinsic :: iso_fortran_env, only : dp => real64
  USE MPI_F08
  implicit none

  TYPE(MPI_Status)                     :: statut
  integer, parameter                   :: nb_valeurs=1000,etiquette=99
  integer                              :: rang
  real(kind=dp)                        :: temps_debut,temps_fin
  real(kind=dp), dimension(nb_valeurs) :: valeurs
  TYPE(MPI_Datatype)                   :: typedp

  ! TODO: Recuperation du rang -> rang

  if (rang == 0) then
    call random_number(valeurs)
    ! TODO: Debut de prise de temps du ping pong -> temps_debut

    ! TODO: Processus 0: envoie et recoit du processus 1

    ! TODO: Fin de prise de temps du ping pong -> temps_fin

    print ('("Moi, processus 0, j''ai envoye et recu ",i5, &
        & " valeurs (derniere = ",f4.2,") du processus 1", &
        & " en ",f8.6," secondes.")'), &
          nb_valeurs,valeurs(nb_valeurs),temps_fin-temps_debut

    ! TODO: Processus 1: recoit et envoie au processus 0

  end if

! TODO: Finaliser MPI

end program ping_pong_2
