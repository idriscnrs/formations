program ping_pong_3
  use, intrinsic :: iso_fortran_env, only : dp => real64
  USE MPI_F08
  implicit none

  TYPE(MPI_Status)                             :: statut
  integer, parameter                           :: nb_valeurs_max=7000000, &
       nb_tests=10,etiquette=99
  integer, dimension(nb_tests)                 :: nb_valeurs
  integer                                      :: rang,i
  real(kind=dp), dimension(0:nb_valeurs_max-1) :: valeurs
  TYPE(MPI_Datatype)                           :: typedp
  real(kind=dp)                                :: temps_debut,temps_fin

  ! TODO: Recuperation du rang -> rang

  ! Listes des tailles de messages a tester
  nb_valeurs = (/ 0,0,1,10,100,1000,10000,100000,1000000,7000000 /)

  do i=1,nb_tests
    if (rang == 0) then
      call random_number(valeurs)
      ! TODO: Debut de la prise de temps du ping pong -> temps_debut

      ! TODO: Processus 0: Envoie et recoit du processus 1
      
      ! TODO: Fin de la prise de temps du ping pong -> temps_fin
      call affichage
    elseif (rang == 1) then
      ! TODO: Processus 1: Recoit et envoie au processus 0
    end if
  end do
  ! TODO: Finaliser MPI
  
contains
  subroutine affichage
    if (nb_valeurs(i)/=0) then
      print ('("Moi, processus 0, j''ai envoye et recu ",i8, &
            & " valeurs (derniere = ",f4.2,") du processus 1", &
            & " en ",f8.6," secondes, soit avec un debit de ",f7.2, &
            & " Mo/s.")'), &
            nb_valeurs(i),valeurs(nb_valeurs(i)-1),temps_fin-temps_debut, &
            real(2*nb_valeurs(i)*8)/1000000./(temps_fin-temps_debut)
    else
      print ('("Moi, processus 0, j''ai envoye et recu ",i8, &
            & " valeurs en ",f8.6," secondes, soit avec un debit de ",f7.2, &
            & " Mo/s.")'), &
            nb_valeurs(i),temps_fin-temps_debut, &
            real(2*nb_valeurs(i)*8)/1000000./(temps_fin-temps_debut)
    end if
  end subroutine affichage
end program ping_pong_3
