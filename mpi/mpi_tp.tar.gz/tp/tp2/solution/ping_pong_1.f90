program ping_pong_1
  use, intrinsic :: iso_fortran_env, only : dp => real64
  USE MPI_F08
  implicit none

  TYPE(MPI_Status)                     :: statut
  integer, parameter                   :: nb_valeurs=1000,etiquette=99
  integer                              :: rang
  real(kind=dp), dimension(nb_valeurs) :: valeurs
  TYPE(MPI_Datatype)                   :: typedp

  ! Initialisation MPI & recuperation du rang
  call MPI_INIT()
  call MPI_COMM_RANK(MPI_COMM_WORLD,rang)
  call MPI_TYPE_CREATE_F90_REAL(precision(valeurs(1)),range(valeurs(1)),typedp)

  if (rang == 0) then
    ! Remplir avec des nombres aleatoires
    call random_number(valeurs)
    ! Processus 0 envoie valeurs au processus 1
    call MPI_SEND(valeurs,nb_valeurs,typedp,1,etiquette, &
                  MPI_COMM_WORLD)
  elseif (rang == 1) then
    ! Processus 1 recoit valeurs du processus 0
    call MPI_RECV(valeurs,nb_valeurs,typedp,0,etiquette, &
                  MPI_COMM_WORLD,statut)
    print ('("Moi, processus 1, j''ai recu ",i4," valeurs (derniere = ", &
           & f4.2,") du processus 0.")'), nb_valeurs,valeurs(nb_valeurs)
  end if
  ! Finaliser MPI
  call MPI_FINALIZE()
end program ping_pong_1
