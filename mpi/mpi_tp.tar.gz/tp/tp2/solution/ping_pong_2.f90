program ping_pong_2
  use, intrinsic :: iso_fortran_env, only : dp => real64
  USE MPI_F08
  implicit none

  TYPE(MPI_Status)                     :: statut
  integer, parameter                   :: nb_valeurs=1000,etiquette=99
  integer                              :: rang
  real(kind=dp)                        :: temps_debut,temps_fin
  real(kind=dp), dimension(nb_valeurs) :: valeurs
  TYPE(MPI_Datatype)                   :: typedp

  ! Recuperation du rang -> rang
  call MPI_INIT()
  call MPI_COMM_RANK(MPI_COMM_WORLD,rang)
  call MPI_TYPE_CREATE_F90_REAL(precision(valeurs(1)),range(valeurs(1)),typedp)

  if (rang == 0) then
    call random_number(valeurs)
    ! Debut de prise de temps du ping pong -> temps_debut
    temps_debut=MPI_WTIME()
    ! Processus 0: envoie et recoit du processus 1
    call MPI_SEND(valeurs,nb_valeurs,typedp,1,etiquette, &
                  MPI_COMM_WORLD)
    call MPI_RECV(valeurs,nb_valeurs,typedp,1,etiquette, &
                  MPI_COMM_WORLD,statut)
    ! Fin de prise de temps du ping pong -> temps_fin
    temps_fin=MPI_WTIME()
    print ('("Moi, processus 0, j''ai envoye et recu ",i5, &
        & " valeurs (derniere = ",f4.2,") du processus 1", &
        & " en ",f8.6," secondes.")'), &
          nb_valeurs,valeurs(nb_valeurs),temps_fin-temps_debut
  elseif (rang == 1) then
    ! Processus 1: recoit et envoie au processus 0
    call MPI_RECV(valeurs,nb_valeurs,typedp,0,etiquette, &
                  MPI_COMM_WORLD,statut)
    call MPI_SEND(valeurs,nb_valeurs,typedp,0,etiquette, &
                  MPI_COMM_WORLD)
  end if
  ! Finaliser MPI
  call MPI_FINALIZE()
end program ping_pong_2
