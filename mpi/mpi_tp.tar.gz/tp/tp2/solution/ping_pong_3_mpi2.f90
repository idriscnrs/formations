program ping_pong_3
  use, intrinsic :: iso_fortran_env, only : dp => real64
  USE MPI
  implicit none

  integer, dimension(MPI_STATUS_SIZE)          :: statut
  integer, parameter                           :: nb_valeurs_max=7000000, &
       nb_tests=10,etiquette=99
  integer, dimension(nb_tests)                 :: nb_valeurs
  integer                                      :: rang,code,i
  real(kind=dp), dimension(0:nb_valeurs_max-1) :: valeurs
  integer                                      :: typedp
  real(kind=dp)                                :: temps_debut,temps_fin

  ! Recuperation du rang -> rang
  call MPI_INIT(code)
  call MPI_COMM_RANK(MPI_COMM_WORLD,rang,code)
  call MPI_TYPE_CREATE_F90_REAL(precision(valeurs(1)),range(valeurs(1)),typedp,code)

  nb_valeurs = (/ 0,0,1,10,100,1000,10000,100000,1000000,7000000 /)

  do i=1,nb_tests
    if (rang == 0) then
      call random_number(valeurs)
      ! Debut de la prise de temps du ping pong -> temps_debut
      temps_debut=MPI_WTIME()
      ! Processus 0: Envoie et recoit du processus 1
      call MPI_SEND(valeurs,nb_valeurs(i),typedp,1,etiquette, &
                    MPI_COMM_WORLD,code)
      call MPI_RECV(valeurs,nb_valeurs(i),typedp,1,etiquette, &
                    MPI_COMM_WORLD,statut,code)
      ! Fin de la prise de temps du ping pong -> temps_fin
      temps_fin=MPI_WTIME()
      call affichage
    elseif (rang == 1) then
      ! Processus 1: Recoit et envoie au processus 0
      call MPI_RECV(valeurs,nb_valeurs(i),typedp,0,etiquette, &
                    MPI_COMM_WORLD,statut,code)
      call MPI_SEND(valeurs,nb_valeurs(i),typedp,0,etiquette, &
                    MPI_COMM_WORLD,code)
    end if
  end do
  ! Finaliser MPI
  call MPI_FINALIZE(code)
contains
  subroutine affichage
    if (nb_valeurs(i)/=0) then
      print ('("Moi, processus 0, j''ai envoye et recu ",i8, &
            & " valeurs (derniere = ",f4.2,") du processus 1", &
            & " en ",f8.6," secondes, soit avec un debit de ",f7.2, &
            & " Mo/s.")'), &
            nb_valeurs(i),valeurs(nb_valeurs(i)-1),temps_fin-temps_debut, &
            real(2*nb_valeurs(i)*8)/1000000./(temps_fin-temps_debut)
    else
      print ('("Moi, processus 0, j''ai envoye et recu ",i8, &
            & " valeurs en ",f8.6," secondes, soit avec un debit de ",f7.2, &
            & " Mo/s.")'), &
            nb_valeurs(i),temps_fin-temps_debut, &
            real(2*nb_valeurs(i)*8)/1000000./(temps_fin-temps_debut)
    end if
  end subroutine affichage
end program ping_pong_3
