program pi
  use, intrinsic :: iso_fortran_env, only : dp => real64, li => int64
  implicit none
  integer(kind=li)   :: nbbloc,i
  real(kind=dp)      :: largeur,somme,x

  ! Nombre d'intervalles
  nbbloc = 3*1000*1000_li*100
  ! largeur des intervalles
  largeur = 1._dp / real(nbbloc,dp)

  somme = 0._dp

  do i=1, nbbloc
    ! Point au milieu de l'intervalle
    x = largeur*(i-0.5_dp)
    ! Calcul de l'aire
    somme = somme + largeur*(4._dp / (1._dp + x*x))
  end do

  print *, "Pi =", somme
  print *, "Ecart =", somme-4._dp*atan(1._dp)
end program
