program pi
  use, intrinsic :: iso_fortran_env, only : dp => real64, li => int64
  use mpi_f08
  implicit none
  integer            :: rang, nbprocs
  integer(kind=li)   :: nbbloc,i,debut,fin
  real(kind=dp)      :: largeur,somme,global,x
  TYPE(MPI_Datatype) :: typedp,typeli

  call MPI_INIT()
  call MPI_COMM_RANK(MPI_COMM_WORLD,rang)
  call MPI_COMM_SIZE(MPI_COMM_WORLD,nbprocs)

  ! Nombre d'intervalles
  nbbloc = 3*1000*1000_li*100
  ! largeur des intervalles
  largeur = 1._dp / real(nbbloc,dp)

  somme = 0._dp

  ! Distribution repartie (Attention aux overflow)
  ! rang*nbbloc must be less than 9.10^18
  debut = (rang*nbbloc)/nbprocs+1
  fin = ((rang+1)*nbbloc)/nbprocs

  ! Idem
  ! rang*nbbloc must be less than  9.10^15
  !debut = ((1._dp*rang)*nbbloc)/nbprocs+1
  !fin = ((1._dp*(rang+1))*nbbloc)/nbprocs

  ! Le reste est distribue sur les premiers rangs
  !debut = rang*(nbbloc/nbprocs)+1+min(rang,mod(nbbloc,nbprocs))
  !fin = debut+(nbbloc/nbprocs)-1
  !if (rang < mod(nbbloc,nbprocs)) fin = fin+1

  ! Le reste est distribue sur les derniers rangs
  !debut = rang*(nbbloc/nbprocs)+1+max(mod(nbbloc,nbprocs)+rang-nbprocs,0)
  !fin = debut+(nbbloc+rang)/nbprocs-1

  print "(i2,a,i11,a,i11,a,i11)", rang, " debut: ", debut, " fin: ", fin, " delta: ", fin-debut+1

  do i=debut, fin
    ! Point au milieu de l'intervalle
    x = largeur*(i-0.5_dp)
    ! Calcul de l'aire
    somme = somme + largeur*(4._dp / (1._dp + x*x))
  end do
  call MPI_TYPE_CREATE_F90_REAL(precision(somme),range(somme),typedp)
  call MPI_REDUCE(somme, global, 1, typedp, MPI_SUM, 0, MPI_COMM_WORLD)
  if (rang ==0) print *, "Pi =", global
  if (rang ==0) print *, "Ecart =", global-4._dp*atan(1._dp)
  call MPI_TYPE_CREATE_F90_INTEGER(range(debut),typeli)
  call MPI_REDUCE(fin-debut+1,i, 1, typeli, MPI_SUM, 0, MPI_COMM_WORLD)
  !call MPI_REDUCE(fin-debut+1,i, 1, MPI_INTEGER8, MPI_SUM, 0, MPI_COMM_WORLD)
  if (rang ==0) print *, "Nb =", i

  call MPI_FINALIZE()
end program
