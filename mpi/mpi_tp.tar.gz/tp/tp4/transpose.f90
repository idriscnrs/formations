PROGRAM transpose
  USE MPI_F08
  IMPLICIT NONE
  INTEGER, PARAMETER                         :: nb_lignes=5,nb_colonnes=4,&
                                                nb_lignes_t=4,nb_colonnes_t=5,&
                                                etiquette=1000
  INTEGER                                    :: rang,taille_reel,i
  TYPE(MPI_Datatype)                         :: type_ligne, type_transpose
  REAL, DIMENSION(nb_lignes,nb_colonnes)     :: A
  REAL, DIMENSION(nb_lignes_t,nb_colonnes_t) :: AT
  INTEGER(kind=MPI_ADDRESS_KIND)             :: pas
  TYPE(MPI_Status)                           :: statut

  ! TODO: Recuperation du rang -> rang

  !-- Initialisation de la matrice AT
  AT(:,:) = 0.

  ! TODO: Type transpose


  IF (rang == 0) THEN
    !Initialisation de la matrice A sur le processus 0
    A(:,:) = RESHAPE( (/ (i,i=1,nb_lignes*nb_colonnes) /), &
                      (/ nb_lignes,nb_colonnes /) )
    PRINT *,'Matrice A'
    DO i=1,nb_lignes
      PRINT *,A(i,:)
    END DO
    ! TODO: Processus 0: Envoie la matrice A au processus 1

  ELSE
    ! TODO: Processus 1: Recoit dans la matrice AT du processus 0

    PRINT *,'Matrice transposee AT'
    DO i=1,nb_lignes_t
      PRINT *,AT(i,:)
    END DO
  END IF

  ! TODO: Liberation des types MPI

  ! TODO: Finaliser MPI

END PROGRAM transpose
