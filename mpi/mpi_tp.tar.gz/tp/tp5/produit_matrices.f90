program produit_matrices
  use mpi_f08
  implicit none
  integer, parameter                  :: etiquette=1000
  integer                             :: rang, Nprocs, N, NL, k
  TYPE(MPI_Datatype)                  :: type_temp, type_tranche
  integer                             :: rang_suivant, rang_precedent, taille_type_reel
  TYPE(MPI_Status)                    :: statut
  real                                :: Emax
  real, allocatable, dimension(:,:)   :: A, B, C, CC, E
  real, allocatable, dimension(:,:)   :: AL, BL, CL, TEMP
  integer(kind=MPI_ADDRESS_KIND)      :: borne_inferieure=0, taille_deplacement_type_tranche
  character(len=256)                  :: arg

  ! TODO: Recuperation du rang et nombre de processus -> rang nprocs


  if (rang == 0) then
    if (command_argument_count() < 1) then
      N=4
    else
      call get_command_argument(1,arg)
      read(arg, '(i6)') N
    end if
  end if

  ! TODO: Diffusion de N a tous le monde
  

  ! Il faut que N soit divisible par Nprocs
  if ( mod(N, Nprocs) == 0 ) then
    if (rang == 0) print *, "Longueur matrice: ", N
    NL = N / Nprocs
  else
    print *, 'N=',N, ' n''est pas divisible par Nprocs=', Nprocs
    ! TODO: Arret du programme
    
  end if

  ! Le processus 0 initialise les matrices A et B
  if (rang == 0) then
    ! Allocation dynamique de mémoire, entre autres, des matrices A, B et C
    allocate( A(N,N), B(N,N), C(N,N), CC(N,N) )
    ! Initialisation de A et B
    call RANDOM_NUMBER(A)
    call RANDOM_NUMBER(B)
    ! Calcul monoprocesseur du produit matriciel A*B
    CC(:,:) = matmul(A(:,:), B(:,:))
  else
    ! Eviter problem avec option -check all
    allocate(A(0,0),B(0,0),C(0,0))
  end if

  ! Allocation dynamique de mémoire des divers tableaux locaux
  allocate( AL(NL,N), BL(N,NL), CL(N,NL), TEMP(NL,N) )

  ! TODO: Construction du type qui correspond a 1 bloc de NL lignes et N colonnes

  ! TODO: Distribution de A aux AL

  ! TODO: Distribution de B aux BL

  ! Calcul des blocs diagonaux de la matrice resultante.
  CL(rang*NL+1:(rang+1)*NL,:) = matmul( AL(:,:), BL(:,:) )

  ! Calcul des blocs extra-diagonaux
  ! Premier algorithme (deux fois plus coûteux que le second)
  do k = 0, Nprocs-1
    if (rang /= k) then
      ! TODO: Envoie AL au processus k et reception du AL de k dans temp
      
      ! Chaque processus calcule les blocs situés au-dessus
      ! et en dessous du bloc de la diagonale principale
      CL(k*NL+1:(k+1)*NL,:)=matmul(TEMP(:,:),BL(:,:))
    end if
  end do
  ! Second algorithme
!  rang_precedent = mod(Nprocs+rang-1,Nprocs)
!  rang_suivant   = mod(rang+1,Nprocs)
!  do k = 1, Nprocs-1
!    ! TODO: Envoie AL au rang_precedent et reception de rang_suivant
!    
!    ! Chaque processus calcule les blocs situés au-dessus
!    ! et en dessous du bloc de la diagonale principale
!    CL(mod(rang+k,Nprocs)*NL+1:(mod(rang+k,Nprocs)+1)*NL,:)=matmul(AL(:,:),BL(:,:))
!  end do

  ! TODO: Recuperation des CL pour former la matrice CC sur le processus 0
  

  ! Les tableaux locaux sont désormais inutiles
  deallocate( AL, BL, CL, TEMP )
  ! Vérification des résultats
  if (rang == 0) then
    allocate( E(N,N) )
    E(:,:) = abs(C(:,:) - CC(:,:))
    Emax   = maxval( E(:,:) ) / N**2
    deallocate( A, B, C, CC, E )
    if ( Emax <= epsilon(1.0) ) then
      print'(/,40X,"Bravo !",/,  &
            & 20X,"Le produit matriciel A*B calcule en parallele",/, &
            & 20X,"est bien egal a celui calcule en monoprocesseur")'
    else
      print'(/,33X,"Resultat incorrect !",/, &
            & 20X,"Le produit matriciel A*B calcule en parallele",/, &
            & 20X,"est different de celui calcule en monoprocesseur")'
    end if
  end if

  ! TODO: Finaliser MPI

end program produit_matrices
