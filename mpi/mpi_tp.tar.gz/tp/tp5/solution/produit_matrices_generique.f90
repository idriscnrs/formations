program produit_matrices
  use mpi_f08
  implicit none
  integer, parameter                  :: etiquette=1000
  integer                             :: rang, Nprocs, N, NL, k
  integer                             :: rang_suivant, rang_precedent, taille_type_reel
  TYPE(MPI_Status)                    :: statut
  real                                :: Emax
  real, allocatable, dimension(:,:)   :: A, B, C, CC, E
  real, allocatable, dimension(:,:)   :: AL, BL, CL, TEMP
  integer                             :: NLmax, reste
  TYPE(MPI_Datatype)                  :: type_tranche1, type_tranche2
  integer                             :: krang
  integer, allocatable, dimension(:)  :: Ndist
  integer, allocatable, dimension(:)  :: nbrS, decalageS
  TYPE(MPI_Datatype), allocatable, dimension(:) :: typeS, typeR
  integer, allocatable, dimension(:)  :: nbrR, decalageR
  integer, allocatable, dimension(:)  :: position
  character(len=256)                  :: arg

  ! Recuperation du rang et nombre de processus -> rang nprocs
  call MPI_INIT()
  call MPI_COMM_RANK(MPI_COMM_WORLD, rang)
  call MPI_COMM_SIZE(MPI_COMM_WORLD, Nprocs)

  if (rang == 0) then
    if (command_argument_count() < 1) then
      N=4
    else
      call get_command_argument(1,arg)
      read(arg, '(i6)') N
    end if
  end if

  ! Diffusion de N a tous le monde
  call MPI_BCAST(N, 1, MPI_INTEGER, 0, MPI_COMM_WORLD)

  if (rang == 0) print *, "Longueur matrice: ", N
  NL = N / Nprocs
  NLmax = NL
  reste = mod(N,Nprocs)
  NLmax=NLmax+1
  if (rang < reste) NL=NL+1
  allocate(Ndist(0:Nprocs-1))
  call MPI_ALLGATHER(NL,1,MPI_INTEGER,Ndist,1,MPI_INTEGER,MPI_COMM_WORLD)

  ! Le processus 0 initialise les matrices A et B
  if (rang == 0) then
    ! Allocation dynamique de mémoire, entre autres, des matrices A, B et C
    allocate( A(N,N), B(N,N), C(N,N), CC(N,N) )
    ! Initialisation de A et B
    call RANDOM_NUMBER(A)
    call RANDOM_NUMBER(B)
    ! Calcul monoprocesseur du produit matriciel A*B
    CC(:,:) = matmul(A(:,:), B(:,:))
  else
    ! Eviter problem avec option -check all
    allocate(A(0,0),B(0,0),C(0,0))
  end if

  ! Allocation dynamique de mémoire des divers tableaux locaux
  allocate( AL(NL,N), BL(N,NL), CL(N,NL), TEMP(NLmax,N) )

  ! Diffusion de A aux AL
  allocate(nbrS(Nprocs))
  allocate(decalageS(Nprocs))
  allocate(typeS(Nprocs))
  if (rang == 0) then
    nbrS(:) = 1
  else
    nbrS(:) = 0
  end if
  decalageS(1) = 0
  call MPI_TYPE_SIZE(MPI_REAL, taille_type_reel)
  do k=2, Nprocs
    decalageS(k) = decalageS(k-1)+Ndist(k-2)*taille_type_reel
  end do
  
  call MPI_TYPE_VECTOR(N, NLmax, N, MPI_REAL, type_tranche1)
  call MPI_TYPE_COMMIT(type_tranche1)
  call MPI_TYPE_VECTOR(N, NLmax-1, N, MPI_REAL, type_tranche2)
  call MPI_TYPE_COMMIT(type_tranche2)
  do k=1, Nprocs
    if (k-1 < reste) then
      typeS(k) = type_tranche1
    else
      typeS(k) = type_tranche2
    end if
  end do
  allocate(nbrR(Nprocs))
  allocate(decalageR(Nprocs))
  allocate(typeR(Nprocs))
  nbrR(:) = 0
  nbrR(1) = N*NL
  decalageR(:) = 0
  typeR(:) = MPI_REAL
  call MPI_ALLTOALLW(A, nbrS, decalageS, typeS, AL, nbrR, decalageR, typeR, MPI_COMM_WORLD)
  ! Diffusion de B aux BL
  nbrS(:) = 0
  decalageS(:) = 0
  do k=1, Nprocs
    nbrS(k) = N*Ndist(k-1)
  end do
  do k=2, Nprocs
    decalageS(k) = decalageS(k-1)+nbrS(k-1)
  end do
  call MPI_SCATTERV(B, nbrS, decalageS, MPI_REAL, BL, N*NL, MPI_REAL, 0, MPI_COMM_WORLD)

  ! Position dans C
  allocate(position(0:Nprocs))
  position(0) = 1
  do k=1, Nprocs
    position(k) = position(k-1)+Ndist(k-1)
  end do

  ! Calcul des blocs diagonaux de la matrice resultante.
  CL(position(rang):position(rang+1)-1,:) = matmul( AL(:,:), BL(:,:) )

  ! Calcul des blocs extra-diagonaux
!  ! Premier algorithme (deux fois plus coûteux que le second)
!  do k = 0, Nprocs-1
!    if (rang /= k) then
!      ! Envoie AL au processus iterp et reception du AL de k dans temp
!      call MPI_SENDRECV(AL,   NL*N, MPI_REAL, k, etiquette, &
!                        TEMP, NL*N, MPI_REAL, k, etiquette, MPI_COMM_WORLD, statut)
!      ! Chaque processus calcule les blocs situés au-dessus
!      ! et en dessous du bloc de la diagonale principale
!      CL(k*NL+1:(k+1)*NL,:)=matmul(TEMP(:,:),BL(:,:))
!    end if
!  end do
  ! Second algorithme
  rang_precedent = mod(Nprocs+rang-1,Nprocs)
  rang_suivant   = mod(rang+1,Nprocs)
  TEMP(:,:) = 0
  TEMP(:NL,:) = AL(:,:)
  do k = 1, Nprocs-1
    ! Envoie AL au rang_precedent et reception de rang_suivant
    call MPI_SENDRECV_REPLACE (TEMP, NLmax*N, MPI_REAL, &
                               rang_precedent, etiquette, &
                               rang_suivant, etiquette, &
                               MPI_COMM_WORLD, statut)
    ! Chaque processus calcule les blocs situés au-dessus
    ! et en dessous du bloc de la diagonale principale
    krang = mod(rang+k,Nprocs)
    CL(position(krang):position(krang+1)-1,:)=matmul(TEMP(:Ndist(krang),:),BL(:,:))
  end do

  ! Recuperation des CL pour former la matrice CC sur le processus 0
  call MPI_GATHERV(CL, NL*N, MPI_REAL, C, nbrS, decalageS, MPI_REAL, 0, MPI_COMM_WORLD)

  ! Les tableaux locaux sont désormais inutiles
  deallocate( AL, BL, CL, TEMP )
  ! Vérification des résultats
  if (rang == 0) then
    allocate( E(N,N) )
    E(:,:) = abs(C(:,:) - CC(:,:))
    Emax   = maxval( E(:,:) ) / N**2
    deallocate( A, B, C, CC, E )
    if ( Emax <= epsilon(1.0) ) then
      print'(/,40X,"Bravo !",/,  &
            & 20X,"Le produit matriciel A*B calcule en parallele",/, &
            & 20X,"est bien egal a celui calcule en monoprocesseur")'
    else
      print'(/,33X,"Resultat incorrect !",/, &
            & 20X,"Le produit matriciel A*B calcule en parallele",/, &
            & 20X,"est different de celui calcule en monoprocesseur")'
    end if
  end if

  ! Finaliser MPI
  call MPI_TYPE_FREE(type_tranche1)
  call MPI_TYPE_FREE(type_tranche2)
  call MPI_FINALIZE()
end program produit_matrices
