program produit_matrices
  use mpi
  implicit none
  integer, parameter                  :: etiquette=1000
  integer                             :: rang, Nprocs, N, NL, code, k, type_temp, type_tranche
  integer                             :: rang_suivant, rang_precedent, taille_type_reel
  integer, dimension(MPI_STATUS_SIZE) :: statut
  real                                :: Emax
  real, allocatable, dimension(:,:)   :: A, B, C, CC, E
  real, allocatable, dimension(:,:)   :: AL, BL, CL, TEMP
  integer(kind=MPI_ADDRESS_KIND)      :: borne_inferieure=0, taille_deplacement_type_tranche
  character(len=256)                  :: arg

  ! Recuperation du rang et nombre de processus -> rang nprocs
  call MPI_INIT(code)
  call MPI_COMM_RANK(MPI_COMM_WORLD, rang, code)
  call MPI_COMM_SIZE(MPI_COMM_WORLD, Nprocs, code)

  if (rang == 0) then
    if (command_argument_count() < 1) then
      N=4
    else
      call get_command_argument(1,arg)
      read(arg, '(i6)') N
    end if
  end if

  ! Diffusion de N a tous le monde
  call MPI_BCAST(N, 1, MPI_INTEGER, 0, MPI_COMM_WORLD, code)

  ! Il faut que N soit divisible par Nprocs
  if ( mod(N, Nprocs) == 0 ) then
    if (rang == 0) print *, "Longueur matrice: ", N
    NL = N / Nprocs
  else
    print *, 'N=',N, ' n''est pas divisible par Nprocs=', Nprocs
    ! Arret du programme
    call MPI_ABORT(MPI_COMM_WORLD, 1, code)
  end if

  ! Le processus 0 initialise les matrices A et B
  if (rang == 0) then
    ! Allocation dynamique de mémoire, entre autres, des matrices A, B et C
    allocate( A(N,N), B(N,N), C(N,N), CC(N,N) )
    ! Initialisation de A et B
    call RANDOM_NUMBER(A)
    call RANDOM_NUMBER(B)
    ! Calcul monoprocesseur du produit matriciel A*B
    CC(:,:) = matmul(A(:,:), B(:,:))
  else
    ! Eviter problem avec option -check all
    allocate(A(0,0),B(0,0),C(0,0))
  end if

  ! Allocation dynamique de mémoire des divers tableaux locaux
  allocate( AL(NL,N), BL(N,NL), CL(N,NL), TEMP(NL,N) )

  ! Construction du type qui correspond a 1 bloc de NL lignes et N colonnes
  call MPI_TYPE_SIZE(MPI_REAL, taille_type_reel, code)
  call MPI_TYPE_VECTOR(N, NL, N, MPI_REAL, type_temp, code)
  taille_deplacement_type_tranche = taille_type_reel*NL
  call MPI_TYPE_CREATE_RESIZED(type_temp, borne_inferieure, taille_deplacement_type_tranche, &
                               type_tranche, code)
  call MPI_TYPE_COMMIT(type_tranche, code)

  ! Diffusion de A aux AL
  call MPI_SCATTER(A, 1, type_tranche, AL, N*NL, MPI_REAL, 0, MPI_COMM_WORLD, code)

  ! Diffusion de B aux BL
  call MPI_SCATTER(B, N*NL, MPI_REAL, BL, N*NL, MPI_REAL, 0, MPI_COMM_WORLD, code)

  ! Calcul des blocs diagonaux de la matrice resultante.
  CL(rang*NL+1:(rang+1)*NL,:) = matmul( AL(:,:), BL(:,:) )

  ! Calcul des blocs extra-diagonaux
!  ! Premier algorithme (deux fois plus coûteux que le second)
!  do k = 0, Nprocs-1
!    if (rang /= k) then
!      ! Envoie AL au processus iterp et reception du AL de k dans temp
!      call MPI_SENDRECV(AL,   NL*N, MPI_REAL, k, etiquette, &
!                        TEMP, NL*N, MPI_REAL, k, etiquette, MPI_COMM_WORLD, statut, code)
!      ! Chaque processus calcule les blocs situés au-dessus
!      ! et en dessous du bloc de la diagonale principale
!      CL(k*NL+1:(k+1)*NL,:)=matmul(TEMP(:,:),BL(:,:))
!    end if
!  end do
  ! Second algorithme
  rang_precedent = mod(Nprocs+rang-1,Nprocs)
  rang_suivant   = mod(rang+1,Nprocs)
  do k = 1, Nprocs-1
    ! Envoie AL au rang_precedent et reception de rang_suivant
    call MPI_SENDRECV_REPLACE(AL, NL*N, MPI_REAL, rang_precedent, etiquette, &
                              rang_suivant, etiquette, MPI_COMM_WORLD, statut, code)
    ! Chaque processus calcule les blocs situés au-dessus
    ! et en dessous du bloc de la diagonale principale
    CL(mod(rang+k,Nprocs)*NL+1:(mod(rang+k,Nprocs)+1)*NL,:)=matmul(AL(:,:),BL(:,:))
  end do

  ! Recuperation des CL pour former la matrice CC sur le processus 0
  call MPI_GATHER(CL, NL*N, MPI_REAL, C, NL*N, MPI_REAL, 0, MPI_COMM_WORLD, code)

  ! Les tableaux locaux sont désormais inutiles
  deallocate( AL, BL, CL, TEMP )
  ! Vérification des résultats
  if (rang == 0) then
    allocate( E(N,N) )
    E(:,:) = abs(C(:,:) - CC(:,:))
    Emax   = maxval( E(:,:) ) / N**2
    deallocate( A, B, C, CC, E )
    if ( Emax <= epsilon(1.0) ) then
      print'(/,40X,"Bravo !",/,  &
            & 20X,"Le produit matriciel A*B calcule en parallele",/, &
            & 20X,"est bien egal a celui calcule en monoprocesseur")'
    else
      print'(/,33X,"Resultat incorrect !",/, &
            & 20X,"Le produit matriciel A*B calcule en parallele",/, &
            & 20X,"est different de celui calcule en monoprocesseur")'
    end if
  end if

  ! Finaliser MPI
  call MPI_TYPE_FREE(type_temp,code)
  call MPI_TYPE_FREE(type_tranche,code)
  call MPI_FINALIZE(code)
end program produit_matrices
