program commsplit
  use MPI_F08
  implicit none
  TYPE(MPI_Comm)                 :: CommCart2D,CommCart1D
  integer, parameter             :: NDimCart2D=2
  integer, dimension(NDimCart2D) :: DimCart2D,CoordCart2D
  logical, dimension(NDimCart2D) :: Periode
  logical                        :: Reordonne
  integer                        :: nb_procs,rang,i
  integer, parameter             :: m=4
  real, dimension(m)             :: V
  real                           :: W

  ! Recuperation du rang et du nombre de processus
  call MPI_INIT()
  call MPI_COMM_RANK(MPI_COMM_WORLD, rang)
  call MPI_COMM_SIZE(MPI_COMM_WORLD, nb_procs)

  ! Caractéristiques de la topologie cartésienne 2D
  DimCart2D(1) = 4
  DimCart2D(2) = 2
  if (DimCart2D(1)*DimCart2D(2) /= nb_procs) then
    print *, "Ce n'est pas le nombre de processeurs nécessaire !"
    ! TODO: On arrete le programme

  end if

  Periode(:)   = .false.
  ReOrdonne    = .false.

  ! TODO: Création de la topologie -> CommCart2D

  ! TODO: Recuperation des coordonnees dans la topologie -> coordCart2D

  ! Initialisation du vecteur V et du scalaire W
  V(:) = 0.
  W = 0.
  if (CoordCart2D(1) == 1) V(:) = (/ (real(i), i=1,m) /)

  ! TODO: Subdivision de la topologie avec MPI_COMM_SPLIT.

  ! TODO: Distribution de V vers W par le processus 1 dans la nouvelle topologie

  print '("Rang : ",I2," ; Coordonnees : (",I1,",",I1,") ; W = ",F2.0)', &
        rang,CoordCart2D(1),CoordCart2D(2),W

  ! Destruction des communicateurs
  call MPI_COMM_FREE(CommCart1D)
  call MPI_COMM_FREE(CommCart2D)
  call MPI_FINALIZE()
end program commsplit
