program commsplit
  use MPI
  implicit none
  integer                        :: CommCart2D,CommCart1D
  integer, parameter             :: NDimCart2D=2
  integer, dimension(NDimCart2D) :: DimCart2D,CoordCart2D
  logical, dimension(NDimCart2D) :: Periode
  logical                        :: Reordonne
  integer                        :: nb_procs,rang,i,code
  integer, parameter             :: m=4
  real, dimension(m)             :: V
  real                           :: W

  ! Recuperation du rang et du nombre de processus
  call MPI_INIT(code)
  call MPI_COMM_RANK(MPI_COMM_WORLD, rang, code)
  call MPI_COMM_SIZE(MPI_COMM_WORLD, nb_procs, code)

  !*** Caractéristiques de la topologie cartésienne 2D
  DimCart2D(1) = 4
  DimCart2D(2) = 2
  if (DimCart2D(1)*DimCart2D(2) /= nb_procs) then
    print *, "Ce n'est pas le nombre de processeurs nécessaire !"
    ! On arrete le programme
    call MPI_ABORT(MPI_COMM_WORLD,1,code)
  end if

  Periode(:)   = .false.
  ReOrdonne    = .false.

  ! Création de la topologie -> CommCart2D
  call MPI_CART_CREATE(MPI_COMM_WORLD, NDimCart2D, DimCart2D, &
                       Periode, ReOrdonne, CommCart2D, code)

  ! Recuperation des coordonnees dans la topologie -> coordCart2D
  call MPI_CART_COORDS(CommCart2D, rang, NDimCart2D, CoordCart2D, code)

  !*** Initialisation du vecteur V et du scalaire W
  V(:) = 0.
  W = 0.
  if (CoordCart2D(1) == 1) V(:) = (/ (real(i), i=1,m) /)

  ! Subdivision de la topologie avec MPI_COMM_SPLIT
  call MPI_COMM_SPLIT( CommCart2D, CoordCart2D(2), rang, CommCart1D, code)

  ! Diffusion de V vers W par le processus 1 dans la nouvelle topologie
  call MPI_SCATTER(V,1,MPI_REAL,W,1,MPI_REAL,1,CommCart1D,code)

  print '("Rang : ",I2," ; Coordonnees : (",I1,",",I1,") ; W = ",F2.0)', &
        rang,CoordCart2D(1),CoordCart2D(2),W

  !*** Destruction des communicateurs
  call MPI_COMM_FREE(CommCart1D,code)
  call MPI_COMM_FREE(CommCart2D,code)
  call MPI_FINALIZE(code)
end program commsplit
