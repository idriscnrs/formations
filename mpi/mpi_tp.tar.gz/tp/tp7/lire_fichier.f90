program lire_fichier
  use MPI_F08
  implicit none
  integer, parameter                  :: nb_valeurs=121
  integer(kind=MPI_OFFSET_KIND)       :: position_fichier
  integer, dimension(nb_valeurs)      :: valeurs
  TYPE(MPI_Status)                    :: statut
  integer                             :: rang,nb_octets_entier
  TYPE(MPI_File)                      :: descripteur

  call MPI_INIT()
  call MPI_COMM_RANK(MPI_COMM_WORLD,rang)
  call MPI_FILE_SET_ERRHANDLER(MPI_FILE_NULL,MPI_ERRORS_ARE_FATAL)

  ! TODO: Ouverture du fichier "donnees.dat" en lecture

  valeurs(:)=0
  ! TODO: Lecture via des déplacements explicites, en mode individuel

  open(unit=45,file="fichier_dei"//achar(48+rang)//".dat")
  write(unit=45,fmt='(I3)') valeurs(:)
  close(unit=45)
  call MPI_BARRIER(MPI_COMM_WORLD)
  if (rang == 0) then
    print *, 'Premiere lecture faite'
  end if

  valeurs(:)=0
  ! TODO: Lecture via les pointeurs partagés, en mode collectif


  open(unit=45,file="fichier_ppc"//achar(48+rang)//".dat")
  write(unit=45,fmt='(I3)') valeurs(:)
  close(unit=45)
  call MPI_BARRIER(MPI_COMM_WORLD)
  if (rang == 0) then
    print *, 'Deuxieme lecture faite'
  end if

  valeurs(:)=0
  ! TODO: Lecture via les pointeurs individuels, en mode individuel

  open(unit=45,file="fichier_pii"//achar(48+rang)//".dat")
  write(unit=45,fmt='(I3)') valeurs(:)
  close(unit=45)
  call MPI_BARRIER(MPI_COMM_WORLD)
  if (rang == 0) then
    print *, 'Troisieme lecture faite'
  end if

  valeurs(:)=0
  ! TODO: Lecture via les pointeurs partagés, en mode individuel

  open(unit=45,file="fichier_ppi"//achar(48+rang)//".dat")
  write(unit=45,fmt='(I3)') valeurs(:)
  close(unit=45)
  call MPI_BARRIER(MPI_COMM_WORLD)
  if (rang == 0) then
    print *, 'Quatrieme lecture faite'
  end if

  ! TODO: Fermeture du fichier


  call MPI_FINALIZE()
end program lire_fichier
