# Configuration

Pour exécuter les TPs il est nécessaire dans le répertoire `arch` de créer un
fichier `make_inc`.
Le plus simple est de faire un lien symbolique vers un des fichiers make_xxx
déjà définit.