#ifndef CALCUL_H
#define CALCUL_H

void initialisation(double **, double **, double **);
void calcul(double *, double *);
void sortie_resultats(double *, double *);

#endif
