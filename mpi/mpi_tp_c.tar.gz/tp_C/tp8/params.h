#ifndef PARAMS_H
#define PARAMS_H

extern int ntx, nty;
extern int sx, ex, sy, ey;

#define it_max 100000
#define faux 0
#define eps 2.e-16

#endif
