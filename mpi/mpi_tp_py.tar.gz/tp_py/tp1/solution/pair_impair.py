from mpi4py import MPI

# MPI_Init() est fait automatiquement lors de l'import

comm = MPI.COMM_WORLD
rang = comm.Get_rank()
nb_processus = comm.Get_size()

if rang % 2 == 0:
    print(f'Coucou, je suis le processus pair {rang}')
else:
    print(f'Coucou, je suis le processus impair {rang}')

# MPI_Finalize() est fait automatiquement à la fin du script
