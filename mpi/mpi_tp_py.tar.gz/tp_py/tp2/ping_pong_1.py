from mpi4py import MPI
import numpy as np

# Parametres globaux
nb_valeurs = 1000
etiquette = 99

# TODO: Initialisation MPI & recuperation du rang

# Initialisation a zero de valeurs
valeurs = np.zeros(nb_valeurs, dtype=np.float64)

# Graine pour le generateur aleatoire
np.random.seed(42)

    # Remplir avec des nombres aleatoires
    valeurs = np.random.rand(nb_valeurs)
    # TODO: Processus 0 envoie valeurs au processus 1


    # TODO: Processus 1 recoit valeurs du processus 0

    print(f"Moi, processus 1, j'ai recu {nb_valeurs} "
          f"valeurs (derniere = {valeurs[-1]:.2f}) du processus 0.")
