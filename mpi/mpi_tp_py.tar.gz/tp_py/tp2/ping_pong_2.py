from mpi4py import MPI
import numpy as np

# TODO: Recuperation du rang -> rang



nb_valeurs = 1000
etiquette = 99

# Creation du tableau valeurs
valeurs = np.zeros(nb_valeurs, dtype=np.float64)

# Graine du generateur aleatoire
np.random.seed(42)

    # Remplir valeur avec des valeurs aleatoires sur le processus 0
    valeurs = np.random.rand(nb_valeurs)
    # TODO: Debut de prise de temps du ping pong -> temps_debut

    # TODO : Processus 0: envoie et recoit du processus 1

    # TODO : Fin de prise de temps du ping pong -> temps_fin

    print(f"Moi, processus 0, j'ai envoye et recu {nb_valeurs} "
          f"valeurs (derniere = {valeurs[-1]:.2f}) du processus 1 en "
          f"{temps_fin - temps_debut:.6f} secondes.")

    # TODO: Processus 1: recoit et envoie au processus 0

