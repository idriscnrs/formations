import math

# Nombre d'intervalles
nbblock = 3 * 1000 * 1000 * 100
# Largeur des intervalles
largeur = 1.0 / nbblock

# Calcul de la somme globale
for i in range(1, nbblock+1):
    x = largeur * (i - 0.5)
    somme_globale += largeur * (4.0 / (1.0 + x * x))

print(f"Pi = {somme_globale}")
print(f"Difference = {somme_globale - 4.0 * math.atan(1.0)}")
