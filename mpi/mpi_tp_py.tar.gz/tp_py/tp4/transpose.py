from mpi4py import MPI
import numpy as np

nb_lignes = 4
nb_colonnes = 5
nb_lignes_t = nb_colonnes
nb_colonnes_t = nb_lignes
etiquette = 1000

# TODO: Recuperation du rang -> rang


# Matrices
A = np.zeros((nb_lignes, nb_colonnes))
AT = np.zeros((nb_lignes_t, nb_colonnes_t), dtype=np.float64)

# TODO: Type transpose

if rang == 0:
    # Initialisation de la matrice A sur le processus 0
    A = np.reshape(np.arange(1, nb_lignes * nb_colonnes + 1, dtype=np.float64),
                   (nb_lignes, nb_colonnes))
    print("Matrice A")
    print(A)
    # TODO: Processus 0: Envoie la matrice A au processus 1

else:
    # TODO: Processus 1: Recoit dans la matrice AT du processus 0

    print("Matrix transpose AT")
    print(AT)
