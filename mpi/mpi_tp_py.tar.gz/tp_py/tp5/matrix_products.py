import numpy as np
from mpi4py import MPI

etiquette = 1000

# TODO: Recuperation du rang et nombre de processus -> rang nprocs

n = nprocs
if rang == 0:
    # Lecture de taille de la matrice depuis un fichier
    with open("matrix_products.data", "r") as file:
        n = int(file.readline().strip())

# TODO: Diffusion de N a tous le monde

# N doit etre divisible par nprocs
if (n % nprocs) != 0:
    print(f"n {n} n'est pas divisible par nprocs {nprocs}")
    # TODO: Arret du programme

else:
    nl = n//nprocs

if rang == 0:
    A = np.random.rand(n, n)
    B = np.random.rand(n, n)
    C = np.zeros((n, n), dtype=np.float64)
    CC = np.zeros((n, n), dtype=np.float64)
    # Calcul sequentiel de A*B
    np.matmul(A, B, out=C)
else:
    # Besoin de definir pour eviter les erreurs "not defined error"
    # dans scatter & gather
    A = None
    B = None
    C = None
    CC = None

# Initialisation des tableau locaux
AL = np.empty((nl, n), dtype=np.float64)
BL = np.empty((n, nl), dtype=np.float64)
CL = np.empty((n, nl), dtype=np.float64)
TEMP = np.empty((nl, n), dtype=np.float64)

# TODO: Construction du type qui correspond a 1 bloc de n lignes et nl colonnes

# TODO: Diffusion de A aux AL

# TODO: Diffusion de B aux BL

# Calcul des blocs diagonaux
np.matmul(AL, BL, out=CL[rang*nl:(rang+1)*nl, :])
# Calcul des blocs extra diagonaux
# Premier algorithme
# for iterp in range(nprocs):
#    if (rang != iterp):
#        # TODO: Envoie AL au processus iterp et reception du AL de iterp dans temp
#    
#    # Calcul du bloc extra diagonal
#    np.matmul(TEMP, BL, out=CL[iterp*nl:(iterp+1)*nl,:])
# Second algorithme
rang_precedent = (nprocs+rang-1) % nprocs
rang_suivant = (rang+1) % nprocs
for iterp in range(1, nprocs):
    # TODO: Envoie AL au rang_precedent et reception de rang_suivant
  
    # Calcul du bloc extra diagonal
    displacement = (rang+iterp) % nprocs
    np.matmul(AL, BL, out=CL[displacement*nl:(displacement+1)*nl, :])
# TODO: Recuperation des CL pour former la matrice CC sur le processus 0

# Desalloue tableaux de travail
del AL, BL, CL, TEMP
# Verification des resultats
if rang == 0:
    Emax = 0.0
    Emax = np.max(np.abs(C-CC))
    print(f"Emax = {Emax}")
    if Emax < 1e-10:
        print("Bravo!")
        print("Le produit parallel A*B est egal au produit sequentiel")
    else:
        print("Resultat faux!")
        print("Le produit parallel A*B est different du produit sequentiel")
