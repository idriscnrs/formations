import numpy as np
from mpi4py import MPI

etiquette = 1000

# Recuperation du rang et nombre de processus -> rang nprocs
comm = MPI.COMM_WORLD
nprocs = comm.Get_size()
rang = comm.Get_rank()

if rang == 0:
    # Lecture de taille de la matrice depuis un fichier
    with open("matrix_products.data", "r") as file:
        N = int(file.readline().strip())

# Diffusion de N a tous le monde
if rang != 0:
    # Sinon erreur "N is not defined" dans le bcast
    N = None
N = comm.bcast(N, root=0)
# print(f"After bcast N={N} on {rang}")

# N doit etre divisible par nprocs
if (N % nprocs) != 0:
    print(f"N {N} n'est pas divisible par nprocs {nprocs}")
    # Arret du programme
    comm.Abort()
else:
    NL = N//nprocs

if rang == 0:
    A = np.random.rand(N, N)
    B = np.random.rand(N, N)
    C = np.zeros((N, N), dtype=np.float64)
    CC = np.zeros((N, N), dtype=np.float64)
    # Calcul sequentiel de A*B
    np.matmul(A, B, out=C)
else:
    # Besoin de definir pour eviter les erreurs "not defined error"
    # dans scatter & gather
    A = None
    B = None
    C = None
    CC = None

# Initialisation des tableau locaux
AL = np.empty((NL, N), dtype=np.float64)
BL = np.empty((N, NL), dtype=np.float64)
CL = np.empty((N, NL), dtype=np.float64)
TEMP = np.empty((NL, N), dtype=np.float64)

# Construction du type qui correspond a 1 bloc de N lignes et NL colonnes
type_temp = MPI.DOUBLE.Create_vector(N, NL, N)
extent = MPI.DOUBLE.Get_size() * NL
type_slice = type_temp.Create_resized(0, extent)
type_slice.Commit()

# Distribution de A aux AL
comm.Scatter(sendbuf=[A, N*NL, MPI.DOUBLE], recvbuf=[AL, N*NL, MPI.DOUBLE],
             root=0)
# Distribution de B aux BL
comm.Scatter([B, 1, type_slice], [BL, N*NL, MPI.DOUBLE], root=0)
# Calcul des blocs diagonaux
np.matmul(AL, BL, out=CL[rang*NL:(rang+1)*NL, :])
# Calcul des blocs extra diagonaux
# Premier algorithme
# for iterp in range(nprocs):
#    if (rang != iterp):
#        #print(f"rang {rang} iterp {iterp}")
#        # Envoie AL au processus iterp et reception du AL de iterp dans temp
#        comm.Sendrecv(sendbuf=[AL,N*NL,MPI.DOUBLE],
#                      dest=iterp, sendtag=etiquette,
#                      recvbuf=[TEMP,N*NL,MPI.DOUBLE],
#                      source=iterp, recvtag=etiquette)
#    # Calcul du bloc extra diagonal
#    np.matmul(TEMP, BL, out=CL[iterp*NL:(iterp+1)*NL,:])
# Second algorithme
rang_precedent = (nprocs+rang-1) % nprocs
rang_suivant = (rang+1) % nprocs
for iterp in range(1, nprocs):
    # Envoie AL au rang_precedent et reception de rang_suivant
    comm.Sendrecv_replace(buf=[AL, N*NL, MPI.DOUBLE],
                          dest=rang_precedent, sendtag=etiquette,
                          source=rang_suivant, recvtag=etiquette)
    # Calcul du bloc extra diagonal
    displacement = (rang+iterp) % nprocs
    np.matmul(AL, BL, out=CL[displacement*NL:(displacement+1)*NL, :])
# Recuperation des CL pour former la matrice CC sur le processus 0
comm.Gather([CL, N*NL, MPI.DOUBLE], [CC, 1, type_slice], root=0)
# Desalloue tableaux de travail
del AL, BL, CL, TEMP
# Verification des resultats
if rang == 0:
    Emax = 0.0
    Emax = np.max(np.abs(C-CC))
    print(f"Emax = {Emax}")
    if Emax < 1e-10:
        print("Bravo!")
        print("Le produit parallel A*B est egal au produit sequentiel")
    else:
        print("Resultat faux!")
        print("Le produit parallel A*B est different du produit sequentiel")
