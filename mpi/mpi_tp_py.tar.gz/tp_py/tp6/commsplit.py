from mpi4py import MPI
import numpy as np

# Recuperation du rang et du nombre de processus
comm = MPI.COMM_WORLD
nbprocs = comm.Get_size()
rang = comm.Get_rank()

dimCart2D = [4, 2]

if dimCart2D[0]*dimCart2D[1] != nbprocs:
    print("Le nombre de processus n'est pas correct!")
    # TODO: On arrete le programme
  
# TODO: Creation de la topologie -> commCart2D

# TODO: Recuperation des coordonnees dans la topologie -> coordCart2D


# Initialisation de v et w
if (coordCart2D[0] == 1):
    v = np.array([1, 2, 3, 4], dtype=np.float64)
else:
    v = None
w = np.zeros(1, dtype=np.float64)

# TODO: Subdivision de la topologie avec split

# TODO: Diffusion de v vers w par le processus 1 dans la nouvelle topologie


print(f"Rang : {rang} ; Coordonnees ({coordCart2D[0]}, {coordCart2D[1]}) "
      f"; w = {w}")
