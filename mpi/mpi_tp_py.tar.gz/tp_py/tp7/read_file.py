from mpi4py import MPI
import numpy as np

nb_valeurs = 121
valeurs = np.zeros(nb_valeurs, dtype=np.int32)

comm = MPI.COMM_WORLD
rang = comm.Get_rank()

# TODO: Ouverture du fichier data.dat en lecture

# TODO: Lecture avec des deplacements explicit en mode individuel

filename = f"file_dei{rang}.dat"
np.savetxt(filename, valeurs, fmt='%3d')
if rang == 0:
    print(f"Premiere lecture faite")

valeurs = np.zeros(nb_valeurs, dtype=np.int32)
# TODO: Lecture avec les pointeurs partages en mode collectif

filename = f"file_ppc{rang}.dat"
np.savetxt(filename, valeurs, fmt='%3d')
if rang == 0:
    print(f"Seconde lecture faite")

valeurs = np.zeros(nb_valeurs, dtype=np.int32)
# TODO: Lecture avec les pointeurs individuels en mode individuel

filename = f"file_pii{rang}.dat"
np.savetxt(filename, valeurs, fmt='%3d')
if rang == 0:
    print(f"Troisieme lecture faite")

valeurs = np.zeros(nb_valeurs, dtype=np.int32)
# TODO: Lecture avec les pointeurs partages en mode individuel

filename = f"file_ppi{rang}.dat"
np.savetxt(filename, valeurs, fmt='%3d')
if rang == 0:
    print(f"Quatrieme lecture faite")

# TODO: Fermeture du fichier

