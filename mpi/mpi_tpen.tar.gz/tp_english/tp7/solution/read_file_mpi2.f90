!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! -*- Mode: F90 -*- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!! read_file.f90 --- TP7  MPI (execute on 4 processes)
!! 
!! Author          : Denis GIROU (CNRS/IDRIS - France) <Denis.Girou@idris.fr>
!! 
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

program read_file

  use mpi

  implicit none

  integer, parameter                  :: nb_values=121
  integer(kind=MPI_OFFSET_KIND)       :: offset
  integer, dimension(nb_values)       :: values
  integer, dimension(MPI_STATUS_SIZE) :: status
  integer                             :: rank,nb_bytes_integer,fh,code

  call MPI_INIT(code)
  call MPI_COMM_RANK(MPI_COMM_WORLD,rank,code)
  call MPI_FILE_SET_ERRHANDLER(MPI_FILE_NULL,MPI_ERRORS_ARE_FATAL,code)

  ! Open the file "data.dat" in read mode
  call MPI_FILE_OPEN(MPI_COMM_WORLD,"data.dat",MPI_MODE_RDONLY, &
                     MPI_INFO_NULL,fh,code)

  ! Read the nb_values of the values array on each processes
  values(:)=0  

  ! Read via explicit offsets, in individual mode
  call MPI_TYPE_SIZE(MPI_INTEGER,nb_bytes_integer,code)
  offset=rank*nb_values*nb_bytes_integer
  call MPI_FILE_READ_AT(fh,offset,values,nb_values, &
                        MPI_INTEGER,status,code)
  open(unit=45,file="file_dei"//achar(48+rank)//".dat")
  write(unit=45,fmt='(I3)') values(:)
  close(unit=45)

  ! Read via shared file pointers, in collective mode
  values(:)=0
  call MPI_FILE_READ_ORDERED(fh,values,nb_values, &
                             MPI_INTEGER,status,code)
  open(unit=45,file="file_ppc"//achar(48+rank)//".dat")
  write(unit=45,fmt='(I3)') values(:)
  close(unit=45)

  ! Read via individual file pointer, in individual mode
  values(:)=0
  offset = rank*nb_values*nb_bytes_integer
  call MPI_FILE_SEEK(fh,offset,MPI_SEEK_SET,code)
  call MPI_FILE_READ(fh,values,nb_values, &
                     MPI_INTEGER,status,code)
  open(unit=45,file="file_pii"//achar(48+rank)//".dat")
  write(unit=45,fmt='(I3)') values(:)
  close(unit=45)

  ! Read via shared file pointers, in individual mode
  ! (the shared file pointer needs to be set at the beginning of the file)
  values(:)=0
  offset=0
  call MPI_FILE_SEEK_SHARED(fh,offset,MPI_SEEK_SET,code)
  call MPI_FILE_READ_SHARED(fh,values,nb_values, &
                            MPI_INTEGER,status,code)
  open(unit=45,file="file_ppi"//achar(48+rank)//".dat")
  write(unit=45,fmt='(I3)') values(:)
  close(unit=45)

  ! Close the file
  call MPI_FILE_CLOSE(fh,code)

  call MPI_FINALIZE(code)

end program read_file
