#/usr/bin/env bash

kernel_dir=${HOME}/.local/share/jupyter/kernels/openacc
conf_dir=${WORK}/config
idrcomp_dir=/gpfslocalsup/pub/idrcomp/utils
ipython_dir=${HOME}/.ipython/profile_default


# Setup jupyterhub
mkdir -p $kernel_dir/
cat > ${kernel_dir}/kernel.sh <<EOF
#!/bin/bash

module purge # disable the external environment

# Activate your Python virtual environment
module load anaconda-py3/2023.03
conda activate gpu_directives

# Ensure python packages installed in conda are always preferred
export PYTHONPATH=${CONDA_PREFIX}/lib/python3.11/site-packages:\${PYTHONPATH}
export PYTHONPATH=${idrcomp_dir}/:\${PYTHONPATH}
export IDR_CONFIG_FILE=${conf_dir}/jean-zay.json

exec python -m ipykernel \$@
EOF

cat > ${kernel_dir}/kernel.json <<EOF
{
"argv": [
 "${kernel_dir}/kernel.sh",
 "-f",
 "{connection_file}"
],
"display_name": "GPU Directives",
"language": "python",
"metadata": {
"debugger": true
 }
}
EOF

# Setup ipython
mkdir -p ${ipython_dir}
cat > ${ipython_dir}/ipython_config.py <<EOF
c.InteractiveShellApp.extensions = ["idrcomp"]
EOF

