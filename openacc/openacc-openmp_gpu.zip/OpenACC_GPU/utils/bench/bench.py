import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
def results(filepath, name=None):
    with open(filepath, 'r') as f:
        threads = []
        times = []
        for line in f:
            if line.startswith(" OMP execution on"):
                threads.append(int(line.split()[3]))
            elif line.startswith("   Temps elapsed"):
                times.append(float(line.split()[3]))
    return pd.Series(np.array(times), index=np.array(threads), name=name)

def plot(df, eff=True, perfect=True):
    first = df.iloc[0]
    efficiency = first/df
    perfect = first/(df.index.to_numpy())
    perfect_efficiency = pd.Series(df.index, index=df.index)
    fig, axes = plt.subplots(nrows=1, ncols=2, figsize=(15,7))
    df.plot(x="threads", ax=axes[0], label=df.name, legend=True)
    efficiency.plot(x="threads", ax=axes[1], label=df.name, legend=True)
    perfect_efficiency.plot(x="threads", ax=axes[1])
    for ax in axes:
        ax.set_xticks(df.index)
        ax.grid(True)

def compare(dfs, eff=True, perfect=True):
    fig, axes = plt.subplots(nrows=1, ncols=2, figsize=(15,7))
    for df in dfs:
        df.plot(ax=axes[0], label=df.name, legend=True)
    if eff:
        efficiencies = [x.iloc[0]/x for x in dfs]
        for plot in efficiencies:
            plot.plot(label=plot.name, legend=True, ax=axes[1])
    if perfect:
        perfect_efficiency = dfs[0].index
        plt.plot(perfect_efficiency, perfect_efficiency)
    for ax in axes:
        ax.set_xticks(perfect_efficiency)
        ax.grid(True)