#include <unistd.h>
double** load_data(char* filename, int size, int transpose)
{
    double** a;
    if (access(filename, F_OK) != -1)
    {
        FILE* f = fopen(filename, "rb");
        a = (double**) malloc(size * sizeof(double*));
        double temp;
        if (f)
        {
            for (int i=0; i<size; ++i)
            {
                a[i] = (double*) malloc(size * sizeof(double));
                fread(a[i], sizeof(double), size, f);
            }
        }
        if (transpose)
        {
            for (int i=0; i<size; ++i)
                for (int j=i; j<size; ++j)
                {
                    temp = a[i][j];
                    a[i][j] = a[j][i];
                    a[j][i] = temp;
                }
        }
    }else 
    {
        a = NULL;
    }
    return a;
}
