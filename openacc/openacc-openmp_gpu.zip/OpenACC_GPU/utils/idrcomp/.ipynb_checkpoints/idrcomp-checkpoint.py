import sys
import os
import json
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from matplotlib import rcParams
from PIL import Image
from subprocess import run, PIPE, CalledProcessError, Popen
from tempfile import NamedTemporaryFile as tmpf
from IPython.core import magic_arguments
from IPython.core.magic import cell_magic, line_magic, Magics, magics_class

def convert_pic(filepath, row, col, mode):
    """ Convert raw picture to image"""
    with open(filepath, 'rb') as pic:
        img = Image.frombytes(mode, (row, col), pic.read(), 'raw')
    return img

def show_gray(filepath, row, col):
    """ Display the gray picture in the notebook"""
    img = convert_pic(filepath, row, col, "L") 
    display(img)
    
def show_rgb(filepath, row, col):
    """ Display the RGB: picture in the notebook"""
    img = convert_pic(filepath, row, col, "RGB")
    display(img)

def compare_rgb(filepath1, filepath2, row, col):
    """ Compare 2 pictures in RGB format """
    img1 = convert_pic(filepath1, row, col, "RGB")
    img2 = convert_pic(filepath2, row, col, "RGB")
    rcParams['figure.figsize'] = 11 ,11
    fig, ax = plt.subplots(1,2) 
    fig.tight_layout(pad=3.0)
    ax[0].set_axis_off()
    ax[1].set_axis_off()
    ax[0].imshow(img1)
    ax[1].imshow(img2)

def print_out_err(proc):
    """ Print output and error of a process"""
    stdout = proc.stdout
    stderr = proc.stderr
    if stderr:
        sys.stderr.write(stderr)
        sys.stderr.flush()
    if stdout:
        sys.stdout.write(stdout)
        sys.stdout.flush()

def idrsetenv(modules):
    """ Create a copy of an environment after loading some modules """
    # Purge env
    command = ["modulecmd", "bash", "purge"]
    try:
        proc = run(command, capture_output=True, shell=False, check=False, encoding='utf8')
    except Exception as e:
        print_out_err(proc)
        raise(e)
    # Load the modules
    command = ["modulecmd", "bash", "load"]
    command.extend(modules)
    sys.stderr.write("module load {:s}\n".format(" ".join(modules)))

    try:
        proc = run(command, capture_output=True, shell=False, check=False, encoding='utf8')
    except Exception as e:
        print_out_err(proc)
        raise(e)
    # Create a copy of the environment
    # It is used because we would need to reload the modules in each cell
    env = os.environ.copy()
    for line in proc.stdout.split('\n'):
        try:
            var, val = line.split(';')[0].split('=')
            env[var] = val
        except ValueError as e:
            pass
    return env

@magics_class
class IdrisMagics(Magics):
    @cell_magic
    @magic_arguments.magic_arguments()
    @magic_arguments.argument('--compiler', '-c', help='Choose compiler',
                              type=str.lower,
                              choices=['nvhpc', 'gcc', 'pgi', 'intel'], default='nvhpc')
    @magic_arguments.argument('--mpi', '-m',
                              help='Use MPI wrapper and set the number of tasks',
                              type=int,
                              default=0)
    @magic_arguments.argument('--gpus', '-g',
                              help='Set the number of GPUs to use',
                              type=int)
    @magic_arguments.argument('--openmp', '-t', help="Activate OpenMP",
                              action="store_true")
    @magic_arguments.argument('--language', '-l', help="Define language",
                              type=str.lower,
                              choices=['c', 'c++','fortran'])
    @magic_arguments.argument('--options',
                              help="Add compiler options. Use quotes to enclose the options",
                              type=str,
                              default=None)
    @magic_arguments.argument('--acc', '-a',
                              help='Activate OpenACC support',
                              action='store_true')
    @magic_arguments.argument('--accopts',
                              type=str,
                              default=None,
                              help="Comma separated options to pass to --ta for PGI, and to --foffload for GCC. Use quotes to enclose the options")
    @magic_arguments.argument('--cliopts',
                              type=str,
                              default=None,
                              help="Options to pass to the command line for the execution. Use quotes to enclose the options")
    @magic_arguments.argument('--time', action='store_true', help='Add time information') 
    @magic_arguments.argument('--profile', action='store_true', help='Use nsys to generate a profile')
    @magic_arguments.argument('--noexec', '-n', action='store_true', help='Do not execute the code. Requires --keep')
    @magic_arguments.argument('--object', action='store_true', help="Only generate object file. Requires --keep")
    @magic_arguments.argument('--keep', '-k',
                              help='Save source after cell execution. Give the name of the file',
                              type=str,
                              default=None)
    def idrrun(self, line='', cell=None):
        config_file = os.environ["IDR_CONFIG_FILE"]
        self.kind = "cell"
        self.idrconfig = json.load(open(config_file, 'r'))
        self.args = magic_arguments.parse_argstring(self.idrrun, line)
        if self.args.noexec and not self.args.keep:
            #TODO Use a correct Error 
            raise BaseException("--noexec requires --keep!!")
        self.initialize()
        self.run_compiler(cell)
        if not self.args.noexec:
            self.run_exec()
            
    @line_magic
    @magic_arguments.magic_arguments()
    @magic_arguments.argument("file", help="Name of the source file")
    @magic_arguments.argument('--compiler', '-c', help='Choose compiler',
                              type=str.lower,
                              choices=['nvhpc', 'gcc', 'pgi', 'intel'], default='nvhpc')
    @magic_arguments.argument('--mpi', '-m',
                              help='Use MPI wrapper and set the number of tasks',
                              type=int,
                              default=0)
    @magic_arguments.argument('--gpus', '-g',
                              help='Set the number of GPUs to use',
                              type=int)
    @magic_arguments.argument('--openmp', '-t', help="Activate OpenMP",
                              action="store_true")
    @magic_arguments.argument('--language', '-l', help="Define language",
                              type=str.lower,
                              choices=['c', 'c++','fortran'])
    @magic_arguments.argument('--options',
                              help="Add compiler options. Use quotes to enclose the options",
                              type=str,
                              default=None)
    @magic_arguments.argument('--acc', '-a',
                              help='Activate OpenACC support',
                              action='store_true')
    @magic_arguments.argument('--accopts',
                              type=str,
                              default=None,
                              help="Comma separated options to pass to --ta for PGI, and to --foffload for GCC. Use quotes to enclose the options")
    @magic_arguments.argument('--cliopts',
                              type=str,
                              default=None,
                              help="Options to pass to the command line for the execution. Use quotes to enclose the options")
    @magic_arguments.argument('--time', action='store_true', help='Add time information')
    @magic_arguments.argument('--profile', action='store_true', help='Use nsys to generate a profile')
    @magic_arguments.argument('--noexec', '-n', action='store_true', help='Do not execute the code. Requires --keep')
    @magic_arguments.argument('--object', action='store_true', help="Only generate object file. Requires --keep")
    def idrrunfile(self, line='', cell=None):
        config_file = os.environ["IDR_CONFIG_FILE"]
        self.idrconfig = json.load(open(config_file, 'r'))
        self.args = magic_arguments.parse_argstring(self.idrrunfile, line)
        self.kind = "line"
        self.initialize()
        self.run_compiler(cell)
        self.file = self.args.file
        if not self.args.noexec:
            self.run_exec()
            
    def initialize(self):
        """ Setup the run """
        self.default_settings = self.idrconfig["default_settings"]
        self.compiler_opts = []
        self.language = self.args.language if self.args.language else self.default_settings["language"]
        # Check if we are using MPI
        if self.args.mpi > 0:
            self.language = "mpi_"+ self.language
        self.family = self.args.compiler
        # Check if gpus are used
        if not self.args.gpus:
            self.ngpus = int(self.default_settings["gpus"])
        else:
            self.ngpus = self.args.gpus
        # Header to include in source file before compiling
        self.source_header = ""
        if self.language == 'c':
            if "c_headers" in self.default_settings.keys():
                for header in self.default_settings["c_headers"]:
                    self.source_header += "#include <{:s}>\n".format(header)
        # Define the options
        opts = self.idrconfig[self.args.compiler]
        # profiler options
        try:
            self.profiling_cmd = self.idrconfig["profiling"]["command"].split()
            self.profiling_opts = self.idrconfig["profiling"]["default_options"]
        except KeyError:
            pass

        # Check if we are passing command line arguments
        self.cli = None
        if self.args.cliopts:
            self.cli = self.args.cliopts[1:-1].split()
        self.compiler = opts[self.language]["compiler"]
        self.extension = opts[self.language]["extension"]
        # Check if we need to load modules
        try:
            self.modules = opts["modules"]
            self.env = idrsetenv(self.modules)
        except KeyError:
            pass
        if self.args.options:
            # the options have to be passed with quotes
            # [1:-1] will remove the quotes
            # TODO add check for quotes
            self.compiler_opts.extend(self.args.options[1:-1].split())
        # Check if we are using OpenACC
        if self.args.acc:
            try:
                with open(opts[self.language]["openacc_header"], 'r') as f:
                    self.source_header += f.read()
            except Exception as e:
                # The language doesn't provide header for openacc
                pass
            self.compiler_opts.append(opts["openacc"]["activate"])
            self.compiler_opts.extend(opts["openacc"]["opts"])
            accopts = []
            if self.args.accopts:
                if self.family == "gcc":
                    for opt in self.args.accopts[1:-1].split(','):
                        accopts.append(opts["openacc"]["accopts_switch"] + opt)
                elif self.family == "pgi":
                    accopts.append(opts["openacc"]["accopts_switch"] + self.args.accopts[1:-1])
                elif self.family == "nvhpc":
                    accopts.append(opts["openacc"]["accopts_switch"] + self.args.accopts[1:-1])
            else:
                accopts.extend([opts["openacc"]["accopts_switch"]+opts["openacc"]["accopts_default"]])
            self.compiler_opts.extend(accopts)
        # Check if we are using OpenMP
        if self.args.openmp:
            self.compiler_opts.append(opts["openmp"]["activate"])

                            
    def run_compiler(self, cell):
        """ Run compiler command, print stdout and stderr"""
        command = []

        command.extend([self.compiler])
        command.extend(self.compiler_opts)
        # Check if we want to keep the source file
        if self.kind == "cell":
            keep = self.args.keep
            if keep:
                source_file = open(keep, 'w+b')
                self.source = keep
            else:
                # If not create a temporary file
                source_file = tmpf('w+b', 
                                   suffix=self.extension, 
                                   dir=os.getcwd(), 
                                   delete=True)
                self.source = str(source_file.name)
            # Write the content of the cell to the source file
            source_file.write(bytes(self.source_header, "utf-8"))
            source_file.write(bytes(cell, "utf-8"))
            source_file.flush()
        elif self.kind == "line":
            self.source = self.args.file

        # Define the name of the executable or object
        self.exec = os.path.join('.', "{:s}.{:s}".format(self.source, "o" if self.args.object else "exe"))
        
        # Finish building of command to run
        if self.args.object:
            command.append('-c')
        command.extend(['-o', os.path.basename(self.exec), os.path.basename(self.source)])
        sys.stdout.write(" ".join(command)+"\n")
        # Now run the command
        try:
            proc = run(command, capture_output=True, shell=False, check=True, env=self.env, encoding='utf8')
            print_out_err(proc)
            if self.kind == "cell":
                source_file.close()
        except CalledProcessError as e:
            sys.stderr.write(" ".join(e.cmd))
            sys.stderr.write(e.stderr)
            sys.stderr.write(e.stdout)
            return  

    def run_exec(self):
        """ Run executable"""
        command = []
        # Get launcher information
        if self.idrconfig["launcher"]["command"]:
            command.append(self.idrconfig["launcher"]["command"])
            command.append(self.idrconfig["launcher"]["tasks"]+str(self.args.mpi if self.args.mpi > 0 else 1))
            if self.ngpus > 0:
                command.append(self.idrconfig["launcher"]["gpus"]+str(self.ngpus))
            command.extend(self.idrconfig["launcher"]["options"])
        # Check if timing is enabled
        if self.args.time:
            command.append('time')
        # use profiler
        if self.args.profile:
            proc = run(["which", "nsys"], capture_output=True, shell=False, check=True, env=self.env, encoding='utf8')
            print_out_err(proc)
            command.extend(self.profiling_cmd)
            if self.profiling_opts:
                command.extend(self.profiling_opts)
        # Add the executable to run
        command.append(os.path.basename(self.exec))
        # Add the command line options
        if self.cli:
            command.extend(self.cli)
        # Now run the command
        if os.path.isfile(self.exec):
            sys.stdout.write(" ".join(command)+"\n")
            try:
                proc = run(command, capture_output=True, shell=False, check=True, env=self.env, encoding='utf8')
                print_out_err(proc)
            except CalledProcessError as e:
                sys.stderr.write(" ".join(e.cmd))
                sys.stderr.write(e.stderr)
                sys.stderr.write(e.stdout)
                return
        else:
            print("No executable was produce")
        # Delete executable
        if self.kind == 'cell':
            if not self.args.keep:
                if os.path.exists(self.exec):
                    os.remove(self.exec)

