# idrcomp

Compile and run C/Fortran code written in jupyter cells.
