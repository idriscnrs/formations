#!/usr/bin/env python
import os
import subprocess
import socket
import sys
import re
import json
from datetime import date

# Get some directories
cwd = os.getcwd()
script_path = os.path.dirname(os.path.realpath(__file__))
home = os.path.expanduser('~')

# Change the configuration file (jean-zay, ruche and azzurra available)
config = "jean-zay"
config_file = os.path.join(script_path, "config", config + ".json")
# Define the configuration file
os.environ["IDR_CONFIG_FILE"] = config_file

# If we are running locally on Jean Zay we need to set the TMPDIR variable to something else
# for the visual profiler to work correctly
try:
    with open(config_file, 'r') as f:
        js = json.load(f)
    is_remote = js["remote"]["enable"]
except KeyError:
    is_remote = False

if config == "jean-zay" and not is_remote:
    scratch_fold = os.path.join(os.environ["SCRATCH"], date.today().strftime("%d_%m_%Y"))
    if not os.path.isdir(scratch_fold):
        os.mkdir(scratch_fold)
    os.environ["TMPDIR"] = scratch_fold
    os.environ["TMP"] = scratch_fold

# Get the hostname
hostname = socket.gethostname()

# Define which command is used to run jupyterlab
lab_command = "jupyter-lab"
if hostname.startswith("jean-zay"):
    lab_command = "idrlab"

# ipython configuration file
ipython_dir = os.path.join(home, ".ipython", "profile_default")
ipython_conf = os.path.join(ipython_dir, "ipython_config.py")
# If ipython_conf does not exist the user needs to run ipython a first time to create the default profile
if not os.path.isdir(ipython_dir):
    sys.stderr.write("Please run jupyter or ipython a first time before running this script")
    sys.exit(1)
if not os.path.isfile(ipython_conf):
    with open(ipython_conf, 'w'):
        pass
# Add idrcomp to the automatically loaded extensions
with open(ipython_conf, 'r+') as f:
    if f.read().find("idrcomp") == -1 :
        f.write("c.InteractiveShellApp.extensions = [\"idrcomp\"]\n")
    else:
        print("idrcomp is already in the configuration file")

# Modify PYTHONPATH to find idrcomp
try:
    os.environ["PYTHONPATH"] += os.pathsep + os.path.join(script_path, "..", "utils")
except KeyError:
    os.environ["PYTHONPATH"] = os.path.join(script_path, "..", "utils")

# Now run jupyterlab
subprocess.run([lab_command, f"--notebook-dir={cwd}"])



