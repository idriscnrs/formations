__all__ = ["convert_pic", "show_gray", "show_rgb", "compare_rgb", "IdrisMagics"]
from .idrcomp import *

def load_ipython_extension(ipython):
    ipython.register_magics(IdrisMagics)

