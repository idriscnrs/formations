#!/bin/bash
#SBATCH --job-name=omp_tp9
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=20
#SBATCH --cores-per-socket=20
#SBATCH --hint=nomultithread
#SBATCH --time=00:05:00
#SBATCH --output=%x.res
#SBATCH --error=%x.res

source ../../arch/env_intel.sh

# Utilisation d'un binding compact par defaut
export KMP_AFFINITY=compact,granularity=fine,1,0

# Echo des commandes passees
set -x

# On se met dans le repertoire de soumission
cd $SLURM_SUBMIT_DIR

# Execution
./run.sh
