# Indiquez dans ce fichier l'environnement Intel à charger, par exemple :
# module load intel/2017.2
