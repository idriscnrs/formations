#include <petscdmda.h>
#include <petscksp.h>
#include <petsctime.h>

int main(int argc, char **argv)
{
  PetscErrorCode ierr;
  const PetscInt nx = 10, ny = 10, stencil_size = 5;
  PetscInt i, j, its;
  Mat A;
  Vec x, b;
  KSP solver;
  const PetscReal rtol = 1.e-8;
  KSPConvergedReason reason;
  PetscReal errorNorm, rnorm;
  PetscLogDouble t1, t2;
  DM dm;
  DMDALocalInfo info;
  const PetscInt stencilWidth = 1;
  MatStencil row, col5[stencil_size];
  PetscScalar hx2, hy2, coef, coef5[stencil_size];

  ierr = PetscInitialize(&argc, &argv, NULL, NULL);
  if (ierr) {
    printf("Error: Could not initialize PETSc, aborting...\n");
    return ierr;
  }

  // Create the 2-D DMDA object
  TBC

  // View the DMDA object
  TBC

  // Create the A matrix from the DMDA object
  TBC

  // Retrieve local information from the DMDA object
  TBC

  hx2 = 1.0 / ((info.mx - 1) * (info.mx - 1));
  hy2 = 1.0 / ((info.my - 1) * (info.my - 1));

  coef = 1.0;
  coef5[0] = 2.0 / hx2 + 2.0 / hy2;
  coef5[1] = -1.0 / hx2; coef5[2] = -1.0 / hx2;
  coef5[3] = -1.0 / hy2; coef5[4] = -1.0 / hy2;

  // Loop on the grid points
  for ( TBC ) {
    for ( TBC ) {
      if ( TBC ) {
        // Set matrix values to enforce boundary conditions (homogeneous Dirichlet conditions)
        TBC
      } else {
        // Set matrix values fo interior points
        TBC
      }
    }
  }
  ierr = MatAssemblyBegin(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);
  ierr = MatAssemblyEnd(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);
  // ierr = MatView(A, PETSC_VIEWER_STDOUT_WORLD); CHKERRQ(ierr);

  // Create global vectors b and x from the DMDA object
  TBC

  ierr = VecSet(b, 0.0); CHKERRQ(ierr);
  ierr = VecSetRandom(x, NULL); CHKERRQ(ierr);

  ierr = KSPCreate(PETSC_COMM_WORLD, &solver); CHKERRQ(ierr);
  ierr = KSPSetOperators(solver, A, A); CHKERRQ(ierr);
  ierr = KSPSetTolerances(solver, rtol, PETSC_DEFAULT, PETSC_DEFAULT, PETSC_DEFAULT); CHKERRQ(ierr);
  ierr = KSPSetInitialGuessNonzero(solver, PETSC_TRUE); CHKERRQ(ierr);
  ierr = KSPSetFromOptions(solver); CHKERRQ(ierr);
  ierr = KSPSetUp(solver); CHKERRQ(ierr);

  ierr = KSPView(solver, PETSC_VIEWER_STDOUT_WORLD); CHKERRQ(ierr);

  ierr = PetscTime(&t1); CHKERRQ(ierr);
  ierr = KSPSolve(solver, b, x); CHKERRQ(ierr);
  ierr = PetscTime(&t2); CHKERRQ(ierr);

  ierr = PetscPrintf(PETSC_COMM_WORLD, "Elapse time: %lf s\n", t2 - t1); CHKERRQ(ierr);

  ierr = KSPGetConvergedReason(solver, &reason); CHKERRQ(ierr);
  ierr = PetscPrintf(PETSC_COMM_WORLD, "Converged reason: %s\n", KSPConvergedReasons[reason]); CHKERRQ(ierr);

  ierr = KSPGetIterationNumber(solver, &its); CHKERRQ(ierr);
  ierr = PetscPrintf(PETSC_COMM_WORLD, "Iterations number: %d\n", its); CHKERRQ(ierr);

  ierr = KSPGetResidualNorm(solver, &rnorm); CHKERRQ(ierr);
  ierr = PetscPrintf(PETSC_COMM_WORLD, "Residual norm: %g\n", rnorm); CHKERRQ(ierr);

  ierr = VecNorm(x, NORM_2, &errorNorm); CHKERRQ(ierr);
  ierr = PetscPrintf(PETSC_COMM_WORLD, "Error norm (NORM_2): %g\n", errorNorm); CHKERRQ(ierr);
  ierr = VecNorm(x, NORM_INFINITY, &errorNorm); CHKERRQ(ierr);
  ierr = PetscPrintf(PETSC_COMM_WORLD, "Error norm (NORM_INFINITY): %g\n", errorNorm); CHKERRQ(ierr);

  ierr = KSPDestroy(&solver); CHKERRQ(ierr);
  ierr = MatDestroy(&A); CHKERRQ(ierr);
  ierr = VecDestroy(&x); CHKERRQ(ierr);
  ierr = VecDestroy(&b); CHKERRQ(ierr);
  ierr = DMDestroy(&dm); CHKERRQ(ierr);

  PetscFinalize();

  return 0;
}
