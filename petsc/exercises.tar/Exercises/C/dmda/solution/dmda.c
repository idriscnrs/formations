#include <petscdmda.h>
#include <petscksp.h>
#include <petsctime.h>

int main(int argc, char **argv)
{
  PetscErrorCode ierr;
  const PetscInt nx = 10, ny = 10, stencil_size = 5;
  PetscInt i, j, its;
  Mat A;
  Vec x, b;
  KSP solver;
  const PetscReal rtol = 1.e-8;
  KSPConvergedReason reason;
  PetscReal errorNorm, rnorm;
  PetscLogDouble t1, t2;
  DM dm;
  DMDALocalInfo info;
  const PetscInt stencilWidth = 1;
  MatStencil row, col5[stencil_size];
  PetscScalar hx2, hy2, coef, coef5[stencil_size];
  PetscScalar **bgrid;

  ierr = PetscInitialize(&argc, &argv, NULL, NULL);
  if (ierr) {
    printf("Error: Could not initialize PETSc, aborting...\n");
    return ierr;
  }

  // Create the 2-D DMDA object
  ierr = DMDACreate2d(PETSC_COMM_WORLD, DM_BOUNDARY_NONE, DM_BOUNDARY_NONE, DMDA_STENCIL_STAR,
                      nx, ny, PETSC_DECIDE, PETSC_DECIDE, 1, stencilWidth,
                      PETSC_NULL, PETSC_NULL, &dm); CHKERRQ(ierr);

  ierr = DMSetFromOptions(dm); CHKERRQ(ierr);
  ierr = DMSetUp(dm); CHKERRQ(ierr);

  // View the DMDA object
  ierr = DMView(dm, PETSC_VIEWER_STDOUT_WORLD); CHKERRQ(ierr);

  // Create the A matrix from the DMDA object
  ierr = DMCreateMatrix(dm, &A); CHKERRQ(ierr);

  // Retrieve local information from the DMDA object
  ierr = DMDAGetLocalInfo(dm, &info); CHKERRQ(ierr);

  hx2 = 1.0 / ((info.mx - 1) * (info.mx - 1));
  hy2 = 1.0 / ((info.my - 1) * (info.my - 1));

  coef = 1.0;
  coef5[0] = 2.0 / hx2 + 2.0 / hy2;
  coef5[1] = -1.0 / hx2; coef5[2] = -1.0 / hx2;
  coef5[3] = -1.0 / hy2; coef5[4] = -1.0 / hy2;

  // Loop on the grid points
  for (j = info.ys; j < info.ys + info.ym; j++) {

    for (i = info.xs; i < info.xs + info.xm; i++) {
      row.i = i; row.j = j; row.c = 0;

      if (i == 0 || i == (info.mx - 1) || j == 0 || j == (info.my - 1)) {
        // Set matrix values to enforce boundary conditions (homogeneous Dirichlet conditions)
        ierr = MatSetValuesStencil(A, 1, &row, 1, &row, &coef, INSERT_VALUES); CHKERRQ(ierr);
      } else {
        // Set matrix values fo interior points
        col5[0].i = i; col5[0].j = j; col5[0].c = 0;
        col5[1].i = i - 1; col5[1].j = j; col5[1].c = 0;
        col5[2].i = i + 1; col5[2].j = j; col5[2].c = 0;
        col5[3].i = i; col5[3].j = j - 1; col5[3].c = 0;
        col5[4].i = i; col5[4].j = j + 1; col5[4].c = 0;
        ierr = MatSetValuesStencil(A, 1, &row, stencil_size, col5, coef5, INSERT_VALUES); CHKERRQ(ierr);
      }
    }
  }
  ierr = MatAssemblyBegin(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);
  ierr = MatAssemblyEnd(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);
  // ierr = MatView(A, PETSC_VIEWER_STDOUT_WORLD); CHKERRQ(ierr);

  // Create global vectors b and x from the DMDA object
  ierr = DMCreateGlobalVector(dm, &b); CHKERRQ(ierr);
  ierr = DMCreateGlobalVector(dm, &x); CHKERRQ(ierr);

  ierr = VecSet(b, 0.0); CHKERRQ(ierr);
  // The way to init to 1 all the boundary
  //ierr = DMDAVecGetArray(dm,b,&bgrid); CHKERRQ(ierr);
  //if (info.ys == 0) {
  //  for (i=info.xs; i<info.xs+info.xm;i++) {
  //    bgrid[0][i] = 1.0; } }
  //if (info.ys+info.ym == info.my) {
  //  for (i=info.xs; i<info.xs+info.xm;i++) {
  //    bgrid[info.my-1][i] = 1.0; } }
  //if (info.xs == 0) {
  //  for (j=info.ys; j<info.ys+info.ym; j++) {
  //    bgrid[j][0] = 1.0; } }
  //if (info.xs+info.xm == info.mx) {
  //  for (j=info.ys; j<info.ys+info.ym; j++) {
  //    bgrid[j][info.mx-1] = 1.0; }}
  //ierr = DMDAVecRestoreArray(dm,b,&bgrid); CHKERRQ(ierr);
  //ierr = VecView(b,PETSC_VIEWER_STDOUT_WORLD); CHKERRQ(ierr);
  ierr = VecSetRandom(x, NULL); CHKERRQ(ierr);

  ierr = KSPCreate(PETSC_COMM_WORLD, &solver); CHKERRQ(ierr);
  ierr = KSPSetOperators(solver, A, A); CHKERRQ(ierr);
  ierr = KSPSetTolerances(solver, rtol, PETSC_DEFAULT, PETSC_DEFAULT, PETSC_DEFAULT); CHKERRQ(ierr);
  ierr = KSPSetInitialGuessNonzero(solver, PETSC_TRUE); CHKERRQ(ierr);
  ierr = KSPSetFromOptions(solver); CHKERRQ(ierr);
  ierr = KSPSetUp(solver); CHKERRQ(ierr);

  ierr = KSPView(solver, PETSC_VIEWER_STDOUT_WORLD); CHKERRQ(ierr);

  ierr = PetscTime(&t1); CHKERRQ(ierr);
  ierr = KSPSolve(solver, b, x); CHKERRQ(ierr);
  ierr = PetscTime(&t2); CHKERRQ(ierr);

  ierr = PetscPrintf(PETSC_COMM_WORLD, "Elapse time: %lf s\n", t2 - t1); CHKERRQ(ierr);

  ierr = KSPGetConvergedReason(solver, &reason); CHKERRQ(ierr);
  ierr = PetscPrintf(PETSC_COMM_WORLD, "Converged reason: %s\n", KSPConvergedReasons[reason]); CHKERRQ(ierr);

  ierr = KSPGetIterationNumber(solver, &its); CHKERRQ(ierr);
  ierr = PetscPrintf(PETSC_COMM_WORLD, "Iterations number: %d\n", its); CHKERRQ(ierr);

  ierr = KSPGetResidualNorm(solver, &rnorm); CHKERRQ(ierr);
  ierr = PetscPrintf(PETSC_COMM_WORLD, "Residual norm: %g\n", rnorm); CHKERRQ(ierr);

  ierr = VecNorm(x, NORM_2, &errorNorm); CHKERRQ(ierr);
  ierr = PetscPrintf(PETSC_COMM_WORLD, "Error norm (NORM_2): %g\n", errorNorm); CHKERRQ(ierr);
  ierr = VecNorm(x, NORM_INFINITY, &errorNorm); CHKERRQ(ierr);
  ierr = PetscPrintf(PETSC_COMM_WORLD, "Error norm (NORM_INFINITY): %g\n", errorNorm); CHKERRQ(ierr);

  ierr = KSPDestroy(&solver); CHKERRQ(ierr);
  ierr = MatDestroy(&A); CHKERRQ(ierr);
  ierr = VecDestroy(&x); CHKERRQ(ierr);
  ierr = VecDestroy(&b); CHKERRQ(ierr);
  ierr = DMDestroy(&dm); CHKERRQ(ierr);

  PetscFinalize();

  return 0;
}
