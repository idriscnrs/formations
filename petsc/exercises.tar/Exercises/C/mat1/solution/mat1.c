#include <petscmat.h>

int main(int argc, char **argv)
{
  PetscErrorCode ierr;
  const PetscInt n = 10;
  PetscInt i, istart, iend, local_size;
  Mat A;
  const PetscScalar one = 1.0;
  Vec u, v;
  PetscScalar *values = NULL;

  ierr = PetscInitialize(&argc, &argv, NULL, NULL);
  if (ierr) {
    printf("Error: Could not initialize PETSc, aborting...\n");
    return ierr;
  }

  ierr = MatCreate(PETSC_COMM_WORLD, &A); CHKERRQ(ierr);
  ierr = MatSetType(A, MATMPIAIJ); CHKERRQ(ierr);
  ierr = MatSetSizes(A, n, n, PETSC_DETERMINE, PETSC_DETERMINE); CHKERRQ(ierr);
  ierr = MatMPIAIJSetPreallocation(A, 1, NULL, 0, NULL); CHKERRQ(ierr);

  ierr = MatGetOwnershipRange(A, &istart, &iend); CHKERRQ(ierr);

  // Using MatDiagonalSet is possible but would require to create a vector full of ones
  for (i = istart; i < iend; i++) {
    ierr = MatSetValues(A, 1, &i, 1, &i, &one, INSERT_VALUES); CHKERRQ(ierr);
  }

  ierr = MatAssemblyBegin(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);
  ierr = MatAssemblyEnd(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);

  ierr = MatScale(A, 0.1); CHKERRQ(ierr);

  ierr = MatCreateVecs(A, &u, &v); CHKERRQ(ierr);

  ierr = VecGetOwnershipRange(u, &istart, &iend); CHKERRQ(ierr);
  local_size = iend - istart;

  ierr = VecGetArray(u, &values); CHKERRQ(ierr);
  for (i = 0; i < local_size; i++) {
    values[i] = (PetscScalar)(i + istart + 1) * 10;
  }
  ierr = VecRestoreArray(u, &values); CHKERRQ(ierr);

  ierr = MatMult(A, u, v); CHKERRQ(ierr);

  ierr = VecView(v, PETSC_VIEWER_STDOUT_WORLD); CHKERRQ(ierr);

  ierr = VecDestroy(&u); CHKERRQ(ierr);
  ierr = VecDestroy(&v); CHKERRQ(ierr);
  ierr = MatDestroy(&A); CHKERRQ(ierr);

  PetscFinalize();

  return 0;
}
