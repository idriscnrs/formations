#include <petscmat.h>

int main(int argc, char **argv)
{
  PetscErrorCode ierr;
  const PetscInt NpointsPerDir = 10, N = NpointsPerDir * NpointsPerDir, stencil_size = 5;
  PetscInt i, istart, iend, colIndex, rowIndex;
  const PetscScalar h = 1.0 / (NpointsPerDir + 1);
  Mat A;
  PetscInt indexes[stencil_size];
  PetscScalar values[] = { -1.0 / (h * h), -1.0 / (h * h), 4.0 / (h * h), -1.0 / (h * h), -1.0 / (h * h) };

  ierr = PetscInitialize(&argc, &argv, PETSC_NULL, PETSC_NULL);
  if (ierr) {
    printf("Error: Could not initialize PETSc, aborting...\n");
    return ierr;
  }

  ierr = MatCreate(PETSC_COMM_WORLD, &A); CHKERRQ(ierr);
  ierr = MatSetType(A, MATMPIAIJ); CHKERRQ(ierr);
  ierr = MatSetSizes(A, PETSC_DECIDE, PETSC_DECIDE, N, N); CHKERRQ(ierr);
  // Comment the next line and uncomment the two lines which follow to check
  // the effect preallocation has on performance
  ierr = MatMPIAIJSetPreallocation(A, stencil_size, PETSC_NULL, stencil_size - 1, PETSC_NULL); CHKERRQ(ierr);
  // ierr = MatMPIAIJSetPreallocation(A, 0, PETSC_NULL, 0 , PETSC_NULL); CHKERRQ(ierr);
  // ierr = MatSetOption(A, MAT_NEW_NONZERO_ALLOCATION_ERR, PETSC_FALSE); CHKERRQ(ierr);

  ierr = MatGetOwnershipRange(A, &istart, &iend); CHKERRQ(ierr);

  for (i = istart; i < iend; i++) {
    rowIndex = i / NpointsPerDir; colIndex = i - rowIndex * NpointsPerDir;

    // Negative indexes are ignored by MatSetValues
    indexes[0] = (rowIndex > 0) ? (i - NpointsPerDir) : -1;
    indexes[1] = (colIndex > 0) ? (i - 1) : -1;
    indexes[2] = i;
    indexes[3] = (colIndex < NpointsPerDir - 1) ? (i + 1) : -1;
    indexes[4] = (rowIndex < NpointsPerDir - 1) ? (i + NpointsPerDir) : -1;

    ierr = MatSetValues(A, 1, &i, stencil_size, indexes, values, INSERT_VALUES); CHKERRQ(ierr);
  }

  ierr = MatAssemblyBegin(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);
  ierr = MatAssemblyEnd(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);

  // Uncomment the next line if you want to view the matrix content
  // ierr = MatView(A, PETSC_VIEWER_STDOUT_WORLD); CHKERRQ(ierr);
  // ierr = MatView(A, PETSC_VIEWER_DRAW_WORLD); CHKERRQ(ierr); // use it with -draw_pause <sec>

  ierr = MatDestroy(&A); CHKERRQ(ierr);

  PetscFinalize();

  return 0;
}
