#include <petscksp.h>
#include <petsctime.h>

int main(int argc, char **argv)
{
  PetscErrorCode ierr;
  const PetscInt stencil_size = 5;
  PetscInt NpointsPerDir = 4, N;
  PetscInt i, istart, iend, its, colIndex, rowIndex;
  PetscInt indexes[stencil_size];
  Mat A;
  PetscScalar h, values[stencil_size];
  Vec x, xExact, b, r, error;
  KSP solver;
  const PetscReal rtol = 1.e-8;
  KSPConvergedReason reason;
  PetscReal errorNorm, xnorm, rnorm, bnorm;
  PetscLogDouble t1, t2;
  PetscLogStage stage1, stage2;

  ierr = PetscInitialize(&argc, &argv, PETSC_NULL, PETSC_NULL);
  if (ierr) {
    printf("Error: Could not initialize PETSc, aborting...\n");
    return ierr;
  }

  ierr = PetscOptionsGetInt(PETSC_NULL, PETSC_NULL, "-size", &NpointsPerDir, PETSC_NULL); CHKERRQ(ierr);
  ierr = PetscPrintf(PETSC_COMM_WORLD, "NpointsPerDir: %D\n", NpointsPerDir); CHKERRQ(ierr);

  N = NpointsPerDir * NpointsPerDir;
  h = 1.0 / (NpointsPerDir + 1);
  values[0] = values[1] = values[3] = values[4] = -1.0 / (h * h);
  values[2] = 4.0 / (h * h);

  ierr = PetscLogStageRegister("Fill & assemble", &stage1); CHKERRQ(ierr);
  ierr = PetscLogStageRegister("Solve", &stage2); CHKERRQ(ierr);

  ierr = MatCreate(PETSC_COMM_WORLD, &A); CHKERRQ(ierr);
  ierr = MatSetType(A, MATMPIAIJ); CHKERRQ(ierr);
  ierr = MatSetSizes(A, PETSC_DECIDE, PETSC_DECIDE, N, N); CHKERRQ(ierr);
  ierr = MatMPIAIJSetPreallocation(A, stencil_size, PETSC_NULL, stencil_size - 1, PETSC_NULL); CHKERRQ(ierr);

  ierr = MatGetOwnershipRange(A, &istart, &iend); CHKERRQ(ierr);

  ierr = PetscLogStagePush(stage1); CHKERRQ(ierr);
  for (i = istart; i < iend; i++) {
    rowIndex = i / NpointsPerDir; colIndex = i - rowIndex * NpointsPerDir;

    // Negative indexes are ignored by MatSetValues
    indexes[0] = (rowIndex > 0) ? (i - NpointsPerDir) : -1;
    indexes[1] = (colIndex > 0) ? (i - 1) : -1;
    indexes[2] = i;
    indexes[3] = (colIndex < NpointsPerDir - 1) ? (i + 1) : -1;
    indexes[4] = (rowIndex < NpointsPerDir - 1) ? (i + NpointsPerDir) : -1;

    ierr = MatSetValues(A, 1, &i, stencil_size, indexes, values, INSERT_VALUES); CHKERRQ(ierr);
  }

  ierr = MatAssemblyBegin(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);
  ierr = MatAssemblyEnd(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);
  ierr = PetscLogStagePop(); CHKERRQ(ierr);

  // Uncomment the next line (or -mat_view at runtime) if you want to view the matrix content
  // ierr = MatView(A, PETSC_VIEWER_STDOUT_WORLD); CHKERRQ(ierr);

  ierr = MatCreateVecs(A, &x, &b); CHKERRQ(ierr);
  ierr = VecDuplicate(x, &xExact); CHKERRQ(ierr);
  ierr = VecSetRandom(xExact, PETSC_NULL); CHKERRQ(ierr);
  ierr = MatMult(A, xExact, b); CHKERRQ(ierr);

  ierr = KSPCreate(PETSC_COMM_WORLD, &solver); CHKERRQ(ierr);
  ierr = KSPSetOperators(solver, A, A); CHKERRQ(ierr);
  ierr = KSPSetTolerances(solver, rtol, PETSC_DEFAULT, PETSC_DEFAULT, PETSC_DEFAULT); CHKERRQ(ierr);
  ierr = KSPSetFromOptions(solver); CHKERRQ(ierr);
  ierr = KSPSetUp(solver); CHKERRQ(ierr);

  // Use this (or -ksp_view at runtime) to view your solver
  ierr = KSPView(solver, PETSC_VIEWER_STDOUT_WORLD); CHKERRQ(ierr);

  ierr = PetscLogStagePush(stage2); CHKERRQ(ierr);
  ierr = PetscTime(&t1); CHKERRQ(ierr);
  ierr = KSPSolve(solver, b, x); CHKERRQ(ierr);
  ierr = PetscTime(&t2); CHKERRQ(ierr);
  ierr = PetscLogStagePop(); CHKERRQ(ierr);

  ierr = PetscPrintf(PETSC_COMM_WORLD, "Elapse time: %lf s\n", t2 - t1); CHKERRQ(ierr);

  ierr = KSPGetConvergedReason(solver, &reason); CHKERRQ(ierr);
  ierr = PetscPrintf(PETSC_COMM_WORLD, "Converged reason: %s\n", KSPConvergedReasons[reason]); CHKERRQ(ierr);

  ierr = KSPGetIterationNumber(solver, &its); CHKERRQ(ierr);
  ierr = PetscPrintf(PETSC_COMM_WORLD, "Iterations number: %d\n", its); CHKERRQ(ierr);

  ierr = KSPGetResidualNorm(solver, &rnorm); CHKERRQ(ierr);
  ierr = PetscPrintf(PETSC_COMM_WORLD, "Residual norm: %g\n", rnorm); CHKERRQ(ierr);

  ierr = VecDuplicate(x, &error); CHKERRQ(ierr);
  ierr = VecCopy(x, error); CHKERRQ(ierr);
  ierr = VecAXPY(error, -1.0, xExact); CHKERRQ(ierr);
  ierr = VecNorm(error, NORM_2, &errorNorm); CHKERRQ(ierr);
  ierr = VecNorm(x, NORM_2, &xnorm); CHKERRQ(ierr);
  ierr = PetscPrintf(PETSC_COMM_WORLD, "Error norm (NORM_2): %g, relative error: %g\n", errorNorm, errorNorm / xnorm); CHKERRQ(ierr);
  ierr = VecNorm(error, NORM_INFINITY, &errorNorm); CHKERRQ(ierr);
  ierr = VecNorm(x, NORM_INFINITY, &xnorm); CHKERRQ(ierr);
  ierr = PetscPrintf(PETSC_COMM_WORLD, "Error norm (NORM_INFINITY): %g, relative error: %g\n", errorNorm, errorNorm / xnorm); CHKERRQ(ierr);

  // Use this (or -ksp_norm_type unpreconditioned at runtime) to compare with the residual computed below.
  // /!\ Works only with the CG, Richardson, Bi-CG-stab, CR, and CGS methods:
  // ierr = KSPSetNormType(solver, KSP_NORM_UNPRECONDITIONED); CHKERRQ(ierr);

  ierr = VecNorm(b, NORM_2, &bnorm); CHKERRQ(ierr);
  ierr = VecDuplicate(b, &r); CHKERRQ(ierr);
  ierr = MatMult(A, x, r); CHKERRQ(ierr);
  ierr = VecAXPY(r, -1.0, b); CHKERRQ(ierr);
  ierr = VecNorm(r, NORM_2, &rnorm); CHKERRQ(ierr);
  ierr = PetscPrintf(PETSC_COMM_WORLD, "Residual norm (computed): %g, relative error: %g\n", rnorm, rnorm / bnorm); CHKERRQ(ierr);

  ierr = KSPDestroy(&solver); CHKERRQ(ierr);
  ierr = VecDestroy(&x); CHKERRQ(ierr);
  ierr = VecDestroy(&xExact); CHKERRQ(ierr);
  ierr = VecDestroy(&b); CHKERRQ(ierr);
  ierr = VecDestroy(&r); CHKERRQ(ierr);
  ierr = VecDestroy(&error); CHKERRQ(ierr);
  ierr = MatDestroy(&A); CHKERRQ(ierr);

  PetscFinalize();

  return 0;
}
