#include <petscvec.h>

int main(int argc, char **argv)
{
  PetscErrorCode ierr;
  int size, rank;
  Vec vec, vec2;
  PetscScalar product;
  PetscReal norm;

  ierr = PetscInitialize(&argc, &argv, NULL, NULL);
  if (ierr) {
    printf("Error: Could not initialize PETSc, aborting...\n");
    return ierr;
  }

  MPI_Comm_size(PETSC_COMM_WORLD, &size);
  MPI_Comm_rank(PETSC_COMM_WORLD, &rank);

  ierr = VecCreate(PETSC_COMM_WORLD, &vec); CHKERRQ(ierr);
  ierr = VecSetType(vec, VECMPI); CHKERRQ(ierr);
  ierr = VecSetSizes(vec, rank + 1, PETSC_DETERMINE); CHKERRQ(ierr);
  ierr = VecSet(vec, size * 0.5); CHKERRQ(ierr);

  ierr = VecView(vec, PETSC_VIEWER_STDOUT_WORLD); CHKERRQ(ierr);

  ierr = VecDuplicate(vec, &vec2); CHKERRQ(ierr);
  ierr = VecCopy(vec, vec2); CHKERRQ(ierr);

  ierr = VecDot(vec, vec2, &product); CHKERRQ(ierr);
  ierr = VecNorm(vec, NORM_2, &norm); CHKERRQ(ierr);

  ierr = PetscPrintf(PETSC_COMM_WORLD, "[%d] dot product = %lf | norm = %lf | norm² = %lf\n", rank, product, norm, norm*norm); CHKERRQ(ierr);

  ierr = VecDestroy(&vec); CHKERRQ(ierr);
  ierr = VecDestroy(&vec2); CHKERRQ(ierr);

  PetscFinalize();

  return 0;
}
