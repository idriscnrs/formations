#include <petscvec.h>
#include <petsctime.h>

int main(int argc, char **argv)
{
  // Use a smaller vector size if the program runs out of memory
  const PetscInt N = 600000000;
  PetscErrorCode ierr;
  Vec bigVec;
  PetscInt i, istart, iend, local_size;
  PetscScalar *values = NULL;
  PetscLogDouble t1, t2;

  ierr = PetscInitialize(&argc, &argv, NULL, NULL);
  if (ierr) {
    printf("Error: Could not initialize PETSc, aborting...\n");
    return ierr;
  }

  ierr = VecCreate(PETSC_COMM_WORLD, &bigVec); CHKERRQ(ierr);
  ierr = VecSetType(bigVec, VECMPI); CHKERRQ(ierr);
  ierr = VecSetSizes(bigVec, PETSC_DECIDE, N); CHKERRQ(ierr);

  ierr = VecGetOwnershipRange(bigVec, &istart, &iend); CHKERRQ(ierr);

  ierr = PetscTime(&t1); CHKERRQ(ierr);
  local_size = iend - istart;
  ierr = VecGetArray(bigVec, &values); CHKERRQ(ierr);
  for (i = 0; i < local_size; i++) {
    values[i] = (PetscScalar)(i + istart);
  }
  ierr = VecRestoreArray(bigVec, &values); CHKERRQ(ierr);
  ierr = PetscTime(&t2); CHKERRQ(ierr);

  ierr = PetscPrintf(PETSC_COMM_WORLD, "Vector initialized in %lf s\n", t2 - t1); CHKERRQ(ierr);

  ierr = VecDestroy(&bigVec); CHKERRQ(ierr);

  PetscFinalize();

  return 0;
}
