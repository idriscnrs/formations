# Zay
#module load intel-all/19.0.4
module load petsc/3.17.4-mpi-debug
#module load petsc/3.17.4-mpi

# Ruche
#module load intel/19.0.3/gcc-4.8.5
#module load intel-mpi/2019.3.199/intel-19.0.3.199
#module load intel-mkl/2019.3.199/intel-19.0.3.199
#module load petsc/3.15.0/intel-19.0.3.199-intel-mpi
#module load petsc/3.14.6/intel-19.0.3.199-intel-mpi
