Utilisation des directives `-qopt-report=5 -qopt-report-phase=vec`
