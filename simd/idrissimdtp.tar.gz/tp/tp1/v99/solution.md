# V0- version de base

```
real    0m1.114s
```

Avec l'option `-qopt-report=5 -qopt-report-phase=vec`

```
LOOP BEGIN at main.f90(15,3)
   remark #15382: vectorization support: call to function AIRE cannot be vectorized   [ main.f90(19,21) ]
```

# V1-Vectorisation

Il faut déclarer la fonction aire comme vectorisable avec `omp declare simd`
et déclarer la boucle dans le `main` comme vectorielle avec `omp simd`

```   
real    0m0.504s
```

# V2-AVX

Comme indiquer dans le rapport il faut aussi utiliser l'option
`-vecabi=cmdtarget` sinon uniquement la version SSE de la fonction `aire` est
 utilisé

```
real    0m0.371s
```


# V3-AVX512

Utilisation de `-qopt-zmm-usage=high`

```
real    0m0.326s
```

