# V0 - Version de base

```
Time    18.15181     s         321 its   17.68419     it/s
```

# V1 - Dérouler la boucle sur les dimensions

Déroule la boucle sur les dimensions (`itern`) pour vectoriser la boucle sur les
clusters. A priori c'est ce que semble faire déjà le compilateur

```
Time    18.34732     s         321 its   17.49575     it/s
```

# V2 - Structure de tableaux

```fortran
LOOP BEGIN at kmeans.f90(91,7)
   remark #15415: vectorization support: non-unit strided load was generated for the variable <CENTROIDS(itern,iterk)>, stride is 6   [ kmeans.f90(94,24) ]
   remark #15415: vectorization support: non-unit strided load was generated for the variable <CENTROIDS(itern,iterk)>, stride is 6   [ kmeans.f90(94,24) ]
```
`centroids(iterk)%position(1)` et `centroids(iterk+1)%position(1)` ne sont pas
 contiguës en mémoire

L'idée est d'avoir plutôt que des tableaux de structure, des structures de
 tableaux

Par exemple : 
```fortran
  type :: point
    ! position of the points
    real(kind=dp), dimension(POINTS_DIMENSION) :: position
    ! centroid  id  associated
    integer :: centroid_id
  end type
  type(point) , dimension(:), allocatable :: points
```
Est remplacé par :
```fortran
  type :: point_array
    ! position of the points
    real(kind=dp), dimension(:,:),allocatable :: position
    ! centroid  id  associated
    integer, dimension(:), allocatable :: centroid_id
  end type
  type(point_array) :: tabpoints
```

Ainsi `tabbpoints%position(iterk,1)` et `tabbpoints%position(iterk+1,1)` sont
 contiguës en mémoire

```
Time    10.19064     s         340 its   33.36395     it/s
```

# V3 - AVX512

Utilisation de `-qopt-zmm-usage=high`

```
Time    10.35398     s         340 its   32.83762     it/s
```

Pas de gain

# V4 - Optionnel

Optimisation du calcul du minimum de distance
`(x-c)**2 = x**2 +c**2 - 2xc`
Donc pour un point fixé (x) fixé on a `min((x-c)**2)=min(0.5*c**2-xc)`
On peut faire un pré-calcul des `0.5*c**2`
L'opération de calcul de distance passe de 2 soustractions,1 multiplication et
 1 FMA à 2 FMA

```
Time    9.316853     s         340 its   36.49301     it/s
```
