# V0 - Version de base

```
Temps CPU (s.)     :    75.2991520000000
```

# V1 - constoprim

Dans le fichier `module_hydro_utils.f90`, dans la fonction `constoprim` on
 remplace `eken(j)` par `eken`
```
Temps CPU (s.)     :    71.2699510000000
```

# V2 - compdt

Dans le fichier `module_hydro_principal.f90`, dans la fonction `compdt` on
 remplace `eken(jj)` par `eken`

```
Temps CPU (s.)     :    62.4362580000000
```

# V3 - cmpflx

Dans le fichier `module_hydro_utils.f90`, dans la fonction `cmpflx` on coupe en
 deux la boucle pour sortir le `if` de la boucle

```
Temps CPU (s.)     :    61.2484710000000
```

