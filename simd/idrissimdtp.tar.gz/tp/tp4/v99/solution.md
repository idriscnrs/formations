# V0 - Version de base

```
+ idrmem ./heatnum
      358384  9.998620953410864E-008   74749.9980008451            74750
IdrisMem v1.3 : elapsed = 215.95 s, VMSizeMax = 17 mB, RSSMax = 4784 kB, StackMax = 152 kB
```

La boucle principale n'est pas vectorisé: 

```
LOOP BEGIN at heatnum.f90(35,7)
  remark #15344: loop was not vectorized: vector dependence prevents vectorization
  remark #15346: vector dependence: assumed FLOW dependence between V(iterx,itery,new) (36:9) and V(iterx-1,itery,old) (36:9)
  remark #15346: vector dependence: assumed ANTI dependence between V(iterx-1,itery,old) (36:9) and V(iterx,itery,new) (36:9)
```

le compilateur pense qu'il est possible que `new=old`

# V1 - Vectorisation de la boucle

On force la vectorisation avec omp simd

```
!$omp simd private(delta) reduction(max:diff)
```

```
+ idrmem ./heatnum
      358384  9.998620953410864E-008   74749.9980008451            74750
IdrisMem v1.3 : elapsed = 71.55 s, VMSizeMax = 17 mB, RSSMax = 4780 kB, StackMax = 152 kB
      ```

# V2 - Suppression de la division

```
remark #15486: divides: 1
```

La division par `9.0_dp` peut être remplacé par la multiplication par l'inverse
 de 9.

```
+ idrmem ./heatnum
      358385  9.999499511142362E-008   74749.9980008241            74750
IdrisMem v1.3 : elapsed = 64.84 s, VMSizeMax = 17 mB, RSSMax = 4784 kB, StackMax = 152 kB
```

# V3 - Activation de l'avx512

On utilise l'option `-qopt-zmm-usage=high`

```
+ idrmem ./heatnum
      358385  9.999499511142362E-008   74749.9980008241            74750
IdrisMem v1.3 : elapsed = 55.38 s, VMSizeMax = 17 mB, RSSMax = 4884 kB, StackMax = 152 kB
```

# V4 : Alignement

On utilise l'option `-align array64byte`

```
      + idrmem ./heatnum
      358385  9.999499511142362E-008   74749.9980008241            74750
IdrisMem v1.3 : elapsed = 55.07 s, VMSizeMax = 17 mB, RSSMax = 4768 kB, StackMax = 152 kB
```

Cela ne change rien car la boucle démarre à 2

# v5 : Alignement++

On ajoute des éléments fictifs aux tableaux `allocate(v(-5:nx+14,ny+4,2))` pour
 que `v(2,i)` soit aligné.

```
+ idrmem ./heatnum
      358385  9.999499511142362E-008   74749.9980008241            74750
IdrisMem v1.3 : elapsed = 41.66 s, VMSizeMax = 17 mB, RSSMax = 4748 kB, StackMax = 152 kB
```
