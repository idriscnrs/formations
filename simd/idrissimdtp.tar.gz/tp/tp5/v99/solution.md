# V0 - Version de base

Version de base

```
3.861024     s   160.6416     Mit/s  3.9208680E-07
```

```
LOOP BEGIN at argmin.f90(17,5)
  remark #15344: loop was not vectorized: vector dependence prevents vectorization
  remark #15346: vector dependence: assumed ANTI dependence between k (18:19) and k (19:9)
```

# V1 - Version Explicite

L'idée est de faire comme pour une réduction, de stocker un vecteur d'indice 

```
3.591281     s   172.7074     Mit/s  3.9208680E-07
```


# V3 - Optimisation des accès mémoire

```
remark #15415: vectorization support: irregularly indexed load was generated for the variable <a(ksimd(isimd))>, part of index is read from memory   [ argmin.f90(26,9) ]
```

Le `a(ksimd(isimd))` coute cher, l'idée est de stocker aussi un vecteur de
valeur

```
0.5005540     s   1239.109     Mit/s  3.9208680E-07
```
